# EcoBin - Entrega Java + SQL Server + Mobile

## Estrutura

```text
backend-java/   API Java Spring Boot
mobile/ecobin/  App React Native/Expo original
```

## Rodar SQL Server

```bash
cd backend-java
docker compose -f docker-compose.sqlserver.yml up -d
```

Credenciais padrão:

```text
Banco: EcoBin
Usuário: sa
Senha: EcoBin@123456
Porta: 1433
```

## Rodar API Java

```bash
cd backend-java
mvn spring-boot:run
```

Swagger:

```text
http://localhost:8080/swagger-ui.html
```

Login inicial:

```json
{
  "Email": "admin@ecobin.com",
  "Password": "123456"
}
```

## Rodar mobile

```bash
cd mobile/ecobin
npm install
copy .env.example .env
npx expo start
```

No celular físico, troque `SEU_IP_DO_PC` pelo IP do computador. Não use `localhost` no celular.

Exemplo:

```text
API_URL=http://192.168.0.10:8080/api/
```

## Credenciais do AppLogin

```text
APP_ID=ecobin-mobile-app-2025
APP_SECRET=GrupoBioCodeFacens
```


## Rota adicionada para status das lixeiras

Foi adicionada a rota equivalente ao método C# `GetStatusLixeirasAsync(int condominioId)`:

```text
GET /api/Telemetrias/condominio/{condominioId}/status-lixeiras
GET /api/Telemetrias/status-lixeiras/{condominioId}
```

Ela retorna `ResponseModel<List<StatusLixeiraDTO>>` com `sensorId`, `nome`, `tipoLixeira`, `nivelOcupacao`, `statusCor`, `statusLabel`, `latitude`, `longitude` e `ultimaLeitura`.
