package com.ecobin.api.models;

import java.time.LocalDateTime;

public class ResponseModel<T> {
    private T dados;
    private String mensagem = "";
    private boolean status = true;
    private byte[] qrCodeBytes;
    private String sessionToken;
    private LocalDateTime sessionExpires;

    public ResponseModel() {}

    public ResponseModel(T dados, String mensagem, boolean status) {
        this.dados = dados;
        this.mensagem = mensagem;
        this.status = status;
    }

    public static <T> ResponseModel<T> ok(T dados, String mensagem) { return new ResponseModel<>(dados, mensagem, true); }
    public static <T> ResponseModel<T> erro(String mensagem) { return new ResponseModel<>(null, mensagem, false); }

    public T getDados() { return dados; }
    public void setDados(T dados) { this.dados = dados; }
    public String getMensagem() { return mensagem; }
    public void setMensagem(String mensagem) { this.mensagem = mensagem; }
    public boolean isStatus() { return status; }
    public boolean getStatus() { return status; }
    public void setStatus(boolean status) { this.status = status; }
    public byte[] getQrCodeBytes() { return qrCodeBytes; }
    public void setQrCodeBytes(byte[] qrCodeBytes) { this.qrCodeBytes = qrCodeBytes; }
    public String getSessionToken() { return sessionToken; }
    public void setSessionToken(String sessionToken) { this.sessionToken = sessionToken; }
    public LocalDateTime getSessionExpires() { return sessionExpires; }
    public void setSessionExpires(LocalDateTime sessionExpires) { this.sessionExpires = sessionExpires; }
}
