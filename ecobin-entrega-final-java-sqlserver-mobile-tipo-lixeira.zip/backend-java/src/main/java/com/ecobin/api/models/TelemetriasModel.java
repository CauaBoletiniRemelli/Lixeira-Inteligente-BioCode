package com.ecobin.api.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "TELemetrias")
public class TelemetriasModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "TEL_SENId", nullable = false)
    private Integer sensorId;

    @Column(name = "TELMomento")
    private LocalDateTime momento;

    @Column(name = "TELNivelOcupacao")
    private Integer nivelOcupacao;

    @Column(name = "TELBateria")
    private Integer bateria;

    @Column(name = "TELTemperatura", precision = 6, scale = 2)
    private BigDecimal temperatura;

    @Column(name = "TELDadosBrutos", columnDefinition = "TEXT")
    private String dadosBrutos;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "TEL_SENId", insertable = false, updatable = false)
    @JsonIgnore
    private SensoresModel sensor;

    @PrePersist public void prePersist(){ if(momento==null) momento=LocalDateTime.now(); }

    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Integer getSensorId(){return sensorId;} public void setSensorId(Integer sensorId){this.sensorId=sensorId;}
    public LocalDateTime getMomento(){return momento;} public void setMomento(LocalDateTime momento){this.momento=momento;}
    public Integer getNivelOcupacao(){return nivelOcupacao;} public void setNivelOcupacao(Integer nivelOcupacao){this.nivelOcupacao=nivelOcupacao;}
    public Integer getBateria(){return bateria;} public void setBateria(Integer bateria){this.bateria=bateria;}
    public BigDecimal getTemperatura(){return temperatura;} public void setTemperatura(BigDecimal temperatura){this.temperatura=temperatura;}
    public String getDadosBrutos(){return dadosBrutos;} public void setDadosBrutos(String dadosBrutos){this.dadosBrutos=dadosBrutos;}
    public SensoresModel getSensor(){return sensor;} public void setSensor(SensoresModel sensor){this.sensor=sensor;}
}
