package com.ecobin.api.dto.provisionamentos;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class AssignWifiRequestDTO {
    private String wifiSSID;
    private String wifiPassword;

    public AssignWifiRequestDTO() {}

    public String getWifiSSID() { return wifiSSID; }
    public void setWifiSSID(String wifiSSID) { this.wifiSSID = wifiSSID; }

    public String getWifiPassword() { return wifiPassword; }
    public void setWifiPassword(String wifiPassword) { this.wifiPassword = wifiPassword; }

}
