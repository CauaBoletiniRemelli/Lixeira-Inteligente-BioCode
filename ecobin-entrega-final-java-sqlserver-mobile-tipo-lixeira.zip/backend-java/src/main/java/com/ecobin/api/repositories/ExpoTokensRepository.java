package com.ecobin.api.repositories;

import com.ecobin.api.models.ExpoTokensModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ExpoTokensRepository extends JpaRepository<ExpoTokensModel, Integer> {
    List<ExpoTokensModel> findByUsuarioIdAndAtivoTrue(Integer usuarioId);
    List<ExpoTokensModel> findByAtivoTrue();
    Optional<ExpoTokensModel> findFirstByUsuarioIdAndDispositivoAndAtivoTrue(Integer usuarioId, String dispositivo);
}
