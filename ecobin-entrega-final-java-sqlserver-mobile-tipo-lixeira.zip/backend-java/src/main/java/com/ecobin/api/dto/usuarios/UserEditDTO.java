package com.ecobin.api.dto.usuarios;

import com.ecobin.api.enums.TipoUsuario;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class UserEditDTO {
    private Integer id;
    private String nome;
    private String email;
    private String senhaHash;
    private TipoUsuario tipo;
    private Integer condominioId;

    public UserEditDTO() {}

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenhaHash() { return senhaHash; }
    public void setSenhaHash(String senhaHash) { this.senhaHash = senhaHash; }

    public TipoUsuario getTipo() { return tipo; }
    public void setTipo(TipoUsuario tipo) { this.tipo = tipo; }

    public Integer getCondominioId() { return condominioId; }
    public void setCondominioId(Integer condominioId) { this.condominioId = condominioId; }

}
