package com.ecobin.api.dto.telemetrias;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class TelemetriaStatsDTO {
    private Integer sensorId;
    private String nomeSensor;
    private Integer totalLeituras;
    private BigDecimal mediaOcupacao;
    private BigDecimal mediaTemperatura;
    private Integer nivelAtual;
    private LocalDateTime ultimaLeitura;
    private Integer alertasCheio;

    public TelemetriaStatsDTO() {}

    public Integer getSensorId() { return sensorId; }
    public void setSensorId(Integer sensorId) { this.sensorId = sensorId; }

    public String getNomeSensor() { return nomeSensor; }
    public void setNomeSensor(String nomeSensor) { this.nomeSensor = nomeSensor; }

    public Integer getTotalLeituras() { return totalLeituras; }
    public void setTotalLeituras(Integer totalLeituras) { this.totalLeituras = totalLeituras; }

    public BigDecimal getMediaOcupacao() { return mediaOcupacao; }
    public void setMediaOcupacao(BigDecimal mediaOcupacao) { this.mediaOcupacao = mediaOcupacao; }

    public BigDecimal getMediaTemperatura() { return mediaTemperatura; }
    public void setMediaTemperatura(BigDecimal mediaTemperatura) { this.mediaTemperatura = mediaTemperatura; }

    public Integer getNivelAtual() { return nivelAtual; }
    public void setNivelAtual(Integer nivelAtual) { this.nivelAtual = nivelAtual; }

    public LocalDateTime getUltimaLeitura() { return ultimaLeitura; }
    public void setUltimaLeitura(LocalDateTime ultimaLeitura) { this.ultimaLeitura = ultimaLeitura; }

    public Integer getAlertasCheio() { return alertasCheio; }
    public void setAlertasCheio(Integer alertasCheio) { this.alertasCheio = alertasCheio; }

}
