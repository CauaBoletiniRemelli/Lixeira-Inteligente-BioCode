package com.ecobin.api.controllers;

import com.ecobin.api.models.*;
import com.ecobin.api.requests.*;
import com.ecobin.api.services.auth.IAuthInterface;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/Auth")
public class AuthController {
    private final IAuthInterface authInterface;

    public AuthController(IAuthInterface authInterface) {
        this.authInterface = authInterface;
    }

    @PostMapping("/AppLogin")
    public ResponseEntity<ResponseModel<AuthModel>> appLogin(@RequestBody AppLoginRequest request) {
        ResponseModel<AuthModel> response = authInterface.appLogin(request);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.status(401).body(response);
    }

    @PostMapping("/ArduinoLogin")
    public ResponseEntity<ResponseModel<AuthModel>> arduinoLogin(@RequestBody ArduinoLoginRequest request) {
        ResponseModel<AuthModel> response = authInterface.arduinoLogin(request);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.status(401).body(response);
    }

    @PreAuthorize("hasAuthority('AppOnly')")
    @PostMapping("/Login")
    public ResponseEntity<ResponseModel<AuthModel>> auth(@RequestBody LoginRequest request) {
        ResponseModel<AuthModel> response = authInterface.login(request);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.status(401).body(response);
    }

    @PostMapping("/RefreshToken")
    public ResponseEntity<ResponseModel<AuthModel>> refreshToken(@RequestBody RefreshTokenRequest request) {
        ResponseModel<AuthModel> response = authInterface.refreshToken(request);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.status(401).body(response);
    }

    @PostMapping("/Logout")
    public ResponseEntity<ResponseModel<Object>> logout(@RequestBody RefreshTokenRequest request) {
        ResponseModel<Object> response = authInterface.logout(request);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("hasAuthority('AppOnly')")
    @PostMapping("/forgot-password")
    public ResponseEntity<ResponseModel<UsuariosModel>> forgotMyPassword(@RequestParam String usuEmail) {
        ResponseModel<UsuariosModel> response = authInterface.forgotPassword(usuEmail);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }
}
