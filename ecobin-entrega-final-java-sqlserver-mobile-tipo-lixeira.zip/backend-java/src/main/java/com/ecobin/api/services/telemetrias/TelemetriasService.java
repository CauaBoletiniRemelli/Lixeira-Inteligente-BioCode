package com.ecobin.api.services.telemetrias;

import com.ecobin.api.dto.telemetrias.TelemetriaArduinoDTO;
import com.ecobin.api.dto.telemetrias.TelemetriaCreateDTO;
import com.ecobin.api.dto.telemetrias.TelemetriaFiltroDTO;
import com.ecobin.api.dto.telemetrias.TelemetriaResponseDTO;
import com.ecobin.api.dto.telemetrias.TelemetriaStatsDTO;
import com.ecobin.api.dto.telemetrias.StatusLixeiraDTO;
import com.ecobin.api.models.ResponseModel;
import com.ecobin.api.models.SensoresModel;
import com.ecobin.api.models.TelemetriasModel;
import com.ecobin.api.repositories.SensoresRepository;
import com.ecobin.api.repositories.TelemetriasRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class TelemetriasService implements ITelemetriasInterface {
    private final TelemetriasRepository telemetriasRepository;
    private final SensoresRepository sensoresRepository;

    public TelemetriasService(TelemetriasRepository telemetriasRepository, SensoresRepository sensoresRepository) {
        this.telemetriasRepository = telemetriasRepository;
        this.sensoresRepository = sensoresRepository;
    }

    @Override
    public ResponseModel<TelemetriaResponseDTO> createTelemetriaAsync(TelemetriaCreateDTO dto) {
        ResponseModel<TelemetriaResponseDTO> response = new ResponseModel<>();
        try {
            SensoresModel sensor = sensoresRepository.findById(dto.getSensorId()).orElse(null);
            if (sensor == null) {
                response.setStatus(false);
                response.setMensagem("Sensor não encontrado.");
                return response;
            }

            TelemetriasModel telemetria = new TelemetriasModel();
            telemetria.setSensorId(dto.getSensorId());
            telemetria.setNivelOcupacao(dto.getNivelOcupacao());
            telemetria.setBateria(dto.getBateria());
            telemetria.setTemperatura(dto.getTemperatura());
            telemetria.setMomento(dto.getMomento() != null ? dto.getMomento() : LocalDateTime.now());
            telemetria.setDadosBrutos(dto.getDadosBrutos());

            telemetriasRepository.save(telemetria);

            if (dto.getNivelOcupacao() != null) {
                sensor.setStatus(dto.getNivelOcupacao() >= 90 ? 2 : 1);
                sensoresRepository.save(sensor);
            }

            TelemetriaResponseDTO responseData = new TelemetriaResponseDTO();
            responseData.setId(telemetria.getId());
            responseData.setSensorId(telemetria.getSensorId());
            responseData.setMomento(telemetria.getMomento() != null ? telemetria.getMomento() : LocalDateTime.now());
            responseData.setNivelOcupacao(telemetria.getNivelOcupacao());
            responseData.setAlertaGerado(dto.getNivelOcupacao() != null && dto.getNivelOcupacao() >= 90);
            responseData.setMensagem(dto.getNivelOcupacao() != null && dto.getNivelOcupacao() >= 90
                    ? "Alerta: Lixeira quase cheia!"
                    : "Telemetria registrada com sucesso.");

            response.setStatus(true);
            response.setMensagem("Telemetria criada com sucesso.");
            response.setDados(responseData);
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao criar telemetria: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<TelemetriaResponseDTO> createTelemetriaArduinoAsync(TelemetriaArduinoDTO dto) {
        try {
            TelemetriaCreateDTO telemetriaDTO = new TelemetriaCreateDTO();
            telemetriaDTO.setSensorId(dto.getSensorId());
            telemetriaDTO.setNivelOcupacao(Math.round(dto.getNivelLixo()));
            telemetriaDTO.setBateria(dto.getBateria());
            telemetriaDTO.setTemperatura(BigDecimal.valueOf(dto.getTemperatura()));
            telemetriaDTO.setMomento(!isNullOrWhiteSpace(dto.getDataHora()) ? parseDate(dto.getDataHora()) : LocalDateTime.now());
            telemetriaDTO.setDadosBrutos("{"
                    + "\"nivelLixo\":" + dto.getNivelLixo() + ","
                    + "\"temperatura\":" + dto.getTemperatura() + ","
                    + "\"umidade\":" + dto.getUmidade() + ","
                    + "\"distancia\":" + dto.getDistancia() + ","
                    + "\"capacidade\":" + dto.getCapacidade() + ","
                    + "\"alertaCheio\":" + dto.getAlertaCheio() + ","
                    + "\"bateria\":" + dto.getBateria() + ","
                    + "\"timestamp\":\"" + (dto.getDataHora() == null ? "" : dto.getDataHora()) + "\""
                    + "}");

            return createTelemetriaAsync(telemetriaDTO);
        } catch (Exception ex) {
            ResponseModel<TelemetriaResponseDTO> response = new ResponseModel<>();
            response.setStatus(false);
            response.setMensagem("Erro ao processar dados do Arduino: " + ex.getMessage());
            return response;
        }
    }

    @Override
    public ResponseModel<List<TelemetriasModel>> getTelemetriasAsync() {
        ResponseModel<List<TelemetriasModel>> response = new ResponseModel<>();
        try {
            List<TelemetriasModel> telemetrias = telemetriasRepository.findAll().stream()
                    .sorted(Comparator.comparing(TelemetriasModel::getMomento, Comparator.nullsLast(Comparator.naturalOrder())).reversed())
                    .limit(1000)
                    .toList();

            response.setStatus(true);
            response.setDados(telemetrias);
            response.setMensagem(telemetrias.size() + " telemetrias encontradas.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<List<TelemetriasModel>> getTelemetriasFiltroAsync(TelemetriaFiltroDTO filtro) {
        ResponseModel<List<TelemetriasModel>> response = new ResponseModel<>();
        try {
            List<TelemetriasModel> dados = telemetriasRepository.findAll().stream()
                    .filter(t -> filtro.getSensorId() == null || Objects.equals(t.getSensorId(), filtro.getSensorId()))
                    .filter(t -> filtro.getCondominioId() == null || sensorPertenceAoCondominio(t.getSensorId(), filtro.getCondominioId()))
                    .filter(t -> filtro.getDataInicio() == null || (t.getMomento() != null && !t.getMomento().isBefore(filtro.getDataInicio())))
                    .filter(t -> filtro.getDataFim() == null || (t.getMomento() != null && !t.getMomento().isAfter(filtro.getDataFim())))
                    .filter(t -> filtro.getNivelMinimoOcupacao() == null || (t.getNivelOcupacao() != null && t.getNivelOcupacao() >= filtro.getNivelMinimoOcupacao()))
                    .filter(t -> filtro.getNivelMaximoOcupacao() == null || (t.getNivelOcupacao() != null && t.getNivelOcupacao() <= filtro.getNivelMaximoOcupacao()))
                    .sorted(Comparator.comparing(TelemetriasModel::getMomento, Comparator.nullsLast(Comparator.naturalOrder())).reversed())
                    .collect(Collectors.toList());

            int skip = filtro.getSkip() == null ? 0 : filtro.getSkip();
            int take = filtro.getTake() == null ? dados.size() : filtro.getTake();
            dados = dados.stream().skip(skip).limit(take).collect(Collectors.toList());

            response.setStatus(true);
            response.setDados(dados);
            response.setMensagem(dados.size() + " telemetrias encontradas.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<List<TelemetriasModel>> getTelemetriasBySensorAsync(Integer sensorId, int limit) {
        ResponseModel<List<TelemetriasModel>> response = new ResponseModel<>();
        try {
            List<TelemetriasModel> telemetrias = telemetriasRepository.findBySensorIdOrderByMomentoDesc(sensorId, PageRequest.of(0, limit));
            response.setStatus(true);
            response.setDados(telemetrias);
            response.setMensagem(telemetrias.size() + " telemetrias encontradas.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<TelemetriasModel> getUltimaTelemetriaAsync(Integer sensorId) {
        ResponseModel<TelemetriasModel> response = new ResponseModel<>();
        try {
            List<TelemetriasModel> lista = telemetriasRepository.findBySensorIdOrderByMomentoDesc(sensorId, PageRequest.of(0, 1));
            if (lista.isEmpty()) {
                response.setStatus(false);
                response.setMensagem("Nenhuma telemetria encontrada para este sensor.");
                return response;
            }

            response.setStatus(true);
            response.setDados(lista.get(0));
            response.setMensagem("Última telemetria encontrada.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<List<TelemetriasModel>> getTelemetriasByCondominioAsync(Integer condominioId) {
        ResponseModel<List<TelemetriasModel>> response = new ResponseModel<>();
        try {
            List<Integer> sensores = sensoresRepository.findByCondominioId(condominioId).stream().map(SensoresModel::getId).toList();
            List<TelemetriasModel> telemetrias = telemetriasRepository.findAll().stream()
                    .filter(t -> sensores.contains(t.getSensorId()))
                    .sorted(Comparator.comparing(TelemetriasModel::getMomento, Comparator.nullsLast(Comparator.naturalOrder())).reversed())
                    .limit(1000)
                    .toList();

            response.setStatus(true);
            response.setDados(telemetrias);
            response.setMensagem(telemetrias.size() + " telemetrias encontradas.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<TelemetriaStatsDTO> getEstatisticasSensorAsync(Integer sensorId, LocalDateTime dataInicio, LocalDateTime dataFim) {
        ResponseModel<TelemetriaStatsDTO> response = new ResponseModel<>();
        try {
            SensoresModel sensor = sensoresRepository.findById(sensorId).orElse(null);
            if (sensor == null) {
                response.setStatus(false);
                response.setMensagem("Sensor não encontrado.");
                return response;
            }

            List<TelemetriasModel> telemetrias = telemetriasRepository.findBySensorId(sensorId).stream()
                    .filter(t -> dataInicio == null || (t.getMomento() != null && !t.getMomento().isBefore(dataInicio)))
                    .filter(t -> dataFim == null || (t.getMomento() != null && !t.getMomento().isAfter(dataFim)))
                    .toList();

            TelemetriaStatsDTO stats = buildStats(sensor, telemetrias);
            response.setStatus(true);
            response.setDados(stats);
            response.setMensagem("Estatísticas calculadas.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<List<TelemetriaStatsDTO>> getEstatisticasCondominioAsync(Integer condominioId) {
        ResponseModel<List<TelemetriaStatsDTO>> response = new ResponseModel<>();
        try {
            List<TelemetriaStatsDTO> statsList = sensoresRepository.findByCondominioId(condominioId).stream()
                    .map(sensor -> buildStats(sensor, telemetriasRepository.findBySensorId(sensor.getId())))
                    .toList();

            response.setStatus(true);
            response.setDados(statsList);
            response.setMensagem("Estatísticas de " + statsList.size() + " sensores.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }


    @Override
    public ResponseModel<List<StatusLixeiraDTO>> getStatusLixeirasAsync(Integer condominioId) {
        ResponseModel<List<StatusLixeiraDTO>> response = new ResponseModel<>();
        try {
            final int limiarLotada = 90;
            final int limiarEnchendo = 70;

            List<SensoresModel> sensores = sensoresRepository.findByCondominioId(condominioId);

            List<TelemetriasModel> ultimasTelemetrias = telemetriasRepository.findAll().stream()
                    .filter(t -> t.getSensorId() != null)
                    .filter(t -> t.getNivelOcupacao() != null)
                    .filter(t -> sensorPertenceAoCondominio(t.getSensorId(), condominioId))
                    .collect(Collectors.groupingBy(TelemetriasModel::getSensorId))
                    .values().stream()
                    .map(lista -> lista.stream()
                            .max(Comparator.comparing(TelemetriasModel::getMomento, Comparator.nullsLast(Comparator.naturalOrder())))
                            .orElse(null))
                    .filter(Objects::nonNull)
                    .toList();

            List<StatusLixeiraDTO> resultado = sensores.stream().map(sensor -> {
                TelemetriasModel ultima = ultimasTelemetrias.stream()
                        .filter(t -> Objects.equals(t.getSensorId(), sensor.getId()))
                        .findFirst()
                        .orElse(null);

                int nivel = ultima != null && ultima.getNivelOcupacao() != null ? ultima.getNivelOcupacao() : 0;
                String cor = nivel >= limiarLotada ? "vermelho" : nivel >= limiarEnchendo ? "amarelo" : "verde";
                String statusLabel = nivel >= limiarLotada ? "Lotada" : nivel >= limiarEnchendo ? "Enchendo" : "Livre";

                StatusLixeiraDTO dto = new StatusLixeiraDTO();
                dto.setSensorId(sensor.getId());
                dto.setNome(sensor.getNome() != null ? sensor.getNome() : "Lixeira " + sensor.getId());
                dto.setTipoLixeira(sensor.getTipo() != null ? sensor.getTipo() : "Comum");
                dto.setNivelOcupacao(nivel);
                dto.setStatusCor(cor);
                dto.setStatusLabel(statusLabel);
                dto.setLatitude(sensor.getLatitude());
                dto.setLongitude(sensor.getLongitude());
                dto.setUltimaLeitura(ultima != null ? ultima.getMomento() : null);
                return dto;
            }).toList();

            response.setStatus(true);
            response.setDados(resultado);
            response.setMensagem("Status das Lixeiras retornado.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage() != null ? ex.getMessage() : "Erro ao buscar status das lixeiras");
        }
        return response;
    }

    @Override
    public ResponseModel<Integer> deleteTelemetriasAntigasAsync(LocalDateTime dataLimite) {
        ResponseModel<Integer> response = new ResponseModel<>();
        try {
            List<TelemetriasModel> telemetriasAntigas = telemetriasRepository.findByMomentoBefore(dataLimite);
            int count = telemetriasAntigas.size();
            telemetriasRepository.deleteAll(telemetriasAntigas);

            response.setStatus(true);
            response.setDados(count);
            response.setMensagem(count + " telemetrias antigas removidas.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }

    private TelemetriaStatsDTO buildStats(SensoresModel sensor, List<TelemetriasModel> telemetrias) {
        TelemetriaStatsDTO stats = new TelemetriaStatsDTO();
        stats.setSensorId(sensor.getId());
        stats.setNomeSensor(sensor.getNome());
        stats.setTotalLeituras(telemetrias.size());
        stats.setMediaOcupacao(mediaInteiros(telemetrias));
        stats.setMediaTemperatura(mediaTemperaturas(telemetrias));
        telemetrias.stream().max(Comparator.comparing(TelemetriasModel::getMomento, Comparator.nullsLast(Comparator.naturalOrder()))).ifPresent(t -> {
            stats.setNivelAtual(t.getNivelOcupacao());
            stats.setUltimaLeitura(t.getMomento());
        });
        stats.setAlertasCheio((int) telemetrias.stream().filter(t -> t.getNivelOcupacao() != null && t.getNivelOcupacao() >= 90).count());
        return stats;
    }

    private BigDecimal mediaInteiros(List<TelemetriasModel> telemetrias) {
        List<Integer> valores = telemetrias.stream().map(TelemetriasModel::getNivelOcupacao).filter(Objects::nonNull).toList();
        if (valores.isEmpty()) return null;
        double media = valores.stream().mapToInt(Integer::intValue).average().orElse(0);
        return BigDecimal.valueOf(media).setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal mediaTemperaturas(List<TelemetriasModel> telemetrias) {
        List<BigDecimal> valores = telemetrias.stream().map(TelemetriasModel::getTemperatura).filter(Objects::nonNull).toList();
        if (valores.isEmpty()) return null;
        BigDecimal soma = valores.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
        return soma.divide(BigDecimal.valueOf(valores.size()), 2, RoundingMode.HALF_UP);
    }

    private boolean sensorPertenceAoCondominio(Integer sensorId, Integer condominioId) {
        if (sensorId == null || condominioId == null) return false;
        return sensoresRepository.findById(sensorId)
                .map(sensor -> Objects.equals(sensor.getCondominioId(), condominioId))
                .orElse(false);
    }

    private LocalDateTime parseDate(String value) {
        try {
            return LocalDateTime.parse(value);
        } catch (DateTimeParseException ex) {
            return LocalDateTime.now();
        }
    }

    private boolean isNullOrWhiteSpace(String value) {
        return value == null || value.trim().isEmpty();
    }
}
