package com.ecobin.api.dto.telemetrias;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class TelemetriaArduinoDTO {
    private Integer sensorId;
    private float nivelLixo;
    private float temperatura;
    private float umidade;
    private float distancia;
    private Integer capacidade;
    private Boolean alertaCheio;
    private Integer bateria;
    private String dataHora;

    public TelemetriaArduinoDTO() {}

    public Integer getSensorId() { return sensorId; }
    public void setSensorId(Integer sensorId) { this.sensorId = sensorId; }

    public float getNivelLixo() { return nivelLixo; }
    public void setNivelLixo(float nivelLixo) { this.nivelLixo = nivelLixo; }

    public float getTemperatura() { return temperatura; }
    public void setTemperatura(float temperatura) { this.temperatura = temperatura; }

    public float getUmidade() { return umidade; }
    public void setUmidade(float umidade) { this.umidade = umidade; }

    public float getDistancia() { return distancia; }
    public void setDistancia(float distancia) { this.distancia = distancia; }

    public Integer getCapacidade() { return capacidade; }
    public void setCapacidade(Integer capacidade) { this.capacidade = capacidade; }

    public Boolean getAlertaCheio() { return alertaCheio; }
    public void setAlertaCheio(Boolean alertaCheio) { this.alertaCheio = alertaCheio; }

    public Integer getBateria() { return bateria; }
    public void setBateria(Integer bateria) { this.bateria = bateria; }

    public String getDataHora() { return dataHora; }
    public void setDataHora(String dataHora) { this.dataHora = dataHora; }

}
