package com.ecobin.api.repositories;

import com.ecobin.api.models.ProvisionSession;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ProvisionSessionRepository extends JpaRepository<ProvisionSession, Integer> {
    Optional<ProvisionSession> findByDeviceIdAndSessionToken(String deviceId, String sessionToken);
    Optional<ProvisionSession> findBySessionToken(String sessionToken);
}
