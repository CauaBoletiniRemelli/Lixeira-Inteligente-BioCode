package com.ecobin.api.services.usuarios;

import com.ecobin.api.dto.usuarios.ChangeEmailDTO;
import com.ecobin.api.dto.usuarios.ChangePasswordDTO;
import com.ecobin.api.dto.usuarios.UserCreateDTO;
import com.ecobin.api.dto.usuarios.UserEditDTO;
import com.ecobin.api.models.ResponseModel;
import com.ecobin.api.models.UsuariosModel;
import com.ecobin.api.repositories.UsuariosRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class UsuarioService implements IUsuarioInterface {
    private final UsuariosRepository usuariosRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioService(UsuariosRepository usuariosRepository, PasswordEncoder passwordEncoder) {
        this.usuariosRepository = usuariosRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public ResponseModel<UsuariosModel> getUserById(Integer idUsuario) {
        ResponseModel<UsuariosModel> response = new ResponseModel<>();
        try {
            UsuariosModel user = usuariosRepository.findById(idUsuario).orElse(null);
            if (user == null) {
                response.setMensagem("Usuário não encontrado.");
                response.setStatus(false);
                return response;
            }

            response.setDados(user);
            response.setMensagem("Usuário encontrado com sucesso.");
            response.setStatus(true);
            return response;
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
            return response;
        }
    }

    @Override
    public ResponseModel<List<UsuariosModel>> getUsers() {
        ResponseModel<List<UsuariosModel>> response = new ResponseModel<>();
        try {
            List<UsuariosModel> users = usuariosRepository.findAll();
            if (!users.isEmpty()) {
                response.setDados(users);
                response.setMensagem("Usuários encontrados com sucesso.");
                response.setStatus(true);
                return response;
            }

            response.setMensagem("Nenhum usuário encontrado.");
            response.setStatus(false);
            return response;
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
            return response;
        }
    }

    @Override
    public ResponseModel<UsuariosModel> createUser(UserCreateDTO dto) {
        ResponseModel<UsuariosModel> response = new ResponseModel<>();
        try {
            UsuariosModel usuario = new UsuariosModel();
            usuario.setNome(dto.getNome());
            usuario.setSenhaHash(dto.getSenhaHash());
            usuario.setEmail(dto.getEmail());
            usuario.setTipo(dto.getTipo());
            usuario.setCondominioId(dto.getCondominioId());
            usuario.setCriadoEm(LocalDateTime.now());

            usuario.setSenhaHash(passwordEncoder.encode(usuario.getSenhaHash()));
            usuariosRepository.save(usuario);

            response.setDados(usuario);
            response.setMensagem("Usuário criado com sucesso.");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }
        return response;
    }

    @Override
    public ResponseModel<UsuariosModel> updateUser(UserEditDTO dto) {
        ResponseModel<UsuariosModel> response = new ResponseModel<>();
        try {
            UsuariosModel user = usuariosRepository.findById(dto.getId()).orElse(null);
            if (user == null) {
                response.setMensagem("Nenhum usuário localizado!");
                response.setStatus(false);
                return response;
            }

            if (!isNullOrWhiteSpace(dto.getNome()) || !java.util.Objects.equals(user.getNome(), dto.getNome())) {
                user.setNome(dto.getNome());
            }
            if (!isNullOrWhiteSpace(dto.getEmail()) || !java.util.Objects.equals(user.getEmail(), dto.getEmail())) {
                user.setEmail(dto.getEmail());
            }
            if (dto.getTipo() != null || !java.util.Objects.equals(user.getTipo(), dto.getTipo())) {
                user.setTipo(dto.getTipo());
            }
            if (dto.getCondominioId() != null || !java.util.Objects.equals(user.getCondominioId(), dto.getCondominioId())) {
                user.setCondominioId(dto.getCondominioId());
            }
            if (!isNullOrWhiteSpace(dto.getSenhaHash())) {
                user.setSenhaHash(passwordEncoder.encode(dto.getSenhaHash()));
            }

            usuariosRepository.save(user);
            response.setDados(user);
            response.setMensagem("Usuário atualizado com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }
        return response;
    }

    @Override
    public ResponseModel<UsuariosModel> changePassword(ChangePasswordDTO dto) {
        ResponseModel<UsuariosModel> response = new ResponseModel<>();
        try {
            UsuariosModel user = usuariosRepository.findById(dto.getID()).orElse(null);
            if (user == null) {
                response.setMensagem("Nenhum usuário localizado!");
                response.setStatus(false);
                return response;
            }

            boolean isOldPasswordValid = passwordEncoder.matches(dto.getOldPassword(), user.getSenhaHash());
            if (!isOldPasswordValid) {
                response.setMensagem("Senha antiga incorreta!");
                response.setStatus(false);
                return response;
            }

            user.setSenhaHash(passwordEncoder.encode(dto.getNewPassword()));
            usuariosRepository.save(user);

            response.setDados(user);
            response.setMensagem("Senha alterada com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }
        return response;
    }

    @Override
    public ResponseModel<UsuariosModel> changeEmail(ChangeEmailDTO dto) {
        ResponseModel<UsuariosModel> response = new ResponseModel<>();
        try {
            UsuariosModel user = usuariosRepository.findById(dto.getID()).orElse(null);
            if (user == null) {
                response.setMensagem("Nenhum usuário localizado!");
                response.setStatus(false);
                return response;
            }

            boolean isOldEmailValid = java.util.Objects.equals(dto.getOldEmail(), user.getEmail());
            if (!isOldEmailValid) {
                response.setMensagem("E-mail antigo incorreto!");
                response.setStatus(false);
                return response;
            }

            user.setEmail(dto.getNewEmail());
            usuariosRepository.save(user);

            response.setDados(user);
            response.setMensagem("E-mail alterado com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }
        return response;
    }

    @Override
    public ResponseModel<List<UsuariosModel>> deleteUser(Integer idUser) {
        ResponseModel<List<UsuariosModel>> response = new ResponseModel<>();
        try {
            UsuariosModel user = usuariosRepository.findById(idUser).orElse(null);
            if (user == null) {
                response.setMensagem("Nenhum usuário localizado!");
                response.setStatus(false);
                return response;
            }

            usuariosRepository.delete(user);
            response.setDados(usuariosRepository.findAll());
            response.setMensagem("Usuário removido com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }
        return response;
    }

    private boolean isNullOrWhiteSpace(String value) {
        return value == null || value.trim().isEmpty();
    }
}
