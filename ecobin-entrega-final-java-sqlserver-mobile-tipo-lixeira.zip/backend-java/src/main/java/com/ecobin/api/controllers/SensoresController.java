package com.ecobin.api.controllers;

import com.ecobin.api.dto.sensores.*;
import com.ecobin.api.services.sensores.ISensoresInterface;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/Sensores")
public class SensoresController {
    private final ISensoresInterface sensores;

    public SensoresController(ISensoresInterface sensores) {
        this.sensores = sensores;
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @GetMapping
    public ResponseEntity<?> getSensores() {
        var response = sensores.getSensoresAsync();
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @PostMapping
    public ResponseEntity<?> createSensor(@RequestBody SensorCreateDTO dto) {
        var response = sensores.createSensorAsync(dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/{idCondominio}")
    public ResponseEntity<?> getSensoresByCondominio(@PathVariable Integer idCondominio) {
        var response = sensores.getSensoresByCondominioAsync(idCondominio);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @PutMapping
    public ResponseEntity<?> updateSensor(@RequestBody SensorEditDTO dto) {
        var response = sensores.updateSensorAsync(dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("isAuthenticated()")
    @PutMapping("/update-locale-{idSensor}")
    public ResponseEntity<?> updateSensorLocale(@PathVariable Integer idSensor, @RequestBody SensorEditLocaleDTO dto) {
        dto.setId(idSensor);
        var response = sensores.updateSensorLocaleAsync(dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @DeleteMapping("/{idSensor}")
    public ResponseEntity<?> deleteSensor(@PathVariable Integer idSensor) {
        var response = sensores.deleteSensorAsync(idSensor);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }
}
