package com.ecobin.api.dto.usuarios;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ChangePasswordDTO {
    private Integer iD;
    private String oldPassword;
    private String newPassword;

    public ChangePasswordDTO() {}

    public Integer getID() { return iD; }
    public void setID(Integer iD) { this.iD = iD; }

    public String getOldPassword() { return oldPassword; }
    public void setOldPassword(String oldPassword) { this.oldPassword = oldPassword; }

    public String getNewPassword() { return newPassword; }
    public void setNewPassword(String newPassword) { this.newPassword = newPassword; }

}
