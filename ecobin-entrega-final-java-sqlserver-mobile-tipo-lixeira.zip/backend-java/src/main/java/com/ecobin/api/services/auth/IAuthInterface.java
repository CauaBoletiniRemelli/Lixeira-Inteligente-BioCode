package com.ecobin.api.services.auth;

import com.ecobin.api.models.*;
import com.ecobin.api.requests.*;

public interface IAuthInterface {
    ResponseModel<AuthModel> appLogin(AppLoginRequest request);
    ResponseModel<AuthModel> arduinoLogin(ArduinoLoginRequest request);
    ResponseModel<AuthModel> login(LoginRequest request);
    ResponseModel<AuthModel> refreshToken(RefreshTokenRequest request);
    ResponseModel<Object> logout(RefreshTokenRequest request);
    ResponseModel<UsuariosModel> forgotPassword(String usuEmail);
}
