package com.ecobin.api.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "provision_sessions")
public class ProvisionSession {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String deviceId;
    @Column(unique = true)
    private String sessionToken;
    private String assignedWifiSSID;
    private String assignedWifiPassword;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime expiresAt;
    private LocalDateTime confirmedAt;
    private String deviceMac;
    private String firmware;
    @PrePersist public void prePersist(){ if(createdAt==null) createdAt=LocalDateTime.now(); if(status==null) status="PENDENTE"; }
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getDeviceId(){return deviceId;} public void setDeviceId(String deviceId){this.deviceId=deviceId;}
    public String getSessionToken(){return sessionToken;} public void setSessionToken(String sessionToken){this.sessionToken=sessionToken;}
    public String getAssignedWifiSSID(){return assignedWifiSSID;} public void setAssignedWifiSSID(String assignedWifiSSID){this.assignedWifiSSID=assignedWifiSSID;}
    public String getAssignedWifiPassword(){return assignedWifiPassword;} public void setAssignedWifiPassword(String assignedWifiPassword){this.assignedWifiPassword=assignedWifiPassword;}
    public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
    public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime createdAt){this.createdAt=createdAt;}
    public LocalDateTime getExpiresAt(){return expiresAt;} public void setExpiresAt(LocalDateTime expiresAt){this.expiresAt=expiresAt;}
    public LocalDateTime getConfirmedAt(){return confirmedAt;} public void setConfirmedAt(LocalDateTime confirmedAt){this.confirmedAt=confirmedAt;}
    public String getDeviceMac(){return deviceMac;} public void setDeviceMac(String deviceMac){this.deviceMac=deviceMac;}
    public String getFirmware(){return firmware;} public void setFirmware(String firmware){this.firmware=firmware;}
}
