package com.ecobin.api.controllers;

import com.ecobin.api.dto.usuarios.*;
import com.ecobin.api.models.*;
import com.ecobin.api.services.usuarios.IUsuarioInterface;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Usuarios")
public class UsuariosController {
    private final IUsuarioInterface usuarioInterface;

    public UsuariosController(IUsuarioInterface usuarioInterface) {
        this.usuarioInterface = usuarioInterface;
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping
    public ResponseEntity<ResponseModel<List<UsuariosModel>>> getUsers() {
        ResponseModel<List<UsuariosModel>> response = usuarioInterface.getUsers();
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/{idUser}")
    public ResponseEntity<ResponseModel<UsuariosModel>> getUserById(@PathVariable Integer idUser) {
        ResponseModel<UsuariosModel> response = usuarioInterface.getUserById(idUser);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @PostMapping
    public ResponseEntity<ResponseModel<UsuariosModel>> createUser(@RequestBody UserCreateDTO userCreateDTO) {
        ResponseModel<UsuariosModel> response = usuarioInterface.createUser(userCreateDTO);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @PutMapping
    public ResponseEntity<ResponseModel<UsuariosModel>> updateUser(@RequestBody UserEditDTO userEditDTO) {
        ResponseModel<UsuariosModel> response = usuarioInterface.updateUser(userEditDTO);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @DeleteMapping("/{idUser}")
    public ResponseEntity<ResponseModel<List<UsuariosModel>>> deleteUser(@PathVariable Integer idUser) {
        ResponseModel<List<UsuariosModel>> response = usuarioInterface.deleteUser(idUser);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/change-password")
    public ResponseEntity<ResponseModel<UsuariosModel>> changePassword(@RequestBody ChangePasswordDTO changePasswordDTO) {
        ResponseModel<UsuariosModel> response = usuarioInterface.changePassword(changePasswordDTO);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/change-email")
    public ResponseEntity<ResponseModel<UsuariosModel>> changeEmail(@RequestBody ChangeEmailDTO changeEmailDTO) {
        ResponseModel<UsuariosModel> response = usuarioInterface.changeEmail(changeEmailDTO);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }
}
