package com.ecobin.api.services.sensores;

import com.ecobin.api.dto.sensores.*;
import com.ecobin.api.models.*;
import java.util.List;

public interface ISensoresInterface {
    ResponseModel<SensoresModel> createSensorAsync(SensorCreateDTO dto);
    ResponseModel<SensoresModel> updateSensorAsync(SensorEditDTO dto);
    ResponseModel<SensoresModel> updateSensorLocaleAsync(SensorEditLocaleDTO dto);
    ResponseModel<List<SensoresModel>> deleteSensorAsync(Integer idSensor);
    ResponseModel<List<SensoresModel>> getSensoresAsync();
    ResponseModel<List<SensoresModel>> getSensoresByCondominioAsync(Integer condominioId);
    ResponseModel<SensoresModel> getSensorByDeviceIdAsync(String deviceId);
}
