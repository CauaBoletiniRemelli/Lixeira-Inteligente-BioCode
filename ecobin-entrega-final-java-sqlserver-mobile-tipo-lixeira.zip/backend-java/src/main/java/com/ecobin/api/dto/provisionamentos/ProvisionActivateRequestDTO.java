package com.ecobin.api.dto.provisionamentos;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ProvisionActivateRequestDTO {
    private String provisionId;
    private String deviceId;
    private String token;
    private Integer condominioId;
    private String nomeSensor;
    @JsonAlias({"Tipo", "tipoLixeira", "TipoLixeira"})
    private String tipo;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Integer usuarioId;
    private String wifiSSID;
    private String wifiPassword;

    public ProvisionActivateRequestDTO() {}

    public String getProvisionId() { return provisionId; }
    public void setProvisionId(String provisionId) { this.provisionId = provisionId; }

    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public Integer getCondominioId() { return condominioId; }
    public void setCondominioId(Integer condominioId) { this.condominioId = condominioId; }

    public String getNomeSensor() { return nomeSensor; }
    public void setNomeSensor(String nomeSensor) { this.nomeSensor = nomeSensor; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public BigDecimal getLatitude() { return latitude; }
    public void setLatitude(BigDecimal latitude) { this.latitude = latitude; }

    public BigDecimal getLongitude() { return longitude; }
    public void setLongitude(BigDecimal longitude) { this.longitude = longitude; }

    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer usuarioId) { this.usuarioId = usuarioId; }

    public String getWifiSSID() { return wifiSSID; }
    public void setWifiSSID(String wifiSSID) { this.wifiSSID = wifiSSID; }

    public String getWifiPassword() { return wifiPassword; }
    public void setWifiPassword(String wifiPassword) { this.wifiPassword = wifiPassword; }

}
