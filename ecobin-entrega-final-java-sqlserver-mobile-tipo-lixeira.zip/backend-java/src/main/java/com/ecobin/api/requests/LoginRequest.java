package com.ecobin.api.requests;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class LoginRequest {
    private String email;
    private String password;

    public LoginRequest() {}

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

}
