package com.ecobin.api.services.auth;

import com.ecobin.api.enums.TipoUsuario;
import com.ecobin.api.models.*;
import com.ecobin.api.repositories.*;
import com.ecobin.api.requests.*;
import com.ecobin.api.security.JwtService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.util.Map;

@Service
public class AuthService implements IAuthInterface {
    private final UsuariosRepository usuariosRepository;
    private final RefreshTokensRepository refreshTokensRepository;
    private final CondominiosRepository condominiosRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Value("${app.credentials.app-id:}")
    private String appId;

    @Value("${app.credentials.app-secret:}")
    private String appSecret;

    @Value("${arduino.credentials.arduino-id:}")
    private String arduinoId;

    @Value("${arduino.credentials.arduino-secret:}")
    private String arduinoSecret;

    public AuthService(
            UsuariosRepository usuariosRepository,
            RefreshTokensRepository refreshTokensRepository,
            CondominiosRepository condominiosRepository,
            PasswordEncoder passwordEncoder,
            JwtService jwtService
    ) {
        this.usuariosRepository = usuariosRepository;
        this.refreshTokensRepository = refreshTokensRepository;
        this.condominiosRepository = condominiosRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @Override
    public ResponseModel<AuthModel> appLogin(AppLoginRequest request) {
        ResponseModel<AuthModel> response = new ResponseModel<>();

        try {
            if (request == null
                    || isNullOrEmpty(request.getAppId())
                    || isNullOrEmpty(request.getAppSecret())
                    || !request.getAppId().equals(appId)
                    || !request.getAppSecret().equals(appSecret)) {

                response.setDados(null);
                response.setMensagem("Credenciais do aplicativo inválidas.");
                response.setStatus(false);
                return response;
            }

            UsuariosModel appUser = new UsuariosModel();
            appUser.setId(0);
            appUser.setEmail("app@ecobin.com");
            appUser.setNome("EcoBin Mobile App");
            appUser.setTipo(TipoUsuario.Aplicativo);
            appUser.setCondominioId(null);

            String token = jwtService.generateToken(appUser);
            String refreshToken = jwtService.generateRefreshToken();

            AuthModel authModel = new AuthModel();
            authModel.setToken(Map.of("token", token));
            authModel.setRefreshToken(refreshToken);
            authModel.setUserId(0);
            authModel.setEmail(appUser.getEmail());
            authModel.setNome(appUser.getNome());
            authModel.setTipo(TipoUsuario.Aplicativo);

            response.setDados(authModel);
            response.setMensagem("Autenticação do aplicativo realizada com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setDados(null);
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }

        return response;
    }

    @Override
    public ResponseModel<AuthModel> arduinoLogin(ArduinoLoginRequest request) {
        ResponseModel<AuthModel> response = new ResponseModel<>();

        try {
            if (request == null
                    || isNullOrEmpty(request.getArduinoId())
                    || isNullOrEmpty(request.getArduinoSecret())
                    || !request.getArduinoId().equals(arduinoId)
                    || !request.getArduinoSecret().equals(arduinoSecret)) {

                response.setDados(null);
                response.setMensagem("Credenciais do aplicativo inválidas.");
                response.setStatus(false);
                return response;
            }

            UsuariosModel appUser = new UsuariosModel();
            appUser.setId(0);
            appUser.setEmail("arduino@ecobin.com");
            appUser.setNome("EcoBin Arduino");
            appUser.setTipo(TipoUsuario.Arduino);
            appUser.setCondominioId(null);

            String token = jwtService.generateToken(appUser);
            String refreshToken = jwtService.generateRefreshToken();

            AuthModel authModel = new AuthModel();
            authModel.setToken(Map.of("token", token));
            authModel.setRefreshToken(refreshToken);
            authModel.setUserId(0);
            authModel.setEmail(appUser.getEmail());
            authModel.setNome(appUser.getNome());
            authModel.setTipo(TipoUsuario.Arduino);

            response.setDados(authModel);
            response.setMensagem("Autenticação do aplicativo realizada com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setDados(null);
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }

        return response;
    }

    @Override
    public ResponseModel<AuthModel> login(LoginRequest request) {
        ResponseModel<AuthModel> response = new ResponseModel<>();

        try {
            if (request == null || isNullOrEmpty(request.getEmail()) || isNullOrEmpty(request.getPassword())) {
                response.setDados(null);
                response.setMensagem("Email e senha são obrigatórios.");
                response.setStatus(false);
                return response;
            }

            UsuariosModel usuario = usuariosRepository.findByEmail(request.getEmail()).orElse(null);

            if (usuario == null
                    || isNullOrEmpty(usuario.getSenhaHash())
                    || !passwordEncoder.matches(request.getPassword(), usuario.getSenhaHash())) {

                response.setDados(null);
                response.setMensagem("E-mail ou senha incorretos.");
                response.setStatus(false);
                return response;
            }

            String token = jwtService.generateToken(usuario);
            String refreshToken = jwtService.generateRefreshToken();

            RefreshTokensModel refreshTokenModel = new RefreshTokensModel();
            refreshTokenModel.setUsuarioId(usuario.getId());
            refreshTokenModel.setToken(refreshToken);
            refreshTokenModel.setExpiracao(java.time.LocalDateTime.now().plusDays(7));

            refreshTokensRepository.save(refreshTokenModel);

            CondominiosModel condominio = null;
            if (usuario.getCondominioId() != null) {
                condominio = condominiosRepository.findById(usuario.getCondominioId()).orElse(null);
            }

            AuthModel authModel = new AuthModel();
            authModel.setToken(Map.of("token", token));
            authModel.setRefreshToken(refreshToken);
            authModel.setUserId(usuario.getId());
            authModel.setEmail(usuario.getEmail());
            authModel.setNome(usuario.getNome());
            authModel.setTipo(usuario.getTipo());
            authModel.setCondominioId(usuario.getCondominioId());
            authModel.setNomeCondominio(condominio != null ? condominio.getNome() : null);

            response.setDados(authModel);
            response.setMensagem("Login realizado com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setDados(null);
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }

        return response;
    }

    @Override
    public ResponseModel<AuthModel> refreshToken(RefreshTokenRequest request) {
        ResponseModel<AuthModel> response = new ResponseModel<>();

        if (request == null || isNullOrEmpty(request.getRefreshToken())) {
            response.setDados(null);
            response.setMensagem("Refresh token é obrigatório.");
            response.setStatus(false);
            return response;
        }

        try {
            RefreshTokensModel storedRefreshToken = refreshTokensRepository
                    .findByToken(request.getRefreshToken())
                    .orElse(null);

            if (storedRefreshToken == null) {
                response.setDados(null);
                response.setMensagem("Refresh token não encontrado.");
                response.setStatus(false);
                return response;
            }

            if (Boolean.TRUE.equals(storedRefreshToken.getRevogado())) {
                response.setDados(null);
                response.setMensagem("Refresh token já foi utilizado ou revogado. Faça login novamente.");
                response.setStatus(false);
                return response;
            }

            if (storedRefreshToken.getExpiracao() != null
                    && storedRefreshToken.getExpiracao().isBefore(java.time.LocalDateTime.now())) {

                response.setDados(null);
                response.setMensagem("Refresh token expirado. Faça login novamente.");
                response.setStatus(false);
                return response;
            }

            RefreshTokensModel ultimoRefreshToken = refreshTokensRepository
                    .findFirstByUsuarioIdAndRevogadoFalseOrderByCriadoEmDesc(storedRefreshToken.getUsuarioId())
                    .orElse(null);

            if (ultimoRefreshToken != null && !ultimoRefreshToken.getId().equals(storedRefreshToken.getId())) {
                response.setDados(null);
                response.setMensagem("Token não é o mais recente. Utilize o último refresh token recebido.");
                response.setStatus(false);
                return response;
            }

            if (!isNullOrEmpty(request.getAccessToken())) {
                try {
                    Integer tokenUserId = jwtService.getUserIdIgnoringExpiration(request.getAccessToken());
                    if (tokenUserId != null && !tokenUserId.equals(storedRefreshToken.getUsuarioId())) {
                        response.setDados(null);
                        response.setMensagem("Token não corresponde ao usuário.");
                        response.setStatus(false);
                        return response;
                    }
                } catch (Exception ignored) {
                }
            }

            UsuariosModel usuario = usuariosRepository.findById(storedRefreshToken.getUsuarioId()).orElse(null);

            if (usuario == null) {
                response.setDados(null);
                response.setMensagem("Usuário não encontrado.");
                response.setStatus(false);
                return response;
            }

            String newAccessToken = jwtService.generateToken(usuario);
            String newRefreshToken = jwtService.generateRefreshToken();

            storedRefreshToken.setRevogado(true);
            refreshTokensRepository.save(storedRefreshToken);

            RefreshTokensModel newRefreshTokenModel = new RefreshTokensModel();
            newRefreshTokenModel.setUsuarioId(storedRefreshToken.getUsuarioId());
            newRefreshTokenModel.setToken(newRefreshToken);
            newRefreshTokenModel.setExpiracao(java.time.LocalDateTime.now().plusDays(7));

            refreshTokensRepository.save(newRefreshTokenModel);

            CondominiosModel condominio = null;
            if (usuario.getCondominioId() != null) {
                condominio = condominiosRepository.findById(usuario.getCondominioId()).orElse(null);
            }

            AuthModel authModel = new AuthModel();
            authModel.setToken(Map.of("token", newAccessToken));
            authModel.setRefreshToken(newRefreshToken);
            authModel.setUserId(usuario.getId());
            authModel.setEmail(usuario.getEmail());
            authModel.setNome(usuario.getNome());
            authModel.setTipo(usuario.getTipo());
            authModel.setCondominioId(usuario.getCondominioId());
            authModel.setNomeCondominio(condominio != null ? condominio.getNome() : null);

            response.setDados(authModel);
            response.setMensagem("Token renovado com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setDados(null);
            response.setMensagem("Erro ao renovar token: " + ex.getMessage());
            response.setStatus(false);
        }

        return response;
    }

    @Override
    public ResponseModel<Object> logout(RefreshTokenRequest request) {
        ResponseModel<Object> response = new ResponseModel<>();

        if (request == null || isNullOrEmpty(request.getRefreshToken())) {
            response.setDados(null);
            response.setMensagem("Token é obrigatório.");
            response.setStatus(false);
            return response;
        }

        try {
            RefreshTokensModel storedRefreshToken = refreshTokensRepository
                    .findByToken(request.getRefreshToken())
                    .orElse(null);

            if (storedRefreshToken != null) {
                storedRefreshToken.setRevogado(true);
                refreshTokensRepository.save(storedRefreshToken);
            }

            response.setDados(null);
            response.setMensagem("Logout realizado com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setDados(null);
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }

        return response;
    }

    @Override
    public ResponseModel<UsuariosModel> forgotPassword(String usuEmail) {
        ResponseModel<UsuariosModel> response = new ResponseModel<>();

        try {
            UsuariosModel user = usuariosRepository.findByEmail(usuEmail).orElse(null);

            if (user == null) {
                response.setMensagem("Nenhum usuário localizado!");
                response.setStatus(true);
                return response;
            }

            String randomPassword = generateRandomPassword(6);

            user.setSenhaHash(passwordEncoder.encode(randomPassword));
            usuariosRepository.save(user);

            response.setDados(null);
            response.setMensagem("Instruções para redefinir a senha foram enviadas para o email cadastrado. Caso o e-mail não apareça, verifique sua caixa de SPAM");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }

        return response;
    }

    private String generateRandomPassword(int length) {
        final String validChars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*()?-";
        SecureRandom random = new SecureRandom();
        StringBuilder chars = new StringBuilder();

        for (int i = 0; i < length; i++) {
            chars.append(validChars.charAt(random.nextInt(validChars.length())));
        }

        return chars.toString();
    }

    private boolean isNullOrEmpty(String value) {
        return value == null || value.isEmpty();
    }
}
