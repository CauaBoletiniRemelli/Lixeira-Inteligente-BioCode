package com.ecobin.api.dto.telemetrias;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class TelemetriaListDTO {
    private Integer id;
    private Integer sensorId;
    private String nomeSensor;
    private LocalDateTime momento;
    private Integer nivelOcupacao;
    private Integer bateria;
    private BigDecimal temperatura;

    public TelemetriaListDTO() {}

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getSensorId() { return sensorId; }
    public void setSensorId(Integer sensorId) { this.sensorId = sensorId; }

    public String getNomeSensor() { return nomeSensor; }
    public void setNomeSensor(String nomeSensor) { this.nomeSensor = nomeSensor; }

    public LocalDateTime getMomento() { return momento; }
    public void setMomento(LocalDateTime momento) { this.momento = momento; }

    public Integer getNivelOcupacao() { return nivelOcupacao; }
    public void setNivelOcupacao(Integer nivelOcupacao) { this.nivelOcupacao = nivelOcupacao; }

    public Integer getBateria() { return bateria; }
    public void setBateria(Integer bateria) { this.bateria = bateria; }

    public BigDecimal getTemperatura() { return temperatura; }
    public void setTemperatura(BigDecimal temperatura) { this.temperatura = temperatura; }

}
