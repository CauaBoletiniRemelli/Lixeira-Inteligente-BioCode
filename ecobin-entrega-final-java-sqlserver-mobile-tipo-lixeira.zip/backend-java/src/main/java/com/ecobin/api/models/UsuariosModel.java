package com.ecobin.api.models;

import com.ecobin.api.enums.TipoUsuario;
import com.ecobin.api.enums.TipoUsuarioConverter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "USUarios")
public class UsuariosModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "USUNome", nullable = false, length = 100)
    private String nome;

    @Column(name = "USUEmail", nullable = false, length = 100, unique = true)
    private String email;

    @JsonIgnore
    @Column(name = "USUSenhaHash", nullable = false, length = 255)
    private String senhaHash;

    @Convert(converter = TipoUsuarioConverter.class)
    @Column(name = "USUTipo", nullable = false)
    private TipoUsuario tipo = TipoUsuario.NaoIdentificado;

    @Column(name = "USU_CONId")
    private Integer condominioId;

    @Column(name = "USUCriadoEm")
    private LocalDateTime criadoEm;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USU_CONId", insertable = false, updatable = false)
    @JsonIgnore
    private CondominiosModel condominio;

    @JsonIgnore
    @OneToMany(mappedBy = "usuario", fetch = FetchType.LAZY)
    private List<ProvisionamentosModel> provisionamentos = new ArrayList<>();

    @JsonIgnore
    @OneToMany(mappedBy = "usuario", fetch = FetchType.LAZY)
    private List<RefreshTokensModel> refreshTokens = new ArrayList<>();

    @JsonIgnore
    @OneToMany(mappedBy = "usuario", fetch = FetchType.LAZY)
    private List<ExpoTokensModel> expoTokens = new ArrayList<>();

    @PrePersist
    public void prePersist(){
        if(criadoEm==null) criadoEm=LocalDateTime.now();
        if(tipo==null) tipo=TipoUsuario.NaoIdentificado;
    }

    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
    public String getEmail(){return email;} public void setEmail(String email){this.email=email;}
    public String getSenhaHash(){return senhaHash;} public void setSenhaHash(String senhaHash){this.senhaHash=senhaHash;}
    public TipoUsuario getTipo(){return tipo;} public void setTipo(TipoUsuario tipo){this.tipo=tipo;}
    public Integer getCondominioId(){return condominioId;} public void setCondominioId(Integer condominioId){this.condominioId=condominioId;}
    public LocalDateTime getCriadoEm(){return criadoEm;} public void setCriadoEm(LocalDateTime criadoEm){this.criadoEm=criadoEm;}
    public CondominiosModel getCondominio(){return condominio;} public void setCondominio(CondominiosModel condominio){this.condominio=condominio;}
    public List<ProvisionamentosModel> getProvisionamentos(){return provisionamentos;} public void setProvisionamentos(List<ProvisionamentosModel> provisionamentos){this.provisionamentos=provisionamentos;}
    public List<RefreshTokensModel> getRefreshTokens(){return refreshTokens;} public void setRefreshTokens(List<RefreshTokensModel> refreshTokens){this.refreshTokens=refreshTokens;}
    public List<ExpoTokensModel> getExpoTokens(){return expoTokens;} public void setExpoTokens(List<ExpoTokensModel> expoTokens){this.expoTokens=expoTokens;}
}
