package com.ecobin.api.models;

import com.ecobin.api.enums.TipoUsuario;

public class AuthModel {
    private String email;
    private String nome;
    private Integer userId;
    private TipoUsuario tipo;
    private Integer condominioId;
    private String nomeCondominio;
    private Object token;
    private String refreshToken;
    public String getEmail(){return email;} public void setEmail(String email){this.email=email;}
    public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
    public Integer getUserId(){return userId;} public void setUserId(Integer userId){this.userId=userId;}
    public TipoUsuario getTipo(){return tipo;} public void setTipo(TipoUsuario tipo){this.tipo=tipo;}
    public Integer getCondominioId(){return condominioId;} public void setCondominioId(Integer condominioId){this.condominioId=condominioId;}
    public String getNomeCondominio(){return nomeCondominio;} public void setNomeCondominio(String nomeCondominio){this.nomeCondominio=nomeCondominio;}
    public Object getToken(){return token;} public void setToken(Object token){this.token=token;}
    public String getRefreshToken(){return refreshToken;} public void setRefreshToken(String refreshToken){this.refreshToken=refreshToken;}
}
