package com.ecobin.api.dto.telemetrias;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class TelemetriaFiltroDTO {
    private Integer sensorId;
    private Integer condominioId;
    private LocalDateTime dataInicio;
    private LocalDateTime dataFim;
    private Integer nivelMinimoOcupacao;
    private Integer nivelMaximoOcupacao;
    private Integer skip;
    private Integer take;

    public TelemetriaFiltroDTO() {}

    public Integer getSensorId() { return sensorId; }
    public void setSensorId(Integer sensorId) { this.sensorId = sensorId; }

    public Integer getCondominioId() { return condominioId; }
    public void setCondominioId(Integer condominioId) { this.condominioId = condominioId; }

    public LocalDateTime getDataInicio() { return dataInicio; }
    public void setDataInicio(LocalDateTime dataInicio) { this.dataInicio = dataInicio; }

    public LocalDateTime getDataFim() { return dataFim; }
    public void setDataFim(LocalDateTime dataFim) { this.dataFim = dataFim; }

    public Integer getNivelMinimoOcupacao() { return nivelMinimoOcupacao; }
    public void setNivelMinimoOcupacao(Integer nivelMinimoOcupacao) { this.nivelMinimoOcupacao = nivelMinimoOcupacao; }

    public Integer getNivelMaximoOcupacao() { return nivelMaximoOcupacao; }
    public void setNivelMaximoOcupacao(Integer nivelMaximoOcupacao) { this.nivelMaximoOcupacao = nivelMaximoOcupacao; }

    public Integer getSkip() { return skip; }
    public void setSkip(Integer skip) { this.skip = skip; }

    public Integer getTake() { return take; }
    public void setTake(Integer take) { this.take = take; }

}
