package com.ecobin.api.requests;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ArduinoLoginRequest {
    private String arduinoId;
    private String arduinoSecret;

    public ArduinoLoginRequest() {}

    public String getArduinoId() { return arduinoId; }
    public void setArduinoId(String arduinoId) { this.arduinoId = arduinoId; }

    public String getArduinoSecret() { return arduinoSecret; }
    public void setArduinoSecret(String arduinoSecret) { this.arduinoSecret = arduinoSecret; }

}
