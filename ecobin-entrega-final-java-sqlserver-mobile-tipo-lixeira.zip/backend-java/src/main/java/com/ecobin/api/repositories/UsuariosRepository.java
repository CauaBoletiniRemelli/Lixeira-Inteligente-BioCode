package com.ecobin.api.repositories;

import com.ecobin.api.models.UsuariosModel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UsuariosRepository extends JpaRepository<UsuariosModel, Integer> {
    Optional<UsuariosModel> findByEmail(String email);
}
