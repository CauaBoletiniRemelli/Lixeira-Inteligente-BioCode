package com.ecobin.api.controllers;

import com.ecobin.api.dto.telemetrias.*;
import com.ecobin.api.services.telemetrias.ITelemetriasInterface;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/Telemetrias")
@PreAuthorize("isAuthenticated()")
public class TelemetriasController {
    private final ITelemetriasInterface telemetrias;

    public TelemetriasController(ITelemetriasInterface telemetrias) {
        this.telemetrias = telemetrias;
    }

    @PostMapping
    public ResponseEntity<?> createTelemetria(@RequestBody TelemetriaCreateDTO dto) {
        var response = telemetrias.createTelemetriaAsync(dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PostMapping("/arduino")
    public ResponseEntity<?> createTelemetriaArduino(@RequestBody TelemetriaArduinoDTO dto) {
        var response = telemetrias.createTelemetriaArduinoAsync(dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @GetMapping
    public ResponseEntity<?> getTelemetrias() {
        var response = telemetrias.getTelemetriasAsync();
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PostMapping("/filtrar")
    public ResponseEntity<?> getTelemetriasFiltro(@RequestBody TelemetriaFiltroDTO filtro) {
        var response = telemetrias.getTelemetriasFiltroAsync(filtro);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @GetMapping("/sensor/{sensorId}")
    public ResponseEntity<?> getTelemetriasBySensor(@PathVariable Integer sensorId, @RequestParam(defaultValue = "100") int limit) {
        var response = telemetrias.getTelemetriasBySensorAsync(sensorId, limit);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @GetMapping("/sensor/{sensorId}/ultima")
    public ResponseEntity<?> getUltimaTelemetria(@PathVariable Integer sensorId) {
        var response = telemetrias.getUltimaTelemetriaAsync(sensorId);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.status(404).body(response);
    }

    @GetMapping("/condominio/{condominioId}")
    public ResponseEntity<?> getTelemetriasByCondominio(@PathVariable Integer condominioId) {
        var response = telemetrias.getTelemetriasByCondominioAsync(condominioId);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @GetMapping("/sensor/{sensorId}/estatisticas")
    public ResponseEntity<?> getEstatisticasSensor(
        @PathVariable Integer sensorId,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataInicio,
        @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataFim) {
        var response = telemetrias.getEstatisticasSensorAsync(sensorId, dataInicio, dataFim);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @GetMapping("/condominio/{condominioId}/estatisticas")
    public ResponseEntity<?> getEstatisticasCondominio(@PathVariable Integer condominioId) {
        var response = telemetrias.getEstatisticasCondominioAsync(condominioId);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }


    @GetMapping({"/condominio/{condominioId}/status-lixeiras", "/status-lixeiras/{condominioId}"})
    public ResponseEntity<?> getStatusLixeiras(@PathVariable Integer condominioId) {
        var response = telemetrias.getStatusLixeirasAsync(condominioId);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @DeleteMapping("/limpeza")
    public ResponseEntity<?> deleteTelemetriasAntigas(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataLimite) {
        var response = telemetrias.deleteTelemetriasAntigasAsync(dataLimite);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }
}
