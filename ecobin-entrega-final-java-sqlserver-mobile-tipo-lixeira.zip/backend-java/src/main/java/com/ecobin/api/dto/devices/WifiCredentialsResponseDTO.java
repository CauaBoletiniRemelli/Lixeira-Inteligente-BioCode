package com.ecobin.api.dto.devices;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class WifiCredentialsResponseDTO {
    private String sSID;
    private String password;
    private LocalDateTime sessionExpires;
    private String deviceId;

    public WifiCredentialsResponseDTO() {}

    public String getSSID() { return sSID; }
    public void setSSID(String sSID) { this.sSID = sSID; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public LocalDateTime getSessionExpires() { return sessionExpires; }
    public void setSessionExpires(LocalDateTime sessionExpires) { this.sessionExpires = sessionExpires; }

    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public String getSsid() { return sSID; }
    public void setSsid(String ssid) { this.sSID = ssid; }
}
