package com.ecobin.api.services.condominio;

import com.ecobin.api.dto.condominios.*;
import com.ecobin.api.models.*;
import java.util.List;

public interface ICondominioInterface {
    ResponseModel<List<CondominiosModel>> getCondominios();
    ResponseModel<CondominiosModel> createCondominio(CondominiosCreateDTO condominio);
    ResponseModel<CondominiosModel> updateCondominio(CondominioEditDTO condominio);
    ResponseModel<List<CondominiosModel>> deleteCondominio(Integer idCond);
}
