package com.ecobin.api.dto.provisionamentos;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ConfirmConfigDTO {
    private String sessionToken;
    private Boolean success;
    private String message;

    public ConfirmConfigDTO() {}

    public String getSessionToken() { return sessionToken; }
    public void setSessionToken(String sessionToken) { this.sessionToken = sessionToken; }

    public Boolean getSuccess() { return success; }
    public void setSuccess(Boolean success) { this.success = success; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

}
