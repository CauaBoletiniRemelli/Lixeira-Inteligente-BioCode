package com.ecobin.api.services.usuarios;

import com.ecobin.api.dto.usuarios.*;
import com.ecobin.api.models.*;
import java.util.List;

public interface IUsuarioInterface {
    ResponseModel<List<UsuariosModel>> getUsers();
    ResponseModel<UsuariosModel> getUserById(Integer idUsuario);
    ResponseModel<UsuariosModel> createUser(UserCreateDTO userCreateDTO);
    ResponseModel<UsuariosModel> updateUser(UserEditDTO userEditDTO);
    ResponseModel<UsuariosModel> changePassword(ChangePasswordDTO changePasswordDTO);
    ResponseModel<UsuariosModel> changeEmail(ChangeEmailDTO changeEmailDTO);
    ResponseModel<List<UsuariosModel>> deleteUser(Integer idUser);
}
