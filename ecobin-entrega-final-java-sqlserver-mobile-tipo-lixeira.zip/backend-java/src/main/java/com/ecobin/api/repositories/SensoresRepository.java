package com.ecobin.api.repositories;

import com.ecobin.api.models.SensoresModel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface SensoresRepository extends JpaRepository<SensoresModel, Integer> {
    List<SensoresModel> findByCondominioId(Integer condominioId);
    Optional<SensoresModel> findByDeviceId(String deviceId);
}
