package com.ecobin.api.security;

import com.ecobin.api.models.UsuariosModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;

@Service
public class JwtService {
    @Value("${app.jwt.secret}")
    private String secret;

    @Value("${app.jwt.expiration-minutes}")
    private long expirationMinutes;

    public String generateToken(UsuariosModel user) {
        long exp = Instant.now().plusSeconds(expirationMinutes * 60).getEpochSecond();
        int tipo = user.getTipo() == null ? 0 : user.getTipo().getValor();
        String header = base64Url("{\"alg\":\"HS256\",\"typ\":\"JWT\"}");
        String payload = String.format("{\"userId\":%d,\"Tipo\":\"%d\",\"sub\":\"%s\",\"exp\":%d}",
                user.getId(), tipo, escape(user.getEmail()), exp);
        String body = header + "." + base64Url(payload);
        return body + "." + sign(body);
    }

    public String generateRefreshToken() {
        byte[] randomNumber = new byte[64];
        new SecureRandom().nextBytes(randomNumber);
        return Base64.getEncoder().encodeToString(randomNumber);
    }

    public Integer getUserId(String token) {
        if (!isValid(token)) return null;
        return getUserIdIgnoringExpiration(token);
    }

    public Integer getUserIdIgnoringExpiration(String token) {
        if (!hasValidSignature(token)) return null;
        try {
            String json = new String(Base64.getUrlDecoder().decode(token.split("\\.")[1]), StandardCharsets.UTF_8);
            return Integer.parseInt(extractNumber(json, "userId"));
        } catch (Exception e) {
            return null;
        }
    }

    public Integer getTipo(String token) {
        if (!isValid(token)) return null;
        return getTipoIgnoringExpiration(token);
    }

    public Integer getTipoIgnoringExpiration(String token) {
        if (!hasValidSignature(token)) return null;
        try {
            String json = new String(Base64.getUrlDecoder().decode(token.split("\\.")[1]), StandardCharsets.UTF_8);
            String tipo = extractString(json, "Tipo");
            if (tipo == null || tipo.isBlank()) tipo = extractNumber(json, "Tipo");
            return Integer.parseInt(tipo);
        } catch (Exception e) {
            return null;
        }
    }

    public String getSubject(String token) {
        if (!isValid(token)) return null;
        String json = new String(Base64.getUrlDecoder().decode(token.split("\\.")[1]), StandardCharsets.UTF_8);
        return extractString(json, "sub");
    }

    public boolean isValid(String token) {
        try {
            if (!hasValidSignature(token)) return false;
            String json = new String(Base64.getUrlDecoder().decode(token.split("\\.")[1]), StandardCharsets.UTF_8);
            long exp = Long.parseLong(extractNumber(json, "exp"));
            return Instant.now().getEpochSecond() < exp;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean hasValidSignature(String token) {
        try {
            if (token == null || token.isBlank()) return false;
            String[] parts = token.split("\\.");
            if (parts.length != 3) return false;
            String body = parts[0] + "." + parts[1];
            return sign(body).equals(parts[2]);
        } catch (Exception e) {
            return false;
        }
    }

    private String sign(String data) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String base64Url(String value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private String escape(String value) {
        return value == null ? "" : value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String extractString(String json, String key) {
        String marker = "\"" + key + "\":\"";
        int start = json.indexOf(marker);
        if (start < 0) return null;
        start += marker.length();
        int end = json.indexOf("\"", start);
        return end < 0 ? null : json.substring(start, end);
    }

    private String extractNumber(String json, String key) {
        String marker = "\"" + key + "\":";
        int start = json.indexOf(marker);
        if (start < 0) return "0";
        start += marker.length();
        int end = start;
        while (end < json.length() && Character.isDigit(json.charAt(end))) end++;
        return json.substring(start, end);
    }
}
