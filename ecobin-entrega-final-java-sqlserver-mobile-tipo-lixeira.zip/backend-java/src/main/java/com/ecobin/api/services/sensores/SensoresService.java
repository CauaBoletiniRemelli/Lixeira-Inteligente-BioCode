package com.ecobin.api.services.sensores;

import com.ecobin.api.dto.sensores.SensorCreateDTO;
import com.ecobin.api.dto.sensores.SensorEditDTO;
import com.ecobin.api.dto.sensores.SensorEditLocaleDTO;
import com.ecobin.api.models.CondominiosModel;
import com.ecobin.api.models.ResponseModel;
import com.ecobin.api.models.SensoresModel;
import com.ecobin.api.repositories.CondominiosRepository;
import com.ecobin.api.repositories.SensoresRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class SensoresService implements ISensoresInterface {
    private final SensoresRepository sensoresRepository;
    private final CondominiosRepository condominiosRepository;

    public SensoresService(SensoresRepository sensoresRepository, CondominiosRepository condominiosRepository) {
        this.sensoresRepository = sensoresRepository;
        this.condominiosRepository = condominiosRepository;
    }

    @Override
    public ResponseModel<SensoresModel> createSensorAsync(SensorCreateDTO dto) {
        ResponseModel<SensoresModel> response = new ResponseModel<>();
        try {
            SensoresModel sensor = new SensoresModel();
            sensor.setDeviceId(dto.getDeviceId());
            sensor.setDeviceKey(dto.getDeviceKey() != null ? dto.getDeviceKey() : UUID.randomUUID().toString().replace("-", ""));
            sensor.setCondominioId(dto.getCondominioId());
            sensor.setNome(dto.getNome());
            sensor.setTipo(defaultTipo(dto.getTipo()));
            sensor.setLatitude(dto.getLatitude());
            sensor.setLongitude(dto.getLongitude());
            sensor.setStatus(0);
            sensor.setCriadoEm(LocalDateTime.now());

            sensoresRepository.save(sensor);
            response.setStatus(true);
            response.setMensagem("Sensor criado com sucesso.");
            response.setDados(sensor);
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<SensoresModel> updateSensorAsync(SensorEditDTO dto) {
        SensoresModel sensor = sensoresRepository.findById(dto.getId()).orElse(null);
        if (sensor == null) {
            return ResponseModel.erro("Sensor não encontrado.");
        }

        if (!isNullOrWhiteSpace(dto.getNome())) sensor.setNome(dto.getNome());
        if (!isNullOrWhiteSpace(dto.getTipo())) sensor.setTipo(dto.getTipo());
        if (dto.getStatus() != null) sensor.setStatus(dto.getStatus());
        if (dto.getCondominioId() != null) sensor.setCondominioId(dto.getCondominioId());
        if (dto.getLatitude() != null) sensor.setLatitude(dto.getLatitude());
        if (dto.getLongitude() != null) sensor.setLongitude(dto.getLongitude());

        sensoresRepository.save(sensor);
        return ResponseModel.ok(sensor, "Sensor atualizado com sucesso.");
    }

    @Override
    public ResponseModel<SensoresModel> updateSensorLocaleAsync(SensorEditLocaleDTO dto) {
        SensoresModel sensor = sensoresRepository.findById(dto.getId()).orElse(null);
        if (sensor == null) {
            return ResponseModel.erro("Sensor não encontrado.");
        }

        if (dto.getLatitude() != null) sensor.setLatitude(dto.getLatitude());
        if (dto.getLongitude() != null) sensor.setLongitude(dto.getLongitude());

        sensoresRepository.save(sensor);
        return ResponseModel.ok(sensor, "Sensor atualizado com sucesso.");
    }

    @Override
    public ResponseModel<List<SensoresModel>> deleteSensorAsync(Integer idSensor) {
        SensoresModel sensor = sensoresRepository.findById(idSensor).orElse(null);
        if (sensor == null) {
            return ResponseModel.erro("Sensor não encontrado.");
        }

        sensoresRepository.delete(sensor);
        ResponseModel<List<SensoresModel>> response = new ResponseModel<>();
        response.setStatus(true);
        response.setMensagem("Sensor removido.");
        response.setDados(null);
        return response;
    }

    @Override
    public ResponseModel<List<SensoresModel>> getSensoresAsync() {
        List<SensoresModel> sensores = sensoresRepository.findAll().stream()
                .filter(sensor -> {
                    if (sensor.getCondominioId() == null) return false;
                    CondominiosModel condominio = condominiosRepository.findById(sensor.getCondominioId()).orElse(null);
                    return condominio != null && Boolean.TRUE.equals(condominio.getAtivo());
                })
                .toList();

        return ResponseModel.ok(sensores, "Lista de sensores retornada.");
    }

    @Override
    public ResponseModel<List<SensoresModel>> getSensoresByCondominioAsync(Integer condominioId) {
        List<SensoresModel> sensores = sensoresRepository.findByCondominioId(condominioId);
        return ResponseModel.ok(sensores, "Sensores do condomínio retornados.");
    }

    @Override
    public ResponseModel<SensoresModel> getSensorByDeviceIdAsync(String deviceId) {
        SensoresModel sensor = sensoresRepository.findByDeviceId(deviceId).orElse(null);
        if (sensor == null) {
            return ResponseModel.erro("Sensor não encontrado.");
        }

        ResponseModel<SensoresModel> response = new ResponseModel<>();
        response.setStatus(true);
        response.setDados(sensor);
        return response;
    }

    private String defaultTipo(String value) {
        return isNullOrWhiteSpace(value) ? "Comum" : value.trim();
    }

    private boolean isNullOrWhiteSpace(String value) {
        return value == null || value.trim().isEmpty();
    }
}
