package com.ecobin.api.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "EXPoTokens")
public class ExpoTokensModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "EXP_USUId", nullable = false)
    private Integer usuarioId;

    @Column(name = "EXPToken", nullable = false, length = 500)
    private String token;

    @Column(name = "EXPDispositivo", length = 255)
    private String dispositivo;

    @Column(name = "EXPPlataforma", length = 50)
    private String plataforma;

    @Column(name = "EXPDataCriacao")
    private LocalDateTime dataCriacao;

    @Column(name = "EXPUltimaAtualizacao")
    private LocalDateTime ultimaAtualizacao;

    @Column(name = "EXPAtivo")
    private Boolean ativo = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EXP_USUId", insertable = false, updatable = false)
    @JsonIgnore
    private UsuariosModel usuario;

    @JsonIgnore
    @OneToMany(mappedBy = "expoToken", fetch = FetchType.LAZY)
    private List<NotificacoesModel> notificacoes = new ArrayList<>();

    @PrePersist public void prePersist(){ if(dataCriacao==null) dataCriacao=LocalDateTime.now(); if(ativo==null) ativo=true; }
    @PreUpdate public void preUpdate(){ ultimaAtualizacao=LocalDateTime.now(); }

    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Integer getUsuarioId(){return usuarioId;} public void setUsuarioId(Integer usuarioId){this.usuarioId=usuarioId;}
    public String getToken(){return token;} public void setToken(String token){this.token=token;}
    public String getDispositivo(){return dispositivo;} public void setDispositivo(String dispositivo){this.dispositivo=dispositivo;}
    public String getPlataforma(){return plataforma;} public void setPlataforma(String plataforma){this.plataforma=plataforma;}
    public LocalDateTime getDataCriacao(){return dataCriacao;} public void setDataCriacao(LocalDateTime dataCriacao){this.dataCriacao=dataCriacao;}
    public LocalDateTime getUltimaAtualizacao(){return ultimaAtualizacao;} public void setUltimaAtualizacao(LocalDateTime ultimaAtualizacao){this.ultimaAtualizacao=ultimaAtualizacao;}
    public Boolean getAtivo(){return ativo;} public void setAtivo(Boolean ativo){this.ativo=ativo;}
    public UsuariosModel getUsuario(){return usuario;} public void setUsuario(UsuariosModel usuario){this.usuario=usuario;}
    public List<NotificacoesModel> getNotificacoes(){return notificacoes;} public void setNotificacoes(List<NotificacoesModel> notificacoes){this.notificacoes=notificacoes;}
}
