package com.ecobin.api.dto.sensores;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class SensorEditDTO {
    private Integer id;
    private String nome;
    @JsonAlias({"Tipo", "tipoLixeira", "TipoLixeira"})
    private String tipo;
    private Integer status;
    private Integer condominioId;
    private BigDecimal latitude;
    private BigDecimal longitude;

    public SensorEditDTO() {}

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }

    public Integer getCondominioId() { return condominioId; }
    public void setCondominioId(Integer condominioId) { this.condominioId = condominioId; }

    public BigDecimal getLatitude() { return latitude; }
    public void setLatitude(BigDecimal latitude) { this.latitude = latitude; }

    public BigDecimal getLongitude() { return longitude; }
    public void setLongitude(BigDecimal longitude) { this.longitude = longitude; }

}
