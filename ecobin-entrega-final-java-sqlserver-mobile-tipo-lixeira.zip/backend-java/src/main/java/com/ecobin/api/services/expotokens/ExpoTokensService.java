package com.ecobin.api.services.expotokens;

import com.ecobin.api.dto.expotokens.ExpoTokenCreateDTO;
import com.ecobin.api.dto.expotokens.NotificacaoCondominioTipoDTO;
import com.ecobin.api.dto.expotokens.NotificacaoCreateDTO;
import com.ecobin.api.dto.expotokens.NotificacaoEnviarDTO;
import com.ecobin.api.models.ExpoTokensModel;
import com.ecobin.api.models.NotificacoesModel;
import com.ecobin.api.models.ResponseModel;
import com.ecobin.api.models.UsuariosModel;
import com.ecobin.api.repositories.ExpoTokensRepository;
import com.ecobin.api.repositories.NotificacoesRepository;
import com.ecobin.api.repositories.UsuariosRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

@Service
public class ExpoTokensService implements IExpoTokensInterface {
    private final ExpoTokensRepository expoTokensRepository;
    private final NotificacoesRepository notificacoesRepository;
    private final UsuariosRepository usuariosRepository;

    public ExpoTokensService(ExpoTokensRepository expoTokensRepository,
                             NotificacoesRepository notificacoesRepository,
                             UsuariosRepository usuariosRepository) {
        this.expoTokensRepository = expoTokensRepository;
        this.notificacoesRepository = notificacoesRepository;
        this.usuariosRepository = usuariosRepository;
    }

    @Override
    public ResponseModel<ExpoTokensModel> salvarTokenAsync(ExpoTokenCreateDTO dto) {
        ResponseModel<ExpoTokensModel> response = new ResponseModel<>();
        try {
            ExpoTokensModel tokenExistente = expoTokensRepository
                    .findFirstByUsuarioIdAndDispositivoAndAtivoTrue(dto.getUsuarioId(), dto.getDispositivo())
                    .orElse(null);

            if (tokenExistente != null) {
                tokenExistente.setToken(dto.getToken());
                tokenExistente.setPlataforma(dto.getPlataforma());
                tokenExistente.setUltimaAtualizacao(LocalDateTime.now());
                expoTokensRepository.save(tokenExistente);

                response.setDados(tokenExistente);
                response.setMensagem("Token atualizado com sucesso!");
            } else {
                ExpoTokensModel novoToken = new ExpoTokensModel();
                novoToken.setUsuarioId(dto.getUsuarioId());
                novoToken.setToken(dto.getToken());
                novoToken.setDispositivo(dto.getDispositivo());
                novoToken.setPlataforma(dto.getPlataforma());
                novoToken.setDataCriacao(LocalDateTime.now());
                novoToken.setAtivo(true);

                expoTokensRepository.save(novoToken);
                response.setDados(novoToken);
                response.setMensagem("Token salvo com sucesso!");
            }

            response.setStatus(true);
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao salvar token: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<List<ExpoTokensModel>> listarTokensPorUsuarioAsync(Integer usuarioId) {
        ResponseModel<List<ExpoTokensModel>> response = new ResponseModel<>();
        try {
            List<ExpoTokensModel> tokens = expoTokensRepository.findByUsuarioIdAndAtivoTrue(usuarioId).stream()
                    .sorted(Comparator.comparing(t -> t.getUltimaAtualizacao() != null ? t.getUltimaAtualizacao() : t.getDataCriacao(), Comparator.nullsLast(Comparator.naturalOrder())).reversed())
                    .toList();
            response.setDados(tokens);
            response.setStatus(true);
            response.setMensagem(tokens.size() + " token(s) encontrado(s).");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao listar tokens: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<ExpoTokensModel> desativarTokenAsync(Integer tokenId) {
        ResponseModel<ExpoTokensModel> response = new ResponseModel<>();
        try {
            ExpoTokensModel token = expoTokensRepository.findById(tokenId).orElse(null);
            if (token == null) {
                response.setStatus(false);
                response.setMensagem("Token não encontrado.");
                return response;
            }

            token.setAtivo(false);
            token.setUltimaAtualizacao(LocalDateTime.now());
            expoTokensRepository.save(token);

            response.setDados(token);
            response.setStatus(true);
            response.setMensagem("Token desativado com sucesso!");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao desativar token: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<List<NotificacoesModel>> enviarNotificacaoParaTodosAsync(NotificacaoCreateDTO dto) {
        ResponseModel<List<NotificacoesModel>> response = new ResponseModel<>();
        try {
            List<ExpoTokensModel> tokens = expoTokensRepository.findByAtivoTrue();
            if (tokens.isEmpty()) {
                response.setStatus(false);
                response.setMensagem("Nenhum token ativo encontrado.");
                return response;
            }

            List<NotificacoesModel> notificacoes = new ArrayList<>();
            for (ExpoTokensModel token : tokens) {
                notificacoes.add(criarNotificacao(token.getId(), token.getUsuarioId(), dto.getTitulo(), dto.getMensagem(), dto.getDados()));
            }
            notificacoesRepository.saveAll(notificacoes);

            response.setDados(notificacoes);
            response.setStatus(true);
            response.setMensagem(notificacoes.size() + " notificação(ões) processada(s)!");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao enviar notificações: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<List<NotificacoesModel>> enviarNotificacaoParaUsuariosAsync(NotificacaoEnviarDTO dto) {
        ResponseModel<List<NotificacoesModel>> response = new ResponseModel<>();
        try {
            if (dto.getUsuarioIds() == null || dto.getUsuarioIds().isEmpty()) {
                NotificacaoCreateDTO createDTO = new NotificacaoCreateDTO();
                createDTO.setTitulo(dto.getTitulo());
                createDTO.setMensagem(dto.getMensagem());
                createDTO.setDados(dto.getDados());
                return enviarNotificacaoParaTodosAsync(createDTO);
            }

            List<ExpoTokensModel> tokens = expoTokensRepository.findByAtivoTrue().stream()
                    .filter(t -> dto.getUsuarioIds().contains(t.getUsuarioId()))
                    .toList();

            if (tokens.isEmpty()) {
                response.setStatus(false);
                response.setMensagem("Nenhum token ativo encontrado para os usuários especificados.");
                return response;
            }

            List<NotificacoesModel> notificacoes = new ArrayList<>();
            for (ExpoTokensModel token : tokens) {
                notificacoes.add(criarNotificacao(token.getId(), token.getUsuarioId(), dto.getTitulo(), dto.getMensagem(), dto.getDados()));
            }
            notificacoesRepository.saveAll(notificacoes);

            response.setDados(notificacoes);
            response.setStatus(true);
            response.setMensagem(notificacoes.size() + " notificação(ões) enviada(s)!");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao enviar notificações: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<NotificacoesModel> enviarNotificacaoParaUsuarioAsync(Integer usuarioId, NotificacaoCreateDTO dto) {
        ResponseModel<NotificacoesModel> response = new ResponseModel<>();
        try {
            List<ExpoTokensModel> tokens = expoTokensRepository.findByUsuarioIdAndAtivoTrue(usuarioId);
            if (tokens.isEmpty()) {
                response.setStatus(false);
                response.setMensagem("Nenhum token ativo encontrado para o usuário especificado.");
                return response;
            }

            ExpoTokensModel token = tokens.get(0);
            NotificacoesModel notificacao = criarNotificacao(token.getId(), usuarioId, dto.getTitulo(), dto.getMensagem(), dto.getDados());
            notificacoesRepository.save(notificacao);

            response.setDados(notificacao);
            response.setStatus(true);
            response.setMensagem("Notificação enviada com sucesso!");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao enviar notificação: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<List<NotificacoesModel>> enviarNotificacaoParaCondominioAsync(Integer condominioId, NotificacaoCreateDTO dto) {
        NotificacaoCondominioTipoDTO filtro = new NotificacaoCondominioTipoDTO();
        filtro.setCondominioId(condominioId);
        filtro.setTitulo(dto.getTitulo());
        filtro.setMensagem(dto.getMensagem());
        filtro.setDados(dto.getDados());
        return enviarNotificacaoParaCondominioTipoAsync(filtro);
    }

    @Override
    public ResponseModel<List<NotificacoesModel>> enviarNotificacaoParaCondominioTipoAsync(NotificacaoCondominioTipoDTO dto) {
        ResponseModel<List<NotificacoesModel>> response = new ResponseModel<>();
        try {
            List<Integer> usuarioIds = usuariosRepository.findAll().stream()
                    .filter(u -> dto.getCondominioId() == null || Objects.equals(u.getCondominioId(), dto.getCondominioId()))
                    .filter(u -> dto.getTipoUsuario() == null || Objects.equals(u.getTipo(), dto.getTipoUsuario()))
                    .map(UsuariosModel::getId)
                    .toList();

            List<ExpoTokensModel> tokens = expoTokensRepository.findByAtivoTrue().stream()
                    .filter(t -> usuarioIds.contains(t.getUsuarioId()))
                    .toList();

            if (tokens.isEmpty()) {
                response.setStatus(false);
                response.setMensagem("Nenhum token ativo encontrado.");
                return response;
            }

            List<NotificacoesModel> notificacoes = tokens.stream()
                    .map(t -> criarNotificacao(t.getId(), t.getUsuarioId(), dto.getTitulo(), dto.getMensagem(), dto.getDados()))
                    .toList();
            notificacoesRepository.saveAll(notificacoes);

            response.setDados(notificacoes);
            response.setStatus(true);
            response.setMensagem(notificacoes.size() + " notificação(ões) processada(s)!");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao enviar notificações: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<List<NotificacoesModel>> listarNotificacoesPorUsuarioAsync(Integer usuarioId) {
        ResponseModel<List<NotificacoesModel>> response = new ResponseModel<>();
        try {
            List<NotificacoesModel> notificacoes = notificacoesRepository.findByUsuarioIdOrderByDataEnvioDesc(usuarioId);
            response.setDados(notificacoes);
            response.setStatus(true);
            response.setMensagem(notificacoes.size() + " notificação(ões) encontrada(s).");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao listar notificações: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<List<NotificacoesModel>> listarNotificacoesNaoLidasAsync(Integer usuarioId) {
        ResponseModel<List<NotificacoesModel>> response = new ResponseModel<>();
        try {
            List<NotificacoesModel> notificacoes = notificacoesRepository.findByUsuarioIdAndLidaFalseOrderByDataEnvioDesc(usuarioId);
            response.setDados(notificacoes);
            response.setStatus(true);
            response.setMensagem(notificacoes.size() + " notificação(ões) não lida(s).");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao listar notificações: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<NotificacoesModel> marcarComoLidaAsync(Integer notificacaoId) {
        ResponseModel<NotificacoesModel> response = new ResponseModel<>();
        try {
            NotificacoesModel notificacao = notificacoesRepository.findById(notificacaoId).orElse(null);
            if (notificacao == null) {
                response.setStatus(false);
                response.setMensagem("Notificação não encontrada.");
                return response;
            }

            notificacao.setLida(true);
            notificacao.setDataLeitura(LocalDateTime.now());
            notificacoesRepository.save(notificacao);

            response.setDados(notificacao);
            response.setStatus(true);
            response.setMensagem("Notificação marcada como lida.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao marcar notificação: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<Boolean> marcarTodasComoLidasAsync(Integer usuarioId) {
        ResponseModel<Boolean> response = new ResponseModel<>();
        try {
            List<NotificacoesModel> notificacoes = notificacoesRepository.findByUsuarioIdAndLidaFalseOrderByDataEnvioDesc(usuarioId);
            for (NotificacoesModel notificacao : notificacoes) {
                notificacao.setLida(true);
                notificacao.setDataLeitura(LocalDateTime.now());
            }
            notificacoesRepository.saveAll(notificacoes);

            response.setDados(true);
            response.setStatus(true);
            response.setMensagem(notificacoes.size() + " notificação(ões) marcada(s) como lida(s).");
        } catch (Exception ex) {
            response.setDados(false);
            response.setStatus(false);
            response.setMensagem("Erro ao marcar notificações: " + ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<Integer> deletarNotificacoesAntigasAsync(LocalDateTime dataLimite) {
        ResponseModel<Integer> response = new ResponseModel<>();
        try {
            List<NotificacoesModel> antigas = notificacoesRepository.findByDataEnvioBefore(dataLimite);
            int count = antigas.size();
            notificacoesRepository.deleteAll(antigas);
            response.setDados(count);
            response.setStatus(true);
            response.setMensagem(count + " notificação(ões) antiga(s) removida(s).");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem("Erro ao deletar notificações: " + ex.getMessage());
        }
        return response;
    }

    private NotificacoesModel criarNotificacao(Integer expoTokenId, Integer usuarioId, String titulo, String mensagem, String dados) {
        NotificacoesModel notificacao = new NotificacoesModel();
        notificacao.setExpoTokenId(expoTokenId);
        notificacao.setUsuarioId(usuarioId);
        notificacao.setTitulo(titulo);
        notificacao.setMensagem(mensagem);
        notificacao.setDados(dados);
        notificacao.setDataEnvio(LocalDateTime.now());
        notificacao.setEnviada(true);
        return notificacao;
    }
}
