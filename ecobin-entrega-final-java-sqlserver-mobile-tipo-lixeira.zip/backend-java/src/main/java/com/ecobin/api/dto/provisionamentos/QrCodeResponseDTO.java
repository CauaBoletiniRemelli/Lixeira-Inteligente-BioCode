package com.ecobin.api.dto.provisionamentos;

public class QrCodeResponseDTO {
    private byte[] qrBytes;
    private String mediaType = "image/png";
    public QrCodeResponseDTO() {}
    public QrCodeResponseDTO(byte[] qrBytes, String mediaType) { this.qrBytes = qrBytes; this.mediaType = mediaType; }
    public byte[] getQrBytes() { return qrBytes; }
    public void setQrBytes(byte[] qrBytes) { this.qrBytes = qrBytes; }
    public String getMediaType() { return mediaType; }
    public void setMediaType(String mediaType) { this.mediaType = mediaType; }
}
