package com.ecobin.api.services.provisionamentos;

import com.ecobin.api.dto.devices.WifiCredentialsResponseDTO;
import com.ecobin.api.dto.provisionamentos.*;
import com.ecobin.api.models.*;
import com.ecobin.api.repositories.*;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@Service
public class ProvisionamentosService implements IProvisionamentosInteraface {
    private final ProvisionamentosRepository provisionamentosRepository;
    private final SensoresRepository sensoresRepository;
    private final UsuariosRepository usuariosRepository;

    @Value("${app.jwt.secret}")
    private String secret;

    public ProvisionamentosService(ProvisionamentosRepository provisionamentosRepository, SensoresRepository sensoresRepository, UsuariosRepository usuariosRepository) {
        this.provisionamentosRepository = provisionamentosRepository;
        this.sensoresRepository = sensoresRepository;
        this.usuariosRepository = usuariosRepository;
    }

    @Override
    public ResponseModel<ProvisionamentosModel> createProvisionamentoAsync(ProvisionCreateRequestDTO dto) {
        ResponseModel<ProvisionamentosModel> response = new ResponseModel<>();
        try {
            if (dto == null || dto.getSensorId() == null || dto.getUsuarioId() == null) {
                response.setStatus(false);
                response.setMensagem("Sensor e usuário são obrigatórios.");
                return response;
            }

            SensoresModel sensor = sensoresRepository.findById(dto.getSensorId()).orElse(null);
            if (sensor == null) {
                response.setStatus(false);
                response.setMensagem("Sensor não encontrado.");
                return response;
            }

            UsuariosModel usuario = usuariosRepository.findById(dto.getUsuarioId()).orElse(null);
            if (usuario == null) {
                response.setStatus(false);
                response.setMensagem("Usuário não encontrado.");
                return response;
            }

            ProvisionamentosModel provision = new ProvisionamentosModel();
            provision.setSensorId(dto.getSensorId());
            provision.setUsuarioId(dto.getUsuarioId());
            provision.setExpiracao(LocalDateTime.now().plusDays(dto.getExpiracaoDias() == null ? 1 : dto.getExpiracaoDias()));
            provision.setUsado(false);
            provision.setCriadoEm(LocalDateTime.now());

            response.setStatus(true);
            response.setMensagem("Provisionamento criado com sucesso.");
            response.setDados(provisionamentosRepository.save(provision));
            return response;
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
            return response;
        }
    }

    @Override
    @Transactional
    public ResponseModel<ProvisionamentosModel> createProvisionamentoComSensorAsync(ProvisionCreateWithSensorDTO dto) {
        ResponseModel<ProvisionamentosModel> response = new ResponseModel<>();
        try {
            if (dto == null || dto.getUsuarioId() == null) {
                response.setStatus(false);
                response.setMensagem("Usuário é obrigatório.");
                return response;
            }

            SensoresModel sensor = new SensoresModel();
            sensor.setDeviceId(UUID.randomUUID().toString().replace("-", ""));
            sensor.setDeviceKey(UUID.randomUUID().toString().replace("-", ""));
            sensor.setNome(dto.getNomeSensor());
            sensor.setTipo(defaultTipo(dto.getTipo()));
            sensor.setCondominioId(dto.getCondominioId());
            sensor.setStatus(0);
            sensor.setCriadoEm(LocalDateTime.now());
            sensor = sensoresRepository.save(sensor);

            ProvisionamentosModel provision = new ProvisionamentosModel();
            provision.setSensorId(sensor.getId());
            provision.setUsuarioId(dto.getUsuarioId());
            provision.setExpiracao(LocalDateTime.now().plusDays(dto.getExpiracaoDias() == null ? 1 : dto.getExpiracaoDias()));
            provision.setUsado(false);
            provision.setCriadoEm(LocalDateTime.now());

            response.setStatus(true);
            response.setMensagem("Sensor placeholder e provisionamento criados com sucesso.");
            response.setDados(provisionamentosRepository.save(provision));
            return response;
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
            return response;
        }
    }

    @Override
    public ResponseModel<List<ProvisionamentosModel>> getProvisionamentosAsync() {
        ResponseModel<List<ProvisionamentosModel>> response = new ResponseModel<>();
        try {
            List<ProvisionamentosModel> provisionamentos = provisionamentosRepository.findAll().stream()
                    .sorted((a, b) -> nullSafeDate(b.getCriadoEm()).compareTo(nullSafeDate(a.getCriadoEm())))
                    .toList();
            response.setStatus(true);
            response.setDados(provisionamentos);
            response.setMensagem("Lista de provisionamentos retornada.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<ProvisionamentosModel> getProvisionamentoByIdAsync(Integer id) {
        ResponseModel<ProvisionamentosModel> response = new ResponseModel<>();
        try {
            ProvisionamentosModel prov = provisionamentosRepository.findById(id).orElse(null);
            if (prov == null) {
                response.setStatus(false);
                response.setMensagem("Provisionamento não encontrado.");
                return response;
            }
            response.setStatus(true);
            response.setDados(prov);
            response.setMensagem("Provisionamento encontrado.");
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
        }
        return response;
    }

    @Override
    public ResponseModel<ProvisionQrResponseDTO> createQrCodeProvisionamentoAsync(Integer provisionId) {
        ResponseModel<ProvisionQrResponseDTO> response = new ResponseModel<>();
        try {
            ProvisionamentosModel prov = provisionamentosRepository.findById(provisionId).orElse(null);
            if (prov == null) {
                response.setStatus(false);
                response.setMensagem("Provisionamento não encontrado.");
                return response;
            }

            String deviceId = sensoresRepository.findById(prov.getSensorId())
                    .map(SensoresModel::getDeviceId)
                    .orElse(String.valueOf(prov.getSensorId()));

            String token = gerarTokenDeProvisionamento(prov, deviceId);
            String qrPayload = prov.getId() + "|" + deviceId + "|" + token;

            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(qrPayload, BarcodeFormat.QR_CODE, 400, 400);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(bitMatrix, "PNG", outputStream);

            ProvisionQrResponseDTO dto = new ProvisionQrResponseDTO();
            dto.setQrBytes(outputStream.toByteArray());
            dto.setMediaType("image/png");

            response.setStatus(true);
            response.setDados(dto);
            return response;
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
            return response;
        }
    }

    @Override
    @Transactional
    public ResponseModel<ProvisionActivateResponseDTO> activateProvisionAsync(ProvisionActivateRequestDTO dto, Integer userIdFromClaim) {
        ResponseModel<ProvisionActivateResponseDTO> response = new ResponseModel<>();
        try {
            if (dto == null || isBlank(dto.getToken()) || isBlank(dto.getProvisionId()) || isBlank(dto.getDeviceId())) {
                response.setStatus(false);
                response.setMensagem("Dados de ativação inválidos.");
                return response;
            }

            ProvisionTokenClaims claims = validarTokenDeProvisionamento(dto.getToken());
            if (claims == null) {
                response.setStatus(false);
                response.setMensagem("Token inválido.");
                return response;
            }
            if (claims.expiraEm().isBefore(LocalDateTime.now())) {
                response.setStatus(false);
                response.setMensagem("Token expirado.");
                return response;
            }
            if (!claims.provisionId().equals(dto.getProvisionId()) || !claims.deviceId().equals(dto.getDeviceId())) {
                response.setStatus(false);
                response.setMensagem("Token não corresponde ao QR.");
                return response;
            }

            ProvisionamentosModel prov = provisionamentosRepository.findById(Integer.parseInt(dto.getProvisionId())).orElse(null);
            if (prov == null) {
                response.setStatus(false);
                response.setMensagem("Provisionamento não encontrado.");
                return response;
            }
            if (Boolean.TRUE.equals(prov.getUsado())) {
                response.setStatus(false);
                response.setMensagem("Provisionamento já usado.");
                return response;
            }
            if (prov.getExpiracao() != null && prov.getExpiracao().isBefore(LocalDateTime.now())) {
                response.setStatus(false);
                response.setMensagem("Provisionamento expirado.");
                return response;
            }

            SensoresModel sensor = sensoresRepository.findById(prov.getSensorId()).orElse(null);
            if (sensor == null) {
                sensor = new SensoresModel();
                sensor.setDeviceId(dto.getDeviceId());
                sensor.setDeviceKey(UUID.randomUUID().toString().replace("-", ""));
                sensor.setNome(dto.getNomeSensor());
                sensor.setTipo(defaultTipo(dto.getTipo()));
                sensor.setCondominioId(dto.getCondominioId());
                sensor.setLatitude(dto.getLatitude());
                sensor.setLongitude(dto.getLongitude());
                sensor.setStatus(0);
                sensor.setCriadoEm(LocalDateTime.now());
            } else {
                sensor.setDeviceId(dto.getDeviceId());
                sensor.setNome(dto.getNomeSensor() == null ? sensor.getNome() : dto.getNomeSensor());
                if (!isBlank(dto.getTipo())) sensor.setTipo(dto.getTipo());
                sensor.setCondominioId(dto.getCondominioId());
                sensor.setLatitude(dto.getLatitude() == null ? sensor.getLatitude() : dto.getLatitude());
                sensor.setLongitude(dto.getLongitude() == null ? sensor.getLongitude() : dto.getLongitude());
            }
            sensor = sensoresRepository.save(sensor);

            String sessionToken = gerarSessionToken();
            prov.setSensorId(sensor.getId());
            prov.setSessionToken(sessionToken);
            prov.setSessionExpires(LocalDateTime.now().plusMinutes(10));
            if (userIdFromClaim != null) prov.setUsuarioId(userIdFromClaim);
            prov.setSsidCriptografado(criptografarDado(dto.getWifiSSID()));
            prov.setSenhaWifiCriptografada(criptografarDado(dto.getWifiPassword()));
            prov.setNomeSensor(dto.getNomeSensor());
            provisionamentosRepository.save(prov);

            ProvisionActivateResponseDTO data = new ProvisionActivateResponseDTO();
            data.setSuccess(true);
            data.setDeviceId(dto.getDeviceId());
            data.setSensorId(sensor.getId());
            data.setSessionToken(sessionToken);
            data.setSessionExpires(prov.getSessionExpires());
            data.setMessage("Provisionamento criado. Use sessionToken para configurar o sensor via AP.");

            response.setStatus(true);
            response.setDados(data);
            return response;
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
            return response;
        }
    }

    @Override
    public ResponseModel<WifiCredentialsResponseDTO> getWifiCredentialsAsync(String deviceId, String sessionToken) {
        ResponseModel<WifiCredentialsResponseDTO> response = new ResponseModel<>();
        try {
            SensoresModel sensor = sensoresRepository.findByDeviceId(deviceId).orElse(null);
            if (sensor == null) {
                response.setStatus(false);
                response.setMensagem("Sensor não encontrado.");
                return response;
            }

            ProvisionamentosModel prov = provisionamentosRepository.findFirstBySensorIdAndSessionToken(sensor.getId(), sessionToken).orElse(null);
            if (prov == null) {
                response.setStatus(false);
                response.setMensagem("Session token inválido.");
                return response;
            }
            if (prov.getSessionExpires() == null || prov.getSessionExpires().isBefore(LocalDateTime.now())) {
                response.setStatus(false);
                response.setMensagem("Session expirado.");
                return response;
            }
            if (isBlank(prov.getSsidCriptografado()) || isBlank(prov.getSenhaWifiCriptografada())) {
                response.setStatus(false);
                response.setMensagem("Credenciais Wi-Fi não configuradas.");
                return response;
            }

            WifiCredentialsResponseDTO data = new WifiCredentialsResponseDTO();
            data.setSSID(descriptografarDado(prov.getSsidCriptografado()));
            data.setPassword(descriptografarDado(prov.getSenhaWifiCriptografada()));
            data.setSessionExpires(prov.getSessionExpires());
            data.setDeviceId(deviceId);

            response.setStatus(true);
            response.setDados(data);
            response.setMensagem("Credenciais Wi-Fi recuperadas com sucesso.");
            return response;
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
            return response;
        }
    }

    @Override
    @Transactional
    public ResponseModel<Boolean> confirmDeviceConfigAsync(String deviceId, com.ecobin.api.dto.devices.ConfirmConfigDTO dto) {
        ResponseModel<Boolean> response = new ResponseModel<>();
        try {
            SensoresModel sensor = sensoresRepository.findByDeviceId(deviceId).orElse(null);
            if (sensor == null) {
                response.setStatus(false);
                response.setMensagem("Sensor não encontrado.");
                return response;
            }

            ProvisionamentosModel prov = provisionamentosRepository.findFirstBySensorIdAndSessionToken(sensor.getId(), dto.getSessionToken()).orElse(null);
            if (prov == null) {
                response.setStatus(false);
                response.setMensagem("Session token inválido para este sensor.");
                return response;
            }
            if (prov.getSessionExpires() == null || prov.getSessionExpires().isBefore(LocalDateTime.now())) {
                response.setStatus(false);
                response.setMensagem("Session expirado.");
                return response;
            }
            if (!Boolean.TRUE.equals(dto.getWifiConnected())) {
                response.setStatus(false);
                response.setMensagem("Dispositivo não conseguiu conectar ao Wi-Fi. " + (dto.getMessage() == null ? "" : dto.getMessage()));
                return response;
            }

            prov.setUsado(true);
            prov.setSessionToken(null);
            prov.setSessionExpires(null);
            provisionamentosRepository.save(prov);

            sensor.setStatus(1);
            sensor.setUltimaConexao(LocalDateTime.now());
            sensoresRepository.save(sensor);

            response.setStatus(true);
            response.setMensagem("Sensor confirmado e ativado com sucesso.");
            response.setDados(true);
            return response;
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
            return response;
        }
    }

    @Override
    public ResponseModel<Object> assignWifiToSessionAsync(String sessionToken, AssignWifiRequestDTO dto) {
        ResponseModel<Object> response = new ResponseModel<>();
        try {
            if (isBlank(sessionToken)) {
                response.setStatus(false);
                response.setMensagem("sessionToken obrigatório.");
                return response;
            }

            ProvisionamentosModel prov = provisionamentosRepository.findBySessionToken(sessionToken).orElse(null);
            if (prov == null) {
                response.setStatus(false);
                response.setMensagem("Session token inválido.");
                return response;
            }
            if (prov.getSessionExpires() == null || prov.getSessionExpires().isBefore(LocalDateTime.now())) {
                response.setStatus(false);
                response.setMensagem("Session expirado.");
                return response;
            }
            if (Boolean.TRUE.equals(prov.getUsado())) {
                response.setStatus(false);
                response.setMensagem("Provisionamento já utilizado.");
                return response;
            }

            prov.setSsidCriptografado(criptografarDado(dto.getWifiSSID() == null ? "" : dto.getWifiSSID()));
            prov.setSenhaWifiCriptografada(criptografarDado(dto.getWifiPassword() == null ? "" : dto.getWifiPassword()));
            provisionamentosRepository.save(prov);

            response.setStatus(true);
            response.setMensagem("Credenciais Wi-Fi atribuídas à sessão com sucesso.");
            response.setDados(null);
            return response;
        } catch (Exception ex) {
            response.setStatus(false);
            response.setMensagem(ex.getMessage());
            return response;
        }
    }

    private String gerarTokenDeProvisionamento(ProvisionamentosModel provision, String deviceId) throws Exception {
        LocalDateTime expiraEm = LocalDateTime.now().plusDays(1);
        String payload = provision.getId() + "|" + deviceId + "|" + expiraEm;
        String assinatura = hmac(payload);
        return Base64.getUrlEncoder().withoutPadding().encodeToString((payload + "|" + assinatura).getBytes(StandardCharsets.UTF_8));
    }

    private ProvisionTokenClaims validarTokenDeProvisionamento(String token) throws Exception {
        String decoded = new String(Base64.getUrlDecoder().decode(token), StandardCharsets.UTF_8);
        String[] parts = decoded.split("\\|", 4);
        if (parts.length != 4) return null;
        String payload = parts[0] + "|" + parts[1] + "|" + parts[2];
        if (!hmac(payload).equals(parts[3])) return null;
        return new ProvisionTokenClaims(parts[0], parts[1], LocalDateTime.parse(parts[2]));
    }

    private String gerarSessionToken() {
        byte[] tokenBytes = new byte[24];
        new SecureRandom().nextBytes(tokenBytes);
        return Base64.getEncoder().encodeToString(tokenBytes);
    }

    private String hmac(String data) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal(data.getBytes(StandardCharsets.UTF_8)));
    }

    private String criptografarDado(String dado) throws Exception {
        if (dado == null) dado = "";
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        byte[] iv = new byte[16];
        new SecureRandom().nextBytes(iv);
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(aesKey(), "AES"), new IvParameterSpec(iv));
        byte[] cipherBytes = cipher.doFinal(dado.getBytes(StandardCharsets.UTF_8));
        byte[] result = new byte[iv.length + cipherBytes.length];
        System.arraycopy(iv, 0, result, 0, iv.length);
        System.arraycopy(cipherBytes, 0, result, iv.length, cipherBytes.length);
        return Base64.getEncoder().encodeToString(result);
    }

    private String descriptografarDado(String dadoCriptografado) throws Exception {
        byte[] fullCipher = Base64.getDecoder().decode(dadoCriptografado);
        byte[] iv = new byte[16];
        byte[] cipherText = new byte[fullCipher.length - 16];
        System.arraycopy(fullCipher, 0, iv, 0, 16);
        System.arraycopy(fullCipher, 16, cipherText, 0, cipherText.length);
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(aesKey(), "AES"), new IvParameterSpec(iv));
        return new String(cipher.doFinal(cipherText), StandardCharsets.UTF_8);
    }

    private byte[] aesKey() throws Exception {
        return MessageDigest.getInstance("SHA-256").digest(secret.getBytes(StandardCharsets.UTF_8));
    }

    private String defaultTipo(String value) {
        return isBlank(value) ? "Comum" : value.trim();
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private LocalDateTime nullSafeDate(LocalDateTime value) {
        return value == null ? LocalDateTime.MIN : value;
    }

    private record ProvisionTokenClaims(String provisionId, String deviceId, LocalDateTime expiraEm) {}
}
