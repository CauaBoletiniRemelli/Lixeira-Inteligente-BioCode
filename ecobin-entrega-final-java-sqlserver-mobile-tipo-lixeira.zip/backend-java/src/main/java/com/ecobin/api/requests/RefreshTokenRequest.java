package com.ecobin.api.requests;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class RefreshTokenRequest {
    private String accessToken;
    private String refreshToken;

    public RefreshTokenRequest() {}

    public String getAccessToken() { return accessToken; }
    public void setAccessToken(String accessToken) { this.accessToken = accessToken; }

    public String getRefreshToken() { return refreshToken; }
    public void setRefreshToken(String refreshToken) { this.refreshToken = refreshToken; }

}
