package com.ecobin.api.dto.condominios;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class CondominiosCreateDTO {
    private String nome;
    private String endereco;
    private String cEP;
    private Boolean ativo;

    public CondominiosCreateDTO() {}

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }

    public String getCEP() { return cEP; }
    public void setCEP(String cEP) { this.cEP = cEP; }

    public Boolean getAtivo() { return ativo; }
    public void setAtivo(Boolean ativo) { this.ativo = ativo; }

    public String getCep() { return cEP; }
    public void setCep(String cep) { this.cEP = cep; }
}
