package com.ecobin.api.dto.usuarios;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ChangeEmailDTO {
    private Integer iD;
    private String oldEmail;
    private String newEmail;

    public ChangeEmailDTO() {}

    public Integer getID() { return iD; }
    public void setID(Integer iD) { this.iD = iD; }

    public String getOldEmail() { return oldEmail; }
    public void setOldEmail(String oldEmail) { this.oldEmail = oldEmail; }

    public String getNewEmail() { return newEmail; }
    public void setNewEmail(String newEmail) { this.newEmail = newEmail; }

}
