package com.ecobin.api.services.telemetrias;

import com.ecobin.api.dto.telemetrias.*;
import com.ecobin.api.models.*;
import java.time.LocalDateTime;
import java.util.List;

public interface ITelemetriasInterface {
    ResponseModel<TelemetriaResponseDTO> createTelemetriaAsync(TelemetriaCreateDTO dto);
    ResponseModel<TelemetriaResponseDTO> createTelemetriaArduinoAsync(TelemetriaArduinoDTO dto);
    ResponseModel<List<TelemetriasModel>> getTelemetriasAsync();
    ResponseModel<List<TelemetriasModel>> getTelemetriasFiltroAsync(TelemetriaFiltroDTO filtro);
    ResponseModel<List<TelemetriasModel>> getTelemetriasBySensorAsync(Integer sensorId, int limit);
    ResponseModel<TelemetriasModel> getUltimaTelemetriaAsync(Integer sensorId);
    ResponseModel<List<TelemetriasModel>> getTelemetriasByCondominioAsync(Integer condominioId);
    ResponseModel<TelemetriaStatsDTO> getEstatisticasSensorAsync(Integer sensorId, LocalDateTime dataInicio, LocalDateTime dataFim);
    ResponseModel<List<TelemetriaStatsDTO>> getEstatisticasCondominioAsync(Integer condominioId);
    ResponseModel<List<StatusLixeiraDTO>> getStatusLixeirasAsync(Integer condominioId);
    ResponseModel<Integer> deleteTelemetriasAntigasAsync(LocalDateTime dataLimite);
}
