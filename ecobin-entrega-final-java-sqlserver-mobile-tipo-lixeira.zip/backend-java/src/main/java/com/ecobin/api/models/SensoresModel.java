package com.ecobin.api.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "SENsores")
public class SensoresModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "SENDeviceId", nullable = false, unique = true, length = 50)
    private String deviceId = "";

    @JsonIgnore
    @Column(name = "SENDeviceKey", nullable = false, length = 255)
    private String deviceKey = "";

    @Column(name = "SENStatus", nullable = false)
    private Integer status = 0;

    @Column(name = "SENNome", length = 100)
    private String nome;

    @Column(name = "SENTipo", length = 50)
    private String tipo = "Comum";

    @Column(name = "SEN_CONId")
    private Integer condominioId;

    @Column(name = "SENLatitude", precision = 10, scale = 8)
    private BigDecimal latitude;

    @Column(name = "SENLongitude", precision = 11, scale = 8)
    private BigDecimal longitude;

    @Column(name = "SENUltimaConexao")
    private LocalDateTime ultimaConexao;

    @Column(name = "SENCriadoEm")
    private LocalDateTime criadoEm;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SEN_CONId", insertable = false, updatable = false)
    @JsonIgnore
    private CondominiosModel condominio;

    @JsonIgnore
    @OneToMany(mappedBy = "sensor", fetch = FetchType.LAZY)
    private List<ProvisionamentosModel> provisionamentos = new ArrayList<>();

    @OneToMany(mappedBy = "sensor", fetch = FetchType.LAZY)
    private List<TelemetriasModel> telemetrias = new ArrayList<>();

    @PrePersist
    public void prePersist(){
        if(criadoEm==null) criadoEm=LocalDateTime.now();
        if(status==null) status=0;
        if(deviceId==null) deviceId="";
        if(deviceKey==null) deviceKey="";
        if(tipo==null || tipo.trim().isEmpty()) tipo="Comum";
    }

    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getDeviceId(){return deviceId;} public void setDeviceId(String deviceId){this.deviceId=deviceId;}
    public String getDeviceKey(){return deviceKey;} public void setDeviceKey(String deviceKey){this.deviceKey=deviceKey;}
    public Integer getStatus(){return status;} public void setStatus(Integer status){this.status=status;}
    public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
    public String getTipo(){return tipo;} public void setTipo(String tipo){this.tipo=tipo;}
    public Integer getCondominioId(){return condominioId;} public void setCondominioId(Integer condominioId){this.condominioId=condominioId;}
    public BigDecimal getLatitude(){return latitude;} public void setLatitude(BigDecimal latitude){this.latitude=latitude;}
    public BigDecimal getLongitude(){return longitude;} public void setLongitude(BigDecimal longitude){this.longitude=longitude;}
    public LocalDateTime getUltimaConexao(){return ultimaConexao;} public void setUltimaConexao(LocalDateTime ultimaConexao){this.ultimaConexao=ultimaConexao;}
    public LocalDateTime getCriadoEm(){return criadoEm;} public void setCriadoEm(LocalDateTime criadoEm){this.criadoEm=criadoEm;}
    public CondominiosModel getCondominio(){return condominio;} public void setCondominio(CondominiosModel condominio){this.condominio=condominio;}
    public List<ProvisionamentosModel> getProvisionamentos(){return provisionamentos;} public void setProvisionamentos(List<ProvisionamentosModel> provisionamentos){this.provisionamentos=provisionamentos;}
    public List<TelemetriasModel> getTelemetrias(){return telemetrias;} public void setTelemetrias(List<TelemetriasModel> telemetrias){this.telemetrias=telemetrias;}
}
