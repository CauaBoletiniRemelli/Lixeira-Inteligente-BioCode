package com.ecobin.api.enums;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = true)
public class TipoUsuarioConverter implements AttributeConverter<TipoUsuario, Integer> {
    @Override
    public Integer convertToDatabaseColumn(TipoUsuario attribute) {
        return attribute == null ? TipoUsuario.NaoIdentificado.getValor() : attribute.getValor();
    }

    @Override
    public TipoUsuario convertToEntityAttribute(Integer dbData) {
        return dbData == null ? TipoUsuario.NaoIdentificado : TipoUsuario.fromValor(dbData);
    }
}
