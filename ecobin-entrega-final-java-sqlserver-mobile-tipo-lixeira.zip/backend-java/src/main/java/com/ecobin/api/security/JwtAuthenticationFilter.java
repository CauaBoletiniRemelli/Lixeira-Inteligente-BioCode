package com.ecobin.api.security;

import com.ecobin.api.repositories.UsuariosRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    private final JwtService jwtService;
    private final UsuariosRepository usuariosRepository;

    public JwtAuthenticationFilter(JwtService jwtService, UsuariosRepository usuariosRepository) {
        this.jwtService = jwtService;
        this.usuariosRepository = usuariosRepository;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String auth = request.getHeader("Authorization");
        if (auth != null && auth.startsWith("Bearer ") && SecurityContextHolder.getContext().getAuthentication() == null) {
            String token = auth.substring(7);
            Integer userId = jwtService.getUserId(token);
            Integer tipoFromToken = jwtService.getTipo(token);

            if (userId != null && tipoFromToken != null) {
                final Integer[] tipo = {tipoFromToken};
                usuariosRepository.findById(userId).ifPresent(user -> {
                    if (user.getTipo() != null) tipo[0] = user.getTipo().getValor();
                });

                List<SimpleGrantedAuthority> authorities = buildAuthorities(tipo[0]);
                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userId, null, authorities);
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        }
        filterChain.doFilter(request, response);
    }

    private List<SimpleGrantedAuthority> buildAuthorities(Integer tipo) {
        List<SimpleGrantedAuthority> authorities = new ArrayList<>();
        int tipoValue = tipo == null ? 0 : tipo;

        authorities.add(new SimpleGrantedAuthority(String.valueOf(tipoValue)));
        authorities.add(new SimpleGrantedAuthority("Tipo:" + tipoValue));

        if (tipoValue == 1) authorities.add(new SimpleGrantedAuthority("AdminOnly"));
        if (tipoValue == 1 || tipoValue == 5) authorities.add(new SimpleGrantedAuthority("AppOnly"));
        if (tipoValue == 6) authorities.add(new SimpleGrantedAuthority("ArduinoOnly"));

        return authorities;
    }
}
