package com.ecobin.api.repositories;

import com.ecobin.api.models.TelemetriasModel;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.List;

public interface TelemetriasRepository extends JpaRepository<TelemetriasModel, Integer> {
    List<TelemetriasModel> findBySensorIdOrderByMomentoDesc(Integer sensorId, Pageable pageable);
    List<TelemetriasModel> findBySensorId(Integer sensorId);
    List<TelemetriasModel> findBySensorIdInOrderByMomentoDesc(List<Integer> sensorIds, Pageable pageable);
    List<TelemetriasModel> findByMomentoBefore(LocalDateTime dataLimite);
    List<TelemetriasModel> findBySensorIdAndMomentoBetween(Integer sensorId, LocalDateTime inicio, LocalDateTime fim);
}
