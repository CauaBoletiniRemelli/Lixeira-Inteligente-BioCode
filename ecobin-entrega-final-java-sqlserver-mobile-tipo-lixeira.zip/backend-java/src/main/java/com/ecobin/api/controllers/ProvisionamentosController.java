package com.ecobin.api.controllers;

import com.ecobin.api.dto.provisionamentos.*;
import com.ecobin.api.services.provisionamentos.IProvisionamentosInteraface;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/Provisionamentos")
public class ProvisionamentosController {
    private final IProvisionamentosInteraface provService;

    public ProvisionamentosController(IProvisionamentosInteraface provService) {
        this.provService = provService;
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @GetMapping
    public ResponseEntity<?> getProvisionamentos() {
        var res = provService.getProvisionamentosAsync();
        return res.isStatus() ? ResponseEntity.ok(res) : ResponseEntity.badRequest().body(res);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @GetMapping("/{id}")
    public ResponseEntity<?> getProvisionamentoById(@PathVariable Integer id) {
        var res = provService.getProvisionamentoByIdAsync(id);
        return res.isStatus() ? ResponseEntity.ok(res) : ResponseEntity.status(404).body(res);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @PostMapping("/criar")
    public ResponseEntity<?> criarProvisionamento(@RequestBody ProvisionCreateRequestDTO dto) {
        var res = provService.createProvisionamentoAsync(dto);
        return res.isStatus() ? ResponseEntity.ok(res) : ResponseEntity.badRequest().body(res);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @PostMapping("/criar-com-sensor")
    public ResponseEntity<?> criarProvisionamentoComSensor(@RequestBody ProvisionCreateWithSensorDTO dto) {
        var res = provService.createProvisionamentoComSensorAsync(dto);
        return res.isStatus() ? ResponseEntity.ok(res) : ResponseEntity.badRequest().body(res);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @GetMapping("/gerar-qr/{provisionId}")
    public ResponseEntity<?> gerarQrCode(@PathVariable Integer provisionId) {
        var res = provService.createQrCodeProvisionamentoAsync(provisionId);
        if (!res.isStatus()) return ResponseEntity.badRequest().body(res);
        return ResponseEntity.ok()
            .contentType(MediaType.parseMediaType(res.getDados().getMediaType()))
            .body(res.getDados().getQrBytes());
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/ativar-qr")
    public ResponseEntity<?> ativarQr(@RequestBody ProvisionActivateRequestDTO dto, Authentication authentication) {
        Integer userId = authentication != null && authentication.getPrincipal() instanceof Integer ? (Integer) authentication.getPrincipal() : null;
        var res = provService.activateProvisionAsync(dto, userId);
        return res.isStatus() ? ResponseEntity.ok(res) : ResponseEntity.badRequest().body(res);
    }

    @PreAuthorize("hasAuthority('AppOnly')")
    @PostMapping("/{sessionToken}/assign-wifi")
    public ResponseEntity<?> assignWifi(@PathVariable String sessionToken, @RequestBody AssignWifiRequestDTO dto) {
        if (sessionToken == null || sessionToken.isBlank()) return ResponseEntity.badRequest().body(Map.of("status", false, "mensagem", "sessionToken obrigatório"));
        var res = provService.assignWifiToSessionAsync(sessionToken, dto);
        return res.isStatus() ? ResponseEntity.ok(res) : ResponseEntity.badRequest().body(res);
    }

    @GetMapping("/wifi-credentials/{deviceId}")
    public ResponseEntity<?> getWifiCredentials(@PathVariable String deviceId, @RequestParam String sessionToken) {
        if (deviceId == null || deviceId.isBlank() || sessionToken == null || sessionToken.isBlank())
            return ResponseEntity.badRequest().body(Map.of("status", false, "mensagem", "deviceId e sessionToken são obrigatórios"));
        var res = provService.getWifiCredentialsAsync(deviceId, sessionToken);
        return res.isStatus() ? ResponseEntity.ok(res) : ResponseEntity.status(404).body(res);
    }

    @PostMapping("/confirm-config/{deviceId}")
    public ResponseEntity<?> confirmConfig(@PathVariable String deviceId, @RequestBody com.ecobin.api.dto.devices.ConfirmConfigDTO dto) {
        var res = provService.confirmDeviceConfigAsync(deviceId, dto);
        return res.isStatus() ? ResponseEntity.ok(res) : ResponseEntity.badRequest().body(res);
    }
}
