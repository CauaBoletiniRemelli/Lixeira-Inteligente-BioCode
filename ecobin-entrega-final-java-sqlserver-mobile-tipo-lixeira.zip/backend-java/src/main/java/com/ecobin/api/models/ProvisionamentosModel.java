package com.ecobin.api.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "PROvisionamentos")
public class ProvisionamentosModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "PRO_SENId", nullable = false)
    private Integer sensorId;

    @Column(name = "PROSsidCriptografado", length = 512)
    private String ssidCriptografado;

    @Column(name = "PROSenhaWifiCriptografada", length = 1024)
    private String senhaWifiCriptografada;

    @Column(name = "PRONomeSensor", length = 100)
    private String nomeSensor;

    @Column(name = "PRO_USUId", nullable = false)
    private Integer usuarioId;

    @Column(name = "PROExpiracao", nullable = false)
    private LocalDateTime expiracao;

    @Column(name = "PROUsado")
    private Boolean usado = false;

    @Column(name = "PROCriadoEm")
    private LocalDateTime criadoEm;

    @Column(name = "PROSessionToken")
    private String sessionToken;

    @Column(name = "PROSessionExpires")
    private LocalDateTime sessionExpires;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRO_SENId", insertable = false, updatable = false)
    @JsonIgnore
    private SensoresModel sensor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PRO_USUId", insertable = false, updatable = false)
    @JsonIgnore
    private UsuariosModel usuario;

    @PrePersist public void prePersist(){ if(criadoEm==null) criadoEm=LocalDateTime.now(); if(usado==null) usado=false; }

    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Integer getSensorId(){return sensorId;} public void setSensorId(Integer sensorId){this.sensorId=sensorId;}
    public String getSsidCriptografado(){return ssidCriptografado;} public void setSsidCriptografado(String ssidCriptografado){this.ssidCriptografado=ssidCriptografado;}
    public String getSenhaWifiCriptografada(){return senhaWifiCriptografada;} public void setSenhaWifiCriptografada(String senhaWifiCriptografada){this.senhaWifiCriptografada=senhaWifiCriptografada;}
    public String getNomeSensor(){return nomeSensor;} public void setNomeSensor(String nomeSensor){this.nomeSensor=nomeSensor;}
    public Integer getUsuarioId(){return usuarioId;} public void setUsuarioId(Integer usuarioId){this.usuarioId=usuarioId;}
    public LocalDateTime getExpiracao(){return expiracao;} public void setExpiracao(LocalDateTime expiracao){this.expiracao=expiracao;}
    public Boolean getUsado(){return usado;} public void setUsado(Boolean usado){this.usado=usado;}
    public LocalDateTime getCriadoEm(){return criadoEm;} public void setCriadoEm(LocalDateTime criadoEm){this.criadoEm=criadoEm;}
    public String getSessionToken(){return sessionToken;} public void setSessionToken(String sessionToken){this.sessionToken=sessionToken;}
    public LocalDateTime getSessionExpires(){return sessionExpires;} public void setSessionExpires(LocalDateTime sessionExpires){this.sessionExpires=sessionExpires;}
    public SensoresModel getSensor(){return sensor;} public void setSensor(SensoresModel sensor){this.sensor=sensor;}
    public UsuariosModel getUsuario(){return usuario;} public void setUsuario(UsuariosModel usuario){this.usuario=usuario;}
}
