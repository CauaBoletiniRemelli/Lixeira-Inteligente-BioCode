package com.ecobin.api.dto.telemetrias;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class TelemetriaCreateDTO {
    private Integer sensorId;
    private Integer nivelOcupacao;
    private Integer bateria;
    private BigDecimal temperatura;
    private LocalDateTime momento;
    private String dadosBrutos;

    public TelemetriaCreateDTO() {}

    public Integer getSensorId() { return sensorId; }
    public void setSensorId(Integer sensorId) { this.sensorId = sensorId; }

    public Integer getNivelOcupacao() { return nivelOcupacao; }
    public void setNivelOcupacao(Integer nivelOcupacao) { this.nivelOcupacao = nivelOcupacao; }

    public Integer getBateria() { return bateria; }
    public void setBateria(Integer bateria) { this.bateria = bateria; }

    public BigDecimal getTemperatura() { return temperatura; }
    public void setTemperatura(BigDecimal temperatura) { this.temperatura = temperatura; }

    public LocalDateTime getMomento() { return momento; }
    public void setMomento(LocalDateTime momento) { this.momento = momento; }

    public String getDadosBrutos() { return dadosBrutos; }
    public void setDadosBrutos(String dadosBrutos) { this.dadosBrutos = dadosBrutos; }

}
