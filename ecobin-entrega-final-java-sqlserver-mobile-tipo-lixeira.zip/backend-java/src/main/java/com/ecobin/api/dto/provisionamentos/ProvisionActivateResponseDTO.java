package com.ecobin.api.dto.provisionamentos;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ProvisionActivateResponseDTO {
    private Boolean success;
    private String deviceId;
    private Integer sensorId;
    private String sessionToken;
    private LocalDateTime sessionExpires;
    private String message;

    public ProvisionActivateResponseDTO() {}

    public Boolean getSuccess() { return success; }
    public void setSuccess(Boolean success) { this.success = success; }

    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public Integer getSensorId() { return sensorId; }
    public void setSensorId(Integer sensorId) { this.sensorId = sensorId; }

    public String getSessionToken() { return sessionToken; }
    public void setSessionToken(String sessionToken) { this.sessionToken = sessionToken; }

    public LocalDateTime getSessionExpires() { return sessionExpires; }
    public void setSessionExpires(LocalDateTime sessionExpires) { this.sessionExpires = sessionExpires; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

}
