package com.ecobin.api.dto.expotokens;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class NotificacaoEnviarDTO {
    private List<Integer> usuarioIds;
    private String titulo;
    private String mensagem;
    private String dados;

    public NotificacaoEnviarDTO() {}

    public List<Integer> getUsuarioIds() { return usuarioIds; }
    public void setUsuarioIds(List<Integer> usuarioIds) { this.usuarioIds = usuarioIds; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getMensagem() { return mensagem; }
    public void setMensagem(String mensagem) { this.mensagem = mensagem; }

    public String getDados() { return dados; }
    public void setDados(String dados) { this.dados = dados; }

}
