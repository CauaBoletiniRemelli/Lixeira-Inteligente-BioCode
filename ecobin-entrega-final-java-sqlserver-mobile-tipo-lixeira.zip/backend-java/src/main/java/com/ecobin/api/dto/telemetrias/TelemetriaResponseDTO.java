package com.ecobin.api.dto.telemetrias;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class TelemetriaResponseDTO {
    private Integer id;
    private Integer sensorId;
    private LocalDateTime momento;
    private Integer nivelOcupacao;
    private Boolean alertaGerado;
    private String mensagem;

    public TelemetriaResponseDTO() {}

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getSensorId() { return sensorId; }
    public void setSensorId(Integer sensorId) { this.sensorId = sensorId; }

    public LocalDateTime getMomento() { return momento; }
    public void setMomento(LocalDateTime momento) { this.momento = momento; }

    public Integer getNivelOcupacao() { return nivelOcupacao; }
    public void setNivelOcupacao(Integer nivelOcupacao) { this.nivelOcupacao = nivelOcupacao; }

    public Boolean getAlertaGerado() { return alertaGerado; }
    public void setAlertaGerado(Boolean alertaGerado) { this.alertaGerado = alertaGerado; }

    public String getMensagem() { return mensagem; }
    public void setMensagem(String mensagem) { this.mensagem = mensagem; }

}
