package com.ecobin.api.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "CONdominios")
public class CondominiosModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "CONNome", nullable = false, length = 100)
    private String nome;

    @Column(name = "CONEndereco", length = 255)
    private String endereco;

    @Column(name = "CONCep", length = 9)
    private String cep;

    @Column(name = "CONCriadoEm")
    private LocalDateTime criadoEm;

    @Column(name = "CONAtivo")
    private Boolean ativo;

    @JsonIgnore
    @OneToMany(mappedBy = "condominio", fetch = FetchType.LAZY)
    private List<SensoresModel> sensores = new ArrayList<>();

    @JsonIgnore
    @OneToMany(mappedBy = "condominio", fetch = FetchType.LAZY)
    private List<UsuariosModel> usuarios = new ArrayList<>();

    @PrePersist
    public void prePersist() {
        if (criadoEm == null) criadoEm = LocalDateTime.now();
    }

    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
    public String getEndereco(){return endereco;} public void setEndereco(String endereco){this.endereco=endereco;}
    public String getCep(){return cep;} public void setCep(String cep){this.cep=cep;}
    public LocalDateTime getCriadoEm(){return criadoEm;} public void setCriadoEm(LocalDateTime criadoEm){this.criadoEm=criadoEm;}
    public Boolean getAtivo(){return ativo;} public void setAtivo(Boolean ativo){this.ativo=ativo;}
    public List<SensoresModel> getSensores(){return sensores;} public void setSensores(List<SensoresModel> sensores){this.sensores=sensores;}
    public List<UsuariosModel> getUsuarios(){return usuarios;} public void setUsuarios(List<UsuariosModel> usuarios){this.usuarios=usuarios;}
}
