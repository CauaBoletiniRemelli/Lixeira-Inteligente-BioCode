package com.ecobin.api.repositories;

import com.ecobin.api.models.CondominiosModel;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CondominiosRepository extends JpaRepository<CondominiosModel, Integer> {
}
