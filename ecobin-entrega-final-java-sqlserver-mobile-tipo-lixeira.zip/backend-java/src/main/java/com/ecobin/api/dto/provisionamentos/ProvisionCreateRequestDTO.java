package com.ecobin.api.dto.provisionamentos;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ProvisionCreateRequestDTO {
    private Integer sensorId;
    private Integer usuarioId;
    private Integer expiracaoDias;

    public ProvisionCreateRequestDTO() {}

    public Integer getSensorId() { return sensorId; }
    public void setSensorId(Integer sensorId) { this.sensorId = sensorId; }

    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer usuarioId) { this.usuarioId = usuarioId; }

    public Integer getExpiracaoDias() { return expiracaoDias; }
    public void setExpiracaoDias(Integer expiracaoDias) { this.expiracaoDias = expiracaoDias; }

}
