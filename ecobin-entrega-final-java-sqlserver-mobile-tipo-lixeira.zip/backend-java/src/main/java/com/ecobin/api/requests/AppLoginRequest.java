package com.ecobin.api.requests;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class AppLoginRequest {
    private String appId;
    private String appSecret;

    public AppLoginRequest() {}

    public String getAppId() { return appId; }
    public void setAppId(String appId) { this.appId = appId; }

    public String getAppSecret() { return appSecret; }
    public void setAppSecret(String appSecret) { this.appSecret = appSecret; }

}
