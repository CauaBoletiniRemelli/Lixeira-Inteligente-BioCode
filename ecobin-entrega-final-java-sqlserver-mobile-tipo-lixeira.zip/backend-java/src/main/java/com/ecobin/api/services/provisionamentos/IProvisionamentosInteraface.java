package com.ecobin.api.services.provisionamentos;

import com.ecobin.api.dto.devices.WifiCredentialsResponseDTO;
import com.ecobin.api.dto.provisionamentos.*;
import com.ecobin.api.models.*;
import java.util.List;

public interface IProvisionamentosInteraface {
    ResponseModel<ProvisionamentosModel> createProvisionamentoAsync(ProvisionCreateRequestDTO dto);
    ResponseModel<ProvisionamentosModel> createProvisionamentoComSensorAsync(ProvisionCreateWithSensorDTO dto);
    ResponseModel<List<ProvisionamentosModel>> getProvisionamentosAsync();
    ResponseModel<ProvisionamentosModel> getProvisionamentoByIdAsync(Integer id);
    ResponseModel<ProvisionQrResponseDTO> createQrCodeProvisionamentoAsync(Integer provisionId);
    ResponseModel<ProvisionActivateResponseDTO> activateProvisionAsync(ProvisionActivateRequestDTO dto, Integer userIdFromClaim);
    ResponseModel<Boolean> confirmDeviceConfigAsync(String deviceId, com.ecobin.api.dto.devices.ConfirmConfigDTO dto);
    ResponseModel<WifiCredentialsResponseDTO> getWifiCredentialsAsync(String deviceId, String sessionToken);
    ResponseModel<Object> assignWifiToSessionAsync(String sessionToken, AssignWifiRequestDTO dto);
}
