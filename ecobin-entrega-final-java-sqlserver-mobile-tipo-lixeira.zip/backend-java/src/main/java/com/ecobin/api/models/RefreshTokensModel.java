package com.ecobin.api.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "REFreshTokens")
public class RefreshTokensModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "REF_USUId", nullable = false)
    private Integer usuarioId;

    @Column(name = "REFToken", nullable=false, unique=true, length=500)
    private String token;

    @Column(name = "REFExpiracao", nullable = false)
    private LocalDateTime expiracao;

    @Column(name = "REFCriadoEm")
    private LocalDateTime criadoEm;

    @Column(name = "REFRevogado")
    private Boolean revogado = false;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "REF_USUId", insertable = false, updatable = false)
    @JsonIgnore
    private UsuariosModel usuario;

    @PrePersist public void prePersist(){ if(criadoEm==null) criadoEm=LocalDateTime.now(); if(revogado==null) revogado=false; }

    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Integer getUsuarioId(){return usuarioId;} public void setUsuarioId(Integer usuarioId){this.usuarioId=usuarioId;}
    public String getToken(){return token;} public void setToken(String token){this.token=token;}
    public LocalDateTime getExpiracao(){return expiracao;} public void setExpiracao(LocalDateTime expiracao){this.expiracao=expiracao;}
    public LocalDateTime getCriadoEm(){return criadoEm;} public void setCriadoEm(LocalDateTime criadoEm){this.criadoEm=criadoEm;}
    public Boolean getRevogado(){return revogado;} public void setRevogado(Boolean revogado){this.revogado=revogado;}
    public UsuariosModel getUsuario(){return usuario;} public void setUsuario(UsuariosModel usuario){this.usuario=usuario;}
}
