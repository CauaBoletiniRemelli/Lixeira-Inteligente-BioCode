package com.ecobin.api.services.condominio;

import com.ecobin.api.dto.condominios.CondominioEditDTO;
import com.ecobin.api.dto.condominios.CondominiosCreateDTO;
import com.ecobin.api.models.CondominiosModel;
import com.ecobin.api.models.ResponseModel;
import com.ecobin.api.repositories.CondominiosRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CondominioService implements ICondominioInterface {
    private final CondominiosRepository condominiosRepository;

    public CondominioService(CondominiosRepository condominiosRepository) {
        this.condominiosRepository = condominiosRepository;
    }

    @Override
    public ResponseModel<List<CondominiosModel>> getCondominios() {
        ResponseModel<List<CondominiosModel>> response = new ResponseModel<>();
        try {
            List<CondominiosModel> condominios = condominiosRepository.findAll();
            if (!condominios.isEmpty()) {
                response.setDados(condominios);
                response.setMensagem("Condomínios encontrados com sucesso.");
                response.setStatus(true);
                return response;
            }
            response.setMensagem("Nenhum condomínio encontrado.");
            response.setStatus(false);
            return response;
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
            return response;
        }
    }

    @Override
    public ResponseModel<CondominiosModel> createCondominio(CondominiosCreateDTO dto) {
        ResponseModel<CondominiosModel> response = new ResponseModel<>();
        try {
            CondominiosModel condominio = new CondominiosModel();
            condominio.setCriadoEm(LocalDateTime.now());
            condominio.setNome(dto.getNome());
            condominio.setEndereco(dto.getEndereco());
            condominio.setCep(dto.getCep());
            condominio.setAtivo(dto.getAtivo());

            condominiosRepository.save(condominio);

            response.setDados(condominio);
            response.setMensagem("Condomínio criado com sucesso.");
            response.setStatus(true);
            return response;
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
            return response;
        }
    }

    @Override
    public ResponseModel<CondominiosModel> updateCondominio(CondominioEditDTO dto) {
        ResponseModel<CondominiosModel> response = new ResponseModel<>();
        try {
            CondominiosModel condominio = condominiosRepository.findById(dto.getId()).orElse(null);
            if (condominio == null) {
                response.setMensagem("Nenhum condomínio localizado!");
                response.setStatus(false);
                return response;
            }

            if (!isNullOrWhiteSpace(dto.getNome()) || !equals(condominio.getNome(), dto.getNome())) {
                condominio.setNome(dto.getNome());
            }
            if (!isNullOrWhiteSpace(dto.getEndereco()) || !equals(condominio.getEndereco(), dto.getEndereco())) {
                condominio.setEndereco(dto.getEndereco());
            }
            if (!isNullOrWhiteSpace(dto.getCep()) || !equals(condominio.getCep(), dto.getCep())) {
                condominio.setCep(dto.getCep());
            }
            if (!equals(condominio.getAtivo(), dto.getAtivo())) {
                condominio.setAtivo(dto.getAtivo());
            }

            condominiosRepository.save(condominio);
            response.setDados(condominio);
            response.setMensagem("Condomínio atualizado com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }
        return response;
    }

    @Override
    public ResponseModel<List<CondominiosModel>> deleteCondominio(Integer idCond) {
        ResponseModel<List<CondominiosModel>> response = new ResponseModel<>();
        try {
            CondominiosModel condominio = condominiosRepository.findById(idCond).orElse(null);
            if (condominio == null) {
                response.setMensagem("Nenhum condomínio localizado!");
                response.setStatus(false);
                return response;
            }

            condominiosRepository.delete(condominio);
            response.setDados(condominiosRepository.findAll());
            response.setMensagem("Condomínio removido com sucesso!");
            response.setStatus(true);
        } catch (Exception ex) {
            response.setMensagem(ex.getMessage());
            response.setStatus(false);
        }
        return response;
    }

    private boolean isNullOrWhiteSpace(String value) {
        return value == null || value.trim().isEmpty();
    }

    private boolean equals(Object a, Object b) {
        return java.util.Objects.equals(a, b);
    }
}
