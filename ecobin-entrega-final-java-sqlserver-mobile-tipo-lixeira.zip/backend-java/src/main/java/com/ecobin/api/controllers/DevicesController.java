package com.ecobin.api.controllers;

import com.ecobin.api.dto.devices.ConfirmConfigDTO;
import com.ecobin.api.models.ResponseModel;
import com.ecobin.api.services.provisionamentos.IProvisionamentosInteraface;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/Devices")
public class DevicesController {
    private final IProvisionamentosInteraface provService;

    public DevicesController(IProvisionamentosInteraface provService) {
        this.provService = provService;
    }

    @GetMapping("/{deviceId}/wifi-credentials")
    public ResponseEntity<?> getWifiCredentials(@PathVariable String deviceId, @RequestParam String sessionToken) {
        if (sessionToken == null || sessionToken.isBlank()) return ResponseEntity.badRequest().body(Map.of("message", "sessionToken é obrigatório"));
        var response = provService.getWifiCredentialsAsync(deviceId, sessionToken);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.status(401).body(response);
    }

    @PostMapping("/{deviceId}/confirm-config")
    public ResponseEntity<?> confirmConfig(@PathVariable String deviceId, @RequestBody ConfirmConfigDTO dto) {
        ResponseModel<Boolean> response = provService.confirmDeviceConfigAsync(deviceId, dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }
}
