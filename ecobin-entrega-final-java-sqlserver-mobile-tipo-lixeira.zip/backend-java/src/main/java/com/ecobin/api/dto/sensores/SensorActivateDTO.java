package com.ecobin.api.dto.sensores;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class SensorActivateDTO {
    private String deviceId;
    private String deviceKey;
    private Integer sessionId;
    private String sessionToken;
    private String nomeSensor;
    @JsonAlias({"Tipo", "tipoLixeira", "TipoLixeira"})
    private String tipo;
    private Integer condominioId;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private String wifiSSID;
    private String wifiPassword;

    public SensorActivateDTO() {}

    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public String getDeviceKey() { return deviceKey; }
    public void setDeviceKey(String deviceKey) { this.deviceKey = deviceKey; }

    public Integer getSessionId() { return sessionId; }
    public void setSessionId(Integer sessionId) { this.sessionId = sessionId; }

    public String getSessionToken() { return sessionToken; }
    public void setSessionToken(String sessionToken) { this.sessionToken = sessionToken; }

    public String getNomeSensor() { return nomeSensor; }
    public void setNomeSensor(String nomeSensor) { this.nomeSensor = nomeSensor; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public Integer getCondominioId() { return condominioId; }
    public void setCondominioId(Integer condominioId) { this.condominioId = condominioId; }

    public BigDecimal getLatitude() { return latitude; }
    public void setLatitude(BigDecimal latitude) { this.latitude = latitude; }

    public BigDecimal getLongitude() { return longitude; }
    public void setLongitude(BigDecimal longitude) { this.longitude = longitude; }

    public String getWifiSSID() { return wifiSSID; }
    public void setWifiSSID(String wifiSSID) { this.wifiSSID = wifiSSID; }

    public String getWifiPassword() { return wifiPassword; }
    public void setWifiPassword(String wifiPassword) { this.wifiPassword = wifiPassword; }

}
