package com.ecobin.api.dto.telemetrias;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class StatusLixeiraDTO {
    private Integer sensorId;
    private String nome;
    private String tipoLixeira;
    private Integer nivelOcupacao;
    private String statusCor;
    private String statusLabel;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private LocalDateTime ultimaLeitura;

    public Integer getSensorId() { return sensorId; }
    public void setSensorId(Integer sensorId) { this.sensorId = sensorId; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getTipoLixeira() { return tipoLixeira; }
    public void setTipoLixeira(String tipoLixeira) { this.tipoLixeira = tipoLixeira; }

    public Integer getNivelOcupacao() { return nivelOcupacao; }
    public void setNivelOcupacao(Integer nivelOcupacao) { this.nivelOcupacao = nivelOcupacao; }

    public String getStatusCor() { return statusCor; }
    public void setStatusCor(String statusCor) { this.statusCor = statusCor; }

    public String getStatusLabel() { return statusLabel; }
    public void setStatusLabel(String statusLabel) { this.statusLabel = statusLabel; }

    public BigDecimal getLatitude() { return latitude; }
    public void setLatitude(BigDecimal latitude) { this.latitude = latitude; }

    public BigDecimal getLongitude() { return longitude; }
    public void setLongitude(BigDecimal longitude) { this.longitude = longitude; }

    public LocalDateTime getUltimaLeitura() { return ultimaLeitura; }
    public void setUltimaLeitura(LocalDateTime ultimaLeitura) { this.ultimaLeitura = ultimaLeitura; }
}
