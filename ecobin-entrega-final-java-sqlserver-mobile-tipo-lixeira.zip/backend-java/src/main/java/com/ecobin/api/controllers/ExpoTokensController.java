package com.ecobin.api.controllers;

import com.ecobin.api.dto.expotokens.*;
import com.ecobin.api.services.expotokens.IExpoTokensInterface;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/ExpoTokens")
@PreAuthorize("isAuthenticated()")
public class ExpoTokensController {
    private final IExpoTokensInterface expoTokensService;

    public ExpoTokensController(IExpoTokensInterface expoTokensService) {
        this.expoTokensService = expoTokensService;
    }

    @PostMapping("/token")
    public ResponseEntity<?> salvarToken(@RequestBody ExpoTokenCreateDTO dto) {
        var response = expoTokensService.salvarTokenAsync(dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @GetMapping("/tokens/usuario/{usuarioId}")
    public ResponseEntity<?> listarTokensPorUsuario(@PathVariable Integer usuarioId) {
        var response = expoTokensService.listarTokensPorUsuarioAsync(usuarioId);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @DeleteMapping("/token/{tokenId}")
    public ResponseEntity<?> desativarToken(@PathVariable Integer tokenId) {
        var response = expoTokensService.desativarTokenAsync(tokenId);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PostMapping("/notificacoes/enviar-todos")
    public ResponseEntity<?> enviarParaTodos(@RequestBody NotificacaoCreateDTO dto) {
        var response = expoTokensService.enviarNotificacaoParaTodosAsync(dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PostMapping("/notificacoes/enviar")
    public ResponseEntity<?> enviarParaUsuarios(@RequestBody NotificacaoEnviarDTO dto) {
        var response = expoTokensService.enviarNotificacaoParaUsuariosAsync(dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PostMapping("/notificacoes/enviar-usuario/{usuarioId}")
    public ResponseEntity<?> enviarParaUsuario(@PathVariable Integer usuarioId, @RequestBody NotificacaoCreateDTO dto) {
        var response = expoTokensService.enviarNotificacaoParaUsuarioAsync(usuarioId, dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PostMapping("/notificacoes/enviar-condominio/{condominioId}")
    public ResponseEntity<?> enviarParaCondominio(@PathVariable Integer condominioId, @RequestBody NotificacaoCreateDTO dto) {
        var response = expoTokensService.enviarNotificacaoParaCondominioAsync(condominioId, dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PostMapping("/notificacoes/enviar-condominio-tipo")
    public ResponseEntity<?> enviarParaCondominioTipo(@RequestBody NotificacaoCondominioTipoDTO dto) {
        var response = expoTokensService.enviarNotificacaoParaCondominioTipoAsync(dto);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @GetMapping("/notificacoes/usuario/{usuarioId}")
    public ResponseEntity<?> listarNotificacoesPorUsuario(@PathVariable Integer usuarioId) {
        var response = expoTokensService.listarNotificacoesPorUsuarioAsync(usuarioId);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @GetMapping("/notificacoes/usuario/{usuarioId}/nao-lidas")
    public ResponseEntity<?> listarNotificacoesNaoLidas(@PathVariable Integer usuarioId) {
        var response = expoTokensService.listarNotificacoesNaoLidasAsync(usuarioId);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PutMapping("/notificacoes/{notificacaoId}/marcar-lida")
    public ResponseEntity<?> marcarComoLida(@PathVariable Integer notificacaoId) {
        var response = expoTokensService.marcarComoLidaAsync(notificacaoId);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PutMapping("/notificacoes/usuario/{usuarioId}/marcar-todas-lidas")
    public ResponseEntity<?> marcarTodasComoLidas(@PathVariable Integer usuarioId) {
        var response = expoTokensService.marcarTodasComoLidasAsync(usuarioId);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @DeleteMapping("/limpeza")
    public ResponseEntity<?> deleteNotificacoesAntigas(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataLimite) {
        var response = expoTokensService.deletarNotificacoesAntigasAsync(dataLimite);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }
}
