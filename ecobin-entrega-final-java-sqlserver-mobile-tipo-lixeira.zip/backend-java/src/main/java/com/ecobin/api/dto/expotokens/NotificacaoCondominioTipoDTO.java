package com.ecobin.api.dto.expotokens;

import com.ecobin.api.enums.TipoUsuario;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class NotificacaoCondominioTipoDTO {
    private Integer condominioId;
    private TipoUsuario tipoUsuario;
    private String titulo;
    private String mensagem;
    private String dados;

    public NotificacaoCondominioTipoDTO() {}

    public Integer getCondominioId() { return condominioId; }
    public void setCondominioId(Integer condominioId) { this.condominioId = condominioId; }

    public TipoUsuario getTipoUsuario() { return tipoUsuario; }
    public void setTipoUsuario(TipoUsuario tipoUsuario) { this.tipoUsuario = tipoUsuario; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getMensagem() { return mensagem; }
    public void setMensagem(String mensagem) { this.mensagem = mensagem; }

    public String getDados() { return dados; }
    public void setDados(String dados) { this.dados = dados; }

}
