package com.ecobin.api.services.expotokens;

import com.ecobin.api.dto.expotokens.*;
import com.ecobin.api.models.*;
import java.time.LocalDateTime;
import java.util.List;

public interface IExpoTokensInterface {
    ResponseModel<ExpoTokensModel> salvarTokenAsync(ExpoTokenCreateDTO dto);
    ResponseModel<List<ExpoTokensModel>> listarTokensPorUsuarioAsync(Integer usuarioId);
    ResponseModel<ExpoTokensModel> desativarTokenAsync(Integer tokenId);
    ResponseModel<List<NotificacoesModel>> enviarNotificacaoParaTodosAsync(NotificacaoCreateDTO dto);
    ResponseModel<List<NotificacoesModel>> enviarNotificacaoParaUsuariosAsync(NotificacaoEnviarDTO dto);
    ResponseModel<NotificacoesModel> enviarNotificacaoParaUsuarioAsync(Integer usuarioId, NotificacaoCreateDTO dto);
    ResponseModel<List<NotificacoesModel>> enviarNotificacaoParaCondominioAsync(Integer condominioId, NotificacaoCreateDTO dto);
    ResponseModel<List<NotificacoesModel>> enviarNotificacaoParaCondominioTipoAsync(NotificacaoCondominioTipoDTO dto);
    ResponseModel<List<NotificacoesModel>> listarNotificacoesPorUsuarioAsync(Integer usuarioId);
    ResponseModel<List<NotificacoesModel>> listarNotificacoesNaoLidasAsync(Integer usuarioId);
    ResponseModel<NotificacoesModel> marcarComoLidaAsync(Integer notificacaoId);
    ResponseModel<Boolean> marcarTodasComoLidasAsync(Integer usuarioId);
    ResponseModel<Integer> deletarNotificacoesAntigasAsync(LocalDateTime dataLimite);
}
