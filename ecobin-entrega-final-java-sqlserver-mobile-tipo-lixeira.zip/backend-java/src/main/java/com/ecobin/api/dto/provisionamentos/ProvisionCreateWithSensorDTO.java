package com.ecobin.api.dto.provisionamentos;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ProvisionCreateWithSensorDTO {
    private String nomeSensor;
    @JsonAlias({"Tipo", "tipoLixeira", "TipoLixeira"})
    private String tipo;
    private Integer condominioId;
    private Integer usuarioId;
    private Integer expiracaoDias;

    public ProvisionCreateWithSensorDTO() {}

    public String getNomeSensor() { return nomeSensor; }
    public void setNomeSensor(String nomeSensor) { this.nomeSensor = nomeSensor; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public Integer getCondominioId() { return condominioId; }
    public void setCondominioId(Integer condominioId) { this.condominioId = condominioId; }

    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer usuarioId) { this.usuarioId = usuarioId; }

    public Integer getExpiracaoDias() { return expiracaoDias; }
    public void setExpiracaoDias(Integer expiracaoDias) { this.expiracaoDias = expiracaoDias; }

}
