package com.ecobin.api.dto.provisionamentos;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ProvisionQrResponseDTO {
    private byte[] qrBytes;
    private String mediaType;

    public ProvisionQrResponseDTO() {}

    public byte[] getQrBytes() { return qrBytes; }
    public void setQrBytes(byte[] qrBytes) { this.qrBytes = qrBytes; }

    public String getMediaType() { return mediaType; }
    public void setMediaType(String mediaType) { this.mediaType = mediaType; }

}
