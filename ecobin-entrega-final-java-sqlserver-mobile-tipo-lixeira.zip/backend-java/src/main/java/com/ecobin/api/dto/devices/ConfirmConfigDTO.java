package com.ecobin.api.dto.devices;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ConfirmConfigDTO {
    private String sessionToken;
    private Boolean wifiConnected;
    private String message;

    public ConfirmConfigDTO() {}

    public String getSessionToken() { return sessionToken; }
    public void setSessionToken(String sessionToken) { this.sessionToken = sessionToken; }

    public Boolean getWifiConnected() { return wifiConnected; }
    public void setWifiConnected(Boolean wifiConnected) { this.wifiConnected = wifiConnected; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

}
