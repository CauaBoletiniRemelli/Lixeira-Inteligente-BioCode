package com.ecobin.api.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "NOTificacoes")
public class NotificacoesModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "NOT_EXPId")
    private Integer expoTokenId;

    @Column(name = "NOT_USUId")
    private Integer usuarioId;

    @Column(name = "NOTTitulo", nullable = false, length = 255)
    private String titulo;

    @Column(name = "NOTMensagem", nullable = false, length = 1000)
    private String mensagem;

    @Column(name = "NOTDados", columnDefinition = "TEXT")
    private String dados;

    @Column(name = "NOTDataEnvio")
    private LocalDateTime dataEnvio;

    @Column(name = "NOTLida")
    private Boolean lida = false;

    @Column(name = "NOTDataLeitura")
    private LocalDateTime dataLeitura;

    @Column(name = "NOTEnviada")
    private Boolean enviada = false;

    @Column(name = "NOTErro", length = 500)
    private String erro;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "NOT_EXPId", insertable = false, updatable = false)
    @JsonIgnore
    private ExpoTokensModel expoToken;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "NOT_USUId", insertable = false, updatable = false)
    @JsonIgnore
    private UsuariosModel usuario;

    @PrePersist public void prePersist(){ if(dataEnvio==null) dataEnvio=LocalDateTime.now(); if(lida==null) lida=false; if(enviada==null) enviada=false; }

    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Integer getExpoTokenId(){return expoTokenId;} public void setExpoTokenId(Integer expoTokenId){this.expoTokenId=expoTokenId;}
    public Integer getUsuarioId(){return usuarioId;} public void setUsuarioId(Integer usuarioId){this.usuarioId=usuarioId;}
    public String getTitulo(){return titulo;} public void setTitulo(String titulo){this.titulo=titulo;}
    public String getMensagem(){return mensagem;} public void setMensagem(String mensagem){this.mensagem=mensagem;}
    public String getDados(){return dados;} public void setDados(String dados){this.dados=dados;}
    public LocalDateTime getDataEnvio(){return dataEnvio;} public void setDataEnvio(LocalDateTime dataEnvio){this.dataEnvio=dataEnvio;}
    public Boolean getLida(){return lida;} public void setLida(Boolean lida){this.lida=lida;}
    public LocalDateTime getDataLeitura(){return dataLeitura;} public void setDataLeitura(LocalDateTime dataLeitura){this.dataLeitura=dataLeitura;}
    public Boolean getEnviada(){return enviada;} public void setEnviada(Boolean enviada){this.enviada=enviada;}
    public String getErro(){return erro;} public void setErro(String erro){this.erro=erro;}
    public ExpoTokensModel getExpoToken(){return expoToken;} public void setExpoToken(ExpoTokensModel expoToken){this.expoToken=expoToken;}
    public UsuariosModel getUsuario(){return usuario;} public void setUsuario(UsuariosModel usuario){this.usuario=usuario;}
}
