package com.ecobin.api.controllers;

import com.ecobin.api.dto.condominios.*;
import com.ecobin.api.models.*;
import com.ecobin.api.services.condominio.ICondominioInterface;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/Condominios")
public class CondominiosController {
    private final ICondominioInterface condominioInterface;

    public CondominiosController(ICondominioInterface condominioInterface) {
        this.condominioInterface = condominioInterface;
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @GetMapping
    public ResponseEntity<ResponseModel<List<CondominiosModel>>> getCondominios() {
        ResponseModel<List<CondominiosModel>> response = condominioInterface.getCondominios();
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @PostMapping
    public ResponseEntity<ResponseModel<CondominiosModel>> postCondominio(@RequestBody CondominiosCreateDTO condominio) {
        ResponseModel<CondominiosModel> response = condominioInterface.createCondominio(condominio);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @PutMapping
    public ResponseEntity<ResponseModel<CondominiosModel>> updateCondominio(@RequestBody CondominioEditDTO condominio) {
        ResponseModel<CondominiosModel> response = condominioInterface.updateCondominio(condominio);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }

    @PreAuthorize("hasAuthority('AdminOnly')")
    @DeleteMapping("/{idCond}")
    public ResponseEntity<ResponseModel<List<CondominiosModel>>> deleteCondominio(@PathVariable Integer idCond) {
        ResponseModel<List<CondominiosModel>> response = condominioInterface.deleteCondominio(idCond);
        return response.isStatus() ? ResponseEntity.ok(response) : ResponseEntity.badRequest().body(response);
    }
}
