package com.ecobin.api.enums;

public enum TipoUsuario {
    NaoIdentificado(0),
    Administrador(1),
    Sindico(2),
    Coletor(3),
    Aplicativo(5),
    Arduino(6);

    private final int valor;
    TipoUsuario(int valor) { this.valor = valor; }
    public int getValor() { return valor; }

    public static TipoUsuario fromValor(int valor) {
        for (TipoUsuario tipo : values()) {
            if (tipo.valor == valor) return tipo;
        }
        return NaoIdentificado;
    }
}
