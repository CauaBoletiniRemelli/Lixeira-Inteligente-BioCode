package com.ecobin.api.dto.expotokens;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ExpoTokenCreateDTO {
    private Integer usuarioId;
    private String token;
    private String dispositivo;
    private String plataforma;

    public ExpoTokenCreateDTO() {}

    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer usuarioId) { this.usuarioId = usuarioId; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getDispositivo() { return dispositivo; }
    public void setDispositivo(String dispositivo) { this.dispositivo = dispositivo; }

    public String getPlataforma() { return plataforma; }
    public void setPlataforma(String plataforma) { this.plataforma = plataforma; }

}
