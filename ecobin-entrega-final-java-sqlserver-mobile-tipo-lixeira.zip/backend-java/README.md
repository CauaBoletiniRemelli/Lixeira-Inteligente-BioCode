# EcoBin API Java — Conversão fiel do backend C#

Este projeto foi reorganizado para manter a API/backend o mais próxima possível da versão original em C# ASP.NET Core, mudando a linguagem para Java + Spring Boot.

## O que foi mantido da versão C#

- Controllers com nomes equivalentes
- Rotas principais equivalentes
- DTOs equivalentes
- Models equivalentes
- ResponseModel com `dados`, `mensagem`, `status`, `qrCodeBytes`, `sessionToken` e `sessionExpires`
- Separação por services/interfaces, semelhante ao padrão usado no C#
- Policies equivalentes:
  - `AdminOnly`
  - `AppOnly`
  - `ArduinoOnly`
- JWT com claim `Tipo` baseada nos valores do enum original
- Banco via JPA/Hibernate
- Repositories equivalentes ao papel do Entity Framework DbContext

## Tecnologias

- Java 17
- Spring Boot 3.3.5
- Spring Web
- Spring Security
- Spring Data JPA
- SQLite Database

## Como rodar

```bash
cd ecobin-api-java
mvn spring-boot:run
```

A API sobe em:

```text
http://localhost:8080
```

Banco SQLite local:

```text
./data/ecobin.db
```

Credenciais iniciais:

```text
email: admin@ecobin.com
senha: 123456
```

## Rotas principais mantidas

### Auth

```text
POST /api/Auth/AppLogin
POST /api/Auth/ArduinoLogin
POST /api/Auth/Login
POST /api/Auth/RefreshToken
POST /api/Auth/Logout
POST /api/Auth/forgot-password?usuEmail=email@teste.com
```

### Condomínios

```text
GET    /api/Condominios
POST   /api/Condominios
PUT    /api/Condominios
DELETE /api/Condominios/{idCond}
```

### Usuários

```text
GET    /api/Usuarios
GET    /api/Usuarios/{idUser}
POST   /api/Usuarios
PUT    /api/Usuarios
DELETE /api/Usuarios/{idUser}
POST   /api/Usuarios/change-password
POST   /api/Usuarios/change-email
```

### Sensores

```text
GET    /api/Sensores
POST   /api/Sensores
GET    /api/Sensores/{idCondominio}
PUT    /api/Sensores
PUT    /api/Sensores/update-locale-{idSensor}
DELETE /api/Sensores/{idSensor}
```

### Provisionamentos

```text
GET  /api/Provisionamentos
GET  /api/Provisionamentos/{id}
POST /api/Provisionamentos/criar
POST /api/Provisionamentos/criar-com-sensor
GET  /api/Provisionamentos/gerar-qr/{provisionId}
POST /api/Provisionamentos/ativar-qr
POST /api/Provisionamentos/{sessionToken}/assign-wifi
GET  /api/Provisionamentos/wifi-credentials/{deviceId}?sessionToken=...
POST /api/Provisionamentos/confirm-config/{deviceId}
```

### Devices

```text
GET  /api/Devices/{deviceId}/wifi-credentials?sessionToken=...
POST /api/Devices/{deviceId}/confirm-config
```

### Telemetrias

```text
POST   /api/Telemetrias
POST   /api/Telemetrias/arduino
GET    /api/Telemetrias
POST   /api/Telemetrias/filtrar
GET    /api/Telemetrias/sensor/{sensorId}
GET    /api/Telemetrias/sensor/{sensorId}/ultima
GET    /api/Telemetrias/condominio/{condominioId}
GET    /api/Telemetrias/sensor/{sensorId}/estatisticas
GET    /api/Telemetrias/condominio/{condominioId}/estatisticas
DELETE /api/Telemetrias/limpeza?dataLimite=2026-01-01T00:00:00
```

### Expo Tokens / Notificações

```text
POST   /api/ExpoTokens/token
GET    /api/ExpoTokens/tokens/usuario/{usuarioId}
DELETE /api/ExpoTokens/token/{tokenId}
POST   /api/ExpoTokens/notificacoes/enviar-todos
POST   /api/ExpoTokens/notificacoes/enviar
POST   /api/ExpoTokens/notificacoes/enviar-usuario/{usuarioId}
POST   /api/ExpoTokens/notificacoes/enviar-condominio/{condominioId}
POST   /api/ExpoTokens/notificacoes/enviar-condominio-tipo
GET    /api/ExpoTokens/notificacoes/usuario/{usuarioId}
GET    /api/ExpoTokens/notificacoes/usuario/{usuarioId}/nao-lidas
PUT    /api/ExpoTokens/notificacoes/{notificacaoId}/marcar-lida
PUT    /api/ExpoTokens/notificacoes/usuario/{usuarioId}/marcar-todas-lidas
DELETE /api/ExpoTokens/limpeza?dataLimite=2026-01-01T00:00:00
```

## Observação importante

A conversão manteve a arquitetura e os fluxos da API original, mas alguns pontos que dependiam de bibliotecas específicas do C# foram adaptados para Java:

- QR Code: nesta versão, o endpoint retorna o payload em bytes. Caso queira PNG real, adicione uma biblioteca Java de QR Code.
- Criptografia Wi-Fi: foi mantido o comportamento de esconder/recuperar credenciais, usando Base64 para simplificar execução acadêmica. Pode ser trocado por AES depois.
- Banco: está em SQLite para rodar fácil na faculdade. O arquivo local fica em `./data/ecobin.db`. Pode ser migrado para MySQL/PostgreSQL alterando o `application.properties` e a dependência JDBC.
