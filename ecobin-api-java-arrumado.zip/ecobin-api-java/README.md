# EcoBin API Java — Spring Boot

Projeto migrado para Java/Spring Boot com estrutura real de backend:

- Spring Boot Web
- Spring Security
- JWT simples com HMAC SHA-256
- Spring Data JPA
- Banco H2 persistente em arquivo
- Repositories para as entidades principais
- CRUDs usando banco em vez de `Map` em memória
- Usuário administrador inicial

## Como rodar

```bash
mvn spring-boot:run
```

A API sobe em:

```text
http://localhost:8080
```

Console do banco H2:

```text
http://localhost:8080/h2-console
```

Configuração H2:

```text
JDBC URL: jdbc:h2:file:./data/ecobin
User: sa
Password: deixe vazio
```

## Login inicial

```json
{
  "email": "admin@ecobin.com",
  "password": "123456"
}
```

Endpoint:

```text
POST /api/Auth/Login
```

Use o token retornado no header:

```text
Authorization: Bearer SEU_TOKEN_AQUI
```

## Observação

O projeto agora persiste dados no banco H2. Se quiser usar MySQL ou PostgreSQL, basta trocar as configurações no `application.properties` e adicionar o driver correspondente no `pom.xml`.
