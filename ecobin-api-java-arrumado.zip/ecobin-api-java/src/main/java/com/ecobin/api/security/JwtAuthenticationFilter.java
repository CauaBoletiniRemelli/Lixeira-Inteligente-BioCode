package com.ecobin.api.security;

import com.ecobin.api.repositories.UsuariosRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    private final JwtService jwtService;
    private final UsuariosRepository usuariosRepository;
    public JwtAuthenticationFilter(JwtService jwtService, UsuariosRepository usuariosRepository) { this.jwtService = jwtService; this.usuariosRepository = usuariosRepository; }
    @Override protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String auth = request.getHeader("Authorization");
        if (auth != null && auth.startsWith("Bearer ")) {
            String token = auth.substring(7);
            String email = jwtService.getSubject(token);
            if (email != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                usuariosRepository.findByEmail(email).ifPresent(user -> {
                    String role = user.getTipo() == null ? "Morador" : user.getTipo().name();
                    var authentication = new UsernamePasswordAuthenticationToken(email, null, List.of(new SimpleGrantedAuthority(role), new SimpleGrantedAuthority(role + "Only")));
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                });
            }
        }
        filterChain.doFilter(request, response);
    }
}
