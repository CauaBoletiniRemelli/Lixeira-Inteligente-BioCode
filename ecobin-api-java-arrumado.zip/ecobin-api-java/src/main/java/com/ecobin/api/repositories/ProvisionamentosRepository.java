package com.ecobin.api.repositories;

import com.ecobin.api.models.ProvisionamentosModel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ProvisionamentosRepository extends JpaRepository<ProvisionamentosModel, Integer> {
    Optional<ProvisionamentosModel> findBySessionToken(String sessionToken);
}
