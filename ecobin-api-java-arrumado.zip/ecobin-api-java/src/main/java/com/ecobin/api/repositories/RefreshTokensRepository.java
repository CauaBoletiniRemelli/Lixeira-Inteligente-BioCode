package com.ecobin.api.repositories;

import com.ecobin.api.models.RefreshTokensModel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface RefreshTokensRepository extends JpaRepository<RefreshTokensModel, Integer> {
    Optional<RefreshTokensModel> findByToken(String token);
}
