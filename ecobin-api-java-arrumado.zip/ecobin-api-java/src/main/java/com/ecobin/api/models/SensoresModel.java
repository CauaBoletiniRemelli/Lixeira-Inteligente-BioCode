package com.ecobin.api.models;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "sensores")
public class SensoresModel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(unique = true)
    private String deviceId;
    private String deviceKey;
    private Integer status;
    private String nome;
    private Integer condominioId;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private LocalDateTime ultimaConexao;
    private LocalDateTime criadoEm;
    @Transient private List<ProvisionamentosModel> provisionamentos;
    @Transient private List<TelemetriasModel> telemetrias;
    @PrePersist public void prePersist(){ if(criadoEm==null) criadoEm=LocalDateTime.now(); if(status==null) status=1; }
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getDeviceId(){return deviceId;} public void setDeviceId(String deviceId){this.deviceId=deviceId;}
    public String getDeviceKey(){return deviceKey;} public void setDeviceKey(String deviceKey){this.deviceKey=deviceKey;}
    public Integer getStatus(){return status;} public void setStatus(Integer status){this.status=status;}
    public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
    public Integer getCondominioId(){return condominioId;} public void setCondominioId(Integer condominioId){this.condominioId=condominioId;}
    public BigDecimal getLatitude(){return latitude;} public void setLatitude(BigDecimal latitude){this.latitude=latitude;}
    public BigDecimal getLongitude(){return longitude;} public void setLongitude(BigDecimal longitude){this.longitude=longitude;}
    public LocalDateTime getUltimaConexao(){return ultimaConexao;} public void setUltimaConexao(LocalDateTime ultimaConexao){this.ultimaConexao=ultimaConexao;}
    public LocalDateTime getCriadoEm(){return criadoEm;} public void setCriadoEm(LocalDateTime criadoEm){this.criadoEm=criadoEm;}
    public List<ProvisionamentosModel> getProvisionamentos(){return provisionamentos;} public void setProvisionamentos(List<ProvisionamentosModel> provisionamentos){this.provisionamentos=provisionamentos;}
    public List<TelemetriasModel> getTelemetrias(){return telemetrias;} public void setTelemetrias(List<TelemetriasModel> telemetrias){this.telemetrias=telemetrias;}
}
