package com.ecobin.api.controllers;

import com.ecobin.api.enums.TipoUsuario;
import com.ecobin.api.models.*;
import com.ecobin.api.repositories.RefreshTokensRepository;
import com.ecobin.api.repositories.UsuariosRepository;
import com.ecobin.api.requests.*;
import com.ecobin.api.security.JwtService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.UUID;

@RestController
@RequestMapping("/api/Auth")
public class AuthController {
    private final UsuariosRepository usuariosRepository;
    private final RefreshTokensRepository refreshTokensRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    @Value("${app.refresh-token.expiration-days}") private long refreshDays;

    public AuthController(UsuariosRepository usuariosRepository, RefreshTokensRepository refreshTokensRepository, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.usuariosRepository = usuariosRepository;
        this.refreshTokensRepository = refreshTokensRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @PostMapping("/AppLogin")
    public ResponseEntity<ResponseModel<AuthModel>> appLogin(@RequestBody AppLoginRequest request) {
        if (!"ecobin-app".equals(request.getAppId()) || !"ecobin-secret".equals(request.getAppSecret())) return ResponseEntity.status(401).body(ResponseModel.<AuthModel>erro("AppId ou AppSecret inválidos"));
        UsuariosModel app = serviceUser("app@ecobin.local", "Aplicativo EcoBin", TipoUsuario.Morador);
        return ResponseEntity.ok(ResponseModel.ok(toAuth(app), "Login do app realizado"));
    }

    @PostMapping("/ArduinoLogin")
    public ResponseEntity<ResponseModel<AuthModel>> arduinoLogin(@RequestBody ArduinoLoginRequest request) {
        if (request.getArduinoId() == null || request.getArduinoSecret() == null || request.getArduinoId().isBlank() || request.getArduinoSecret().isBlank()) return ResponseEntity.status(401).body(ResponseModel.<AuthModel>erro("Credenciais do Arduino inválidas"));
        UsuariosModel arduino = serviceUser(request.getArduinoId() + "@arduino.local", "Arduino " + request.getArduinoId(), TipoUsuario.Arduino);
        return ResponseEntity.ok(ResponseModel.ok(toAuth(arduino), "Login do Arduino realizado"));
    }

    @PostMapping("/Login")
    public ResponseEntity<ResponseModel<AuthModel>> auth(@RequestBody LoginRequest request) {
        return usuariosRepository.findByEmail(request.getEmail())
            .filter(u -> passwordEncoder.matches(request.getPassword(), u.getSenhaHash()))
            .map(u -> ResponseEntity.ok(ResponseModel.ok(toAuth(u), "Login realizado")))
            .orElseGet(() -> ResponseEntity.status(401).body(ResponseModel.<AuthModel>erro("E-mail ou senha inválidos")));
    }

    @PostMapping("/RefreshToken")
    public ResponseEntity<ResponseModel<AuthModel>> refreshToken(@RequestBody RefreshTokenRequest request) {
        var refreshOpt = refreshTokensRepository.findByToken(request.getRefreshToken());
        if (refreshOpt.isEmpty()) return ResponseEntity.status(401).body(ResponseModel.<AuthModel>erro("Refresh token inválido ou expirado"));
        RefreshTokensModel refresh = refreshOpt.get();
        if (Boolean.TRUE.equals(refresh.getRevogado()) || refresh.getExpiracao() == null || refresh.getExpiracao().isBefore(LocalDateTime.now())) {
            return ResponseEntity.status(401).body(ResponseModel.<AuthModel>erro("Refresh token inválido ou expirado"));
        }
        var usuarioOpt = usuariosRepository.findById(refresh.getUsuarioId());
        if (usuarioOpt.isEmpty()) return ResponseEntity.status(401).body(ResponseModel.<AuthModel>erro("Usuário não encontrado"));
        return ResponseEntity.ok(ResponseModel.ok(toAuth(usuarioOpt.get()), "Token atualizado"));
    }

    @PostMapping("/Logout")
    public ResponseEntity<ResponseModel<Object>> logout(@RequestBody RefreshTokenRequest request) {
        refreshTokensRepository.findByToken(request.getRefreshToken()).ifPresent(t -> { t.setRevogado(true); refreshTokensRepository.save(t); });
        return ResponseEntity.ok(ResponseModel.ok(null, "Logout realizado"));
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<ResponseModel<UsuariosModel>> forgotMyPassword(@RequestParam String usuEmail) {
        return usuariosRepository.findByEmail(usuEmail)
            .map(u -> ResponseEntity.ok(ResponseModel.ok(u, "Usuário localizado para recuperação de senha")))
            .orElseGet(() -> ResponseEntity.badRequest().body(ResponseModel.<UsuariosModel>erro("E-mail não encontrado")));
    }

    private UsuariosModel serviceUser(String email, String nome, TipoUsuario tipo) {
        return usuariosRepository.findByEmail(email).orElseGet(() -> {
            UsuariosModel u = new UsuariosModel(); u.setNome(nome); u.setEmail(email); u.setSenhaHash(passwordEncoder.encode(UUID.randomUUID().toString())); u.setTipo(tipo); return usuariosRepository.save(u);
        });
    }

    private AuthModel toAuth(UsuariosModel user) {
        AuthModel auth = new AuthModel();
        auth.setEmail(user.getEmail()); auth.setNome(user.getNome()); auth.setUserId(user.getId()); auth.setTipo(user.getTipo()); auth.setCondominioId(user.getCondominioId());
        auth.setToken(jwtService.generateToken(user));
        RefreshTokensModel refresh = new RefreshTokensModel(); refresh.setUsuarioId(user.getId()); refresh.setToken(UUID.randomUUID().toString()); refresh.setExpiracao(LocalDateTime.now().plusDays(refreshDays)); refreshTokensRepository.save(refresh);
        auth.setRefreshToken(refresh.getToken());
        return auth;
    }
}
