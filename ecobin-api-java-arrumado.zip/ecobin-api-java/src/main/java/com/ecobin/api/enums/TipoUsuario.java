package com.ecobin.api.enums;

public enum TipoUsuario {
    NaoIdentificado,
    Admin,
    Sindico,
    Morador,
    Arduino
}
