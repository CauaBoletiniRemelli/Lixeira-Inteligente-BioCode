package com.ecobin.api.models;

import com.ecobin.api.enums.TipoUsuario;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "usuarios")
public class UsuariosModel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false)
    private String nome;
    @Column(nullable = false, unique = true)
    private String email;
    @JsonIgnore
    @Column(nullable = false)
    private String senhaHash;
    @Enumerated(EnumType.STRING)
    private TipoUsuario tipo;
    private Integer condominioId;
    private LocalDateTime criadoEm;
    @Transient
    private List<ProvisionamentosModel> provisionamentos;

    @PrePersist public void prePersist(){ if(criadoEm==null) criadoEm=LocalDateTime.now(); if(tipo==null) tipo=TipoUsuario.Morador; }
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
    public String getEmail(){return email;} public void setEmail(String email){this.email=email;}
    public String getSenhaHash(){return senhaHash;} public void setSenhaHash(String senhaHash){this.senhaHash=senhaHash;}
    public TipoUsuario getTipo(){return tipo;} public void setTipo(TipoUsuario tipo){this.tipo=tipo;}
    public Integer getCondominioId(){return condominioId;} public void setCondominioId(Integer condominioId){this.condominioId=condominioId;}
    public LocalDateTime getCriadoEm(){return criadoEm;} public void setCriadoEm(LocalDateTime criadoEm){this.criadoEm=criadoEm;}
    public List<ProvisionamentosModel> getProvisionamentos(){return provisionamentos;} public void setProvisionamentos(List<ProvisionamentosModel> provisionamentos){this.provisionamentos=provisionamentos;}
}
