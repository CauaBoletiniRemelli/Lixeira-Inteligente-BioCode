package com.ecobin.api.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "condominios")
public class CondominiosModel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(nullable = false)
    private String nome;
    private String endereco;
    private String cep;
    private LocalDateTime criadoEm;
    private Boolean ativo;
    @Transient
    private List<SensoresModel> sensores;

    @PrePersist
    public void prePersist() { if (criadoEm == null) criadoEm = LocalDateTime.now(); if (ativo == null) ativo = true; }
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public String getNome(){return nome;} public void setNome(String nome){this.nome=nome;}
    public String getEndereco(){return endereco;} public void setEndereco(String endereco){this.endereco=endereco;}
    public String getCep(){return cep;} public void setCep(String cep){this.cep=cep;}
    public LocalDateTime getCriadoEm(){return criadoEm;} public void setCriadoEm(LocalDateTime criadoEm){this.criadoEm=criadoEm;}
    public Boolean getAtivo(){return ativo;} public void setAtivo(Boolean ativo){this.ativo=ativo;}
    public List<SensoresModel> getSensores(){return sensores;} public void setSensores(List<SensoresModel> sensores){this.sensores=sensores;}
}
