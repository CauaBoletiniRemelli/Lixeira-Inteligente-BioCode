package com.ecobin.api.controllers;

import com.ecobin.api.dto.sensores.*;
import com.ecobin.api.models.*;
import com.ecobin.api.repositories.SensoresRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/Sensores")
public class SensoresController {
    private final SensoresRepository sensoresRepository;
    public SensoresController(SensoresRepository sensoresRepository) { this.sensoresRepository = sensoresRepository; }

    @PreAuthorize("isAuthenticated()")
    @GetMapping public ResponseEntity<ResponseModel<List<SensoresModel>>> getSensores(){ return ResponseEntity.ok(ResponseModel.ok(sensoresRepository.findAll(),"Sensores listados")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping public ResponseEntity<ResponseModel<SensoresModel>> createSensor(@RequestBody SensorCreateDTO dto){
        SensoresModel s=new SensoresModel();
        s.setNome(dto.getNome()); s.setDeviceId(dto.getDeviceId()); s.setDeviceKey(dto.getDeviceKey()==null?UUID.randomUUID().toString():dto.getDeviceKey()); s.setCondominioId(dto.getCondominioId()); s.setLatitude(dto.getLatitude()); s.setLongitude(dto.getLongitude()); s.setStatus(1);
        return ResponseEntity.ok(ResponseModel.ok(sensoresRepository.save(s),"Sensor criado"));
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/{idCondominio}") public ResponseEntity<ResponseModel<List<SensoresModel>>> getSensoresByCondominio(@PathVariable Integer idCondominio){ return ResponseEntity.ok(ResponseModel.ok(sensoresRepository.findByCondominioId(idCondominio),"Sensores do condomínio")); }

    @PreAuthorize("isAuthenticated()")
    @PutMapping public ResponseEntity<ResponseModel<SensoresModel>> updateSensor(@RequestBody SensorEditDTO dto){ return sensoresRepository.findById(dto.getId()).map(s->{ s.setNome(dto.getNome()); s.setCondominioId(dto.getCondominioId()); s.setStatus(dto.getStatus()); s.setLatitude(dto.getLatitude()); s.setLongitude(dto.getLongitude()); return ResponseEntity.ok(ResponseModel.ok(sensoresRepository.save(s),"Sensor atualizado")); }).orElseGet(()->ResponseEntity.badRequest().body(ResponseModel.<SensoresModel>erro("Sensor não encontrado"))); }

    @PreAuthorize("isAuthenticated()")
    @PutMapping("/update-locale-{idSensor}") public ResponseEntity<ResponseModel<SensoresModel>> updateSensorLocale(@PathVariable Integer idSensor, @RequestBody SensorUpdateLocaleDTO dto){ return sensoresRepository.findById(idSensor).map(s->{ s.setLatitude(dto.getLatitude()); s.setLongitude(dto.getLongitude()); return ResponseEntity.ok(ResponseModel.ok(sensoresRepository.save(s),"Localização atualizada")); }).orElseGet(()->ResponseEntity.badRequest().body(ResponseModel.<SensoresModel>erro("Sensor não encontrado"))); }

    @PreAuthorize("isAuthenticated()")
    @DeleteMapping("/{idSensor}") public ResponseEntity<ResponseModel<List<SensoresModel>>> deleteSensor(@PathVariable Integer idSensor){ if(!sensoresRepository.existsById(idSensor)) return ResponseEntity.badRequest().body(ResponseModel.<List<SensoresModel>>erro("Sensor não encontrado")); sensoresRepository.deleteById(idSensor); return ResponseEntity.ok(ResponseModel.ok(sensoresRepository.findAll(),"Sensor removido")); }
}
