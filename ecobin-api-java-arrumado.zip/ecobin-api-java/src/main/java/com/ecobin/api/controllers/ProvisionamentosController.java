package com.ecobin.api.controllers;

import com.ecobin.api.dto.provisionamentos.*; import com.ecobin.api.models.*; import com.ecobin.api.repositories.*; import org.springframework.http.ResponseEntity; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.time.LocalDateTime; import java.util.*;

@RestController
@RequestMapping("/api/Provisionamentos")
public class ProvisionamentosController {
    private final ProvisionamentosRepository provisionamentosRepository; private final SensoresRepository sensoresRepository;
    public ProvisionamentosController(ProvisionamentosRepository provisionamentosRepository, SensoresRepository sensoresRepository){this.provisionamentosRepository=provisionamentosRepository;this.sensoresRepository=sensoresRepository;}

    @PreAuthorize("isAuthenticated()")
    @GetMapping public ResponseEntity<ResponseModel<List<ProvisionamentosModel>>> getProvisionamentos(){ return ResponseEntity.ok(ResponseModel.ok(provisionamentosRepository.findAll(),"Provisionamentos listados")); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/{id}") public ResponseEntity<ResponseModel<ProvisionamentosModel>> getProvisionamentoById(@PathVariable Integer id){ return provisionamentosRepository.findById(id).map(p->ResponseEntity.ok(ResponseModel.ok(p,"Provisionamento localizado"))).orElseGet(()->ResponseEntity.badRequest().body(ResponseModel.<ProvisionamentosModel>erro("Provisionamento não encontrado"))); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/criar") public ResponseEntity<ResponseModel<ProvisionamentosModel>> criarProvisionamento(@RequestBody ProvisionCreateRequestDTO dto){ ProvisionamentosModel p=new ProvisionamentosModel(); p.setSensorId(dto.getSensorId()); p.setUsuarioId(dto.getUsuarioId()); p.setSessionToken(UUID.randomUUID().toString()); p.setSessionExpires(LocalDateTime.now().plusDays(dto.getExpiracaoDias()==null?1:dto.getExpiracaoDias())); p.setExpiracao(p.getSessionExpires()); return ResponseEntity.ok(ResponseModel.ok(provisionamentosRepository.save(p),"Provisionamento criado")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/criar-com-sensor") public ResponseEntity<ResponseModel<ProvisionamentosModel>> criarProvisionamentoComSensor(@RequestBody ProvisionCreateWithSensorDTO dto){ SensoresModel s=new SensoresModel(); s.setNome(dto.getNomeSensor()); s.setCondominioId(dto.getCondominioId()); s.setDeviceId("DEV-"+UUID.randomUUID()); s.setDeviceKey(UUID.randomUUID().toString()); s=sensoresRepository.save(s); ProvisionamentosModel p=new ProvisionamentosModel(); p.setSensorId(s.getId()); p.setUsuarioId(dto.getUsuarioId()); p.setNomeSensor(dto.getNomeSensor()); p.setSessionToken(UUID.randomUUID().toString()); p.setSessionExpires(LocalDateTime.now().plusDays(dto.getExpiracaoDias()==null?1:dto.getExpiracaoDias())); p.setExpiracao(p.getSessionExpires()); return ResponseEntity.ok(ResponseModel.ok(provisionamentosRepository.save(p),"Provisionamento criado com sensor")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/ativar-qr") public ResponseEntity<ResponseModel<ProvisionActivateResponseDTO>> ativarQr(@RequestBody ProvisionActivateRequestDTO dto){ SensoresModel s=new SensoresModel(); s.setDeviceId(dto.getDeviceId()); s.setNome(dto.getNomeSensor()); s.setCondominioId(dto.getCondominioId()); s.setLatitude(dto.getLatitude()); s.setLongitude(dto.getLongitude()); s.setDeviceKey(UUID.randomUUID().toString()); s=sensoresRepository.save(s); ProvisionActivateResponseDTO res=new ProvisionActivateResponseDTO(); res.setSuccess(true); res.setDeviceId(s.getDeviceId()); res.setSensorId(s.getId()); res.setSessionToken(UUID.randomUUID().toString()); res.setSessionExpires(LocalDateTime.now().plusDays(1)); res.setMessage("QR ativado"); return ResponseEntity.ok(ResponseModel.ok(res,"QR ativado")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/{sessionToken}/assign-wifi") public ResponseEntity<ResponseModel<Object>> assignWifi(@PathVariable String sessionToken, @RequestBody AssignWifiRequestDTO dto){ return provisionamentosRepository.findBySessionToken(sessionToken).map(p->{ p.setSsidCriptografado(dto.getWifiSSID()); p.setSenhaWifiCriptografada(dto.getWifiPassword()); provisionamentosRepository.save(p); return ResponseEntity.ok(ResponseModel.ok((Object)null,"Wi-Fi associado")); }).orElseGet(()->ResponseEntity.badRequest().body(ResponseModel.<Object>erro("Sessão não encontrada"))); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/wifi-credentials/{deviceId}") public ResponseEntity<ResponseModel<Object>> getWifiCredentials(@PathVariable String deviceId, @RequestParam String sessionToken){ return ResponseEntity.ok(ResponseModel.ok(Map.of("deviceId",deviceId,"sessionToken",sessionToken),"Credenciais")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/confirm-config/{deviceId}") public ResponseEntity<ResponseModel<Object>> confirmConfig(@PathVariable String deviceId, @RequestBody com.ecobin.api.dto.devices.ConfirmConfigDTO dto){ return ResponseEntity.ok(ResponseModel.ok(null,"Configuração confirmada")); }
}
