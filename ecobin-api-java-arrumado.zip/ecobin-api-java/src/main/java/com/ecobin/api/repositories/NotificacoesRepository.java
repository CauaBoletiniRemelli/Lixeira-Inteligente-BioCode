package com.ecobin.api.repositories;

import com.ecobin.api.models.NotificacoesModel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificacoesRepository extends JpaRepository<NotificacoesModel, Integer> {
    List<NotificacoesModel> findByUsuarioIdOrderByDataEnvioDesc(Integer usuarioId);
    List<NotificacoesModel> findByUsuarioIdAndLidaFalseOrderByDataEnvioDesc(Integer usuarioId);
}
