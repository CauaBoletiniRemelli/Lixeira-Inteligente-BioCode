package com.ecobin.api.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "refresh_tokens")
public class RefreshTokensModel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer usuarioId;
    @Column(nullable=false, unique=true, length=500)
    private String token;
    private LocalDateTime expiracao;
    private LocalDateTime criadoEm;
    private Boolean revogado;
    @PrePersist public void prePersist(){ if(criadoEm==null) criadoEm=LocalDateTime.now(); if(revogado==null) revogado=false; }
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Integer getUsuarioId(){return usuarioId;} public void setUsuarioId(Integer usuarioId){this.usuarioId=usuarioId;}
    public String getToken(){return token;} public void setToken(String token){this.token=token;}
    public LocalDateTime getExpiracao(){return expiracao;} public void setExpiracao(LocalDateTime expiracao){this.expiracao=expiracao;}
    public LocalDateTime getCriadoEm(){return criadoEm;} public void setCriadoEm(LocalDateTime criadoEm){this.criadoEm=criadoEm;}
    public Boolean getRevogado(){return revogado;} public void setRevogado(Boolean revogado){this.revogado=revogado;}
}
