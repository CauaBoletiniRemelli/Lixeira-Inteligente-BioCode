package com.ecobin.api.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "notificacoes")
public class NotificacoesModel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer expoTokenId;
    private Integer usuarioId;
    private String titulo;
    @Column(length = 2000)
    private String mensagem;
    @Column(length = 2000)
    private String dados;
    private LocalDateTime dataEnvio;
    private Boolean lida;
    private LocalDateTime dataLeitura;
    private Boolean enviada;
    private String erro;
    @PrePersist public void prePersist(){ if(dataEnvio==null) dataEnvio=LocalDateTime.now(); if(lida==null) lida=false; if(enviada==null) enviada=true; }
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Integer getExpoTokenId(){return expoTokenId;} public void setExpoTokenId(Integer expoTokenId){this.expoTokenId=expoTokenId;}
    public Integer getUsuarioId(){return usuarioId;} public void setUsuarioId(Integer usuarioId){this.usuarioId=usuarioId;}
    public String getTitulo(){return titulo;} public void setTitulo(String titulo){this.titulo=titulo;}
    public String getMensagem(){return mensagem;} public void setMensagem(String mensagem){this.mensagem=mensagem;}
    public String getDados(){return dados;} public void setDados(String dados){this.dados=dados;}
    public LocalDateTime getDataEnvio(){return dataEnvio;} public void setDataEnvio(LocalDateTime dataEnvio){this.dataEnvio=dataEnvio;}
    public Boolean getLida(){return lida;} public void setLida(Boolean lida){this.lida=lida;}
    public LocalDateTime getDataLeitura(){return dataLeitura;} public void setDataLeitura(LocalDateTime dataLeitura){this.dataLeitura=dataLeitura;}
    public Boolean getEnviada(){return enviada;} public void setEnviada(Boolean enviada){this.enviada=enviada;}
    public String getErro(){return erro;} public void setErro(String erro){this.erro=erro;}
}
