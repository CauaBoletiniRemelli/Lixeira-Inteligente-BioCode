package com.ecobin.api.dto.provisionamentos;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class ProvisionCreateWithSensorDTO {
    private String nomeSensor;
    private Integer condominioId;
    private Integer usuarioId;
    private Integer expiracaoDias;

    public ProvisionCreateWithSensorDTO() {}

    public String getNomeSensor() { return nomeSensor; }
    public void setNomeSensor(String nomeSensor) { this.nomeSensor = nomeSensor; }

    public Integer getCondominioId() { return condominioId; }
    public void setCondominioId(Integer condominioId) { this.condominioId = condominioId; }

    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer usuarioId) { this.usuarioId = usuarioId; }

    public Integer getExpiracaoDias() { return expiracaoDias; }
    public void setExpiracaoDias(Integer expiracaoDias) { this.expiracaoDias = expiracaoDias; }

}
