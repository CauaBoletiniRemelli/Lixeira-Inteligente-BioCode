package com.ecobin.api.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "expo_tokens")
public class ExpoTokensModel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer usuarioId;
    @Column(nullable = false, unique = true, length = 500)
    private String token;
    private String dispositivo;
    private String plataforma;
    private LocalDateTime dataCriacao;
    private LocalDateTime ultimaAtualizacao;
    private Boolean ativo;
    @Transient private List<NotificacoesModel> notificacoes;
    @PrePersist public void prePersist(){ dataCriacao=LocalDateTime.now(); ultimaAtualizacao=dataCriacao; if(ativo==null) ativo=true; }
    @PreUpdate public void preUpdate(){ ultimaAtualizacao=LocalDateTime.now(); }
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Integer getUsuarioId(){return usuarioId;} public void setUsuarioId(Integer usuarioId){this.usuarioId=usuarioId;}
    public String getToken(){return token;} public void setToken(String token){this.token=token;}
    public String getDispositivo(){return dispositivo;} public void setDispositivo(String dispositivo){this.dispositivo=dispositivo;}
    public String getPlataforma(){return plataforma;} public void setPlataforma(String plataforma){this.plataforma=plataforma;}
    public LocalDateTime getDataCriacao(){return dataCriacao;} public void setDataCriacao(LocalDateTime dataCriacao){this.dataCriacao=dataCriacao;}
    public LocalDateTime getUltimaAtualizacao(){return ultimaAtualizacao;} public void setUltimaAtualizacao(LocalDateTime ultimaAtualizacao){this.ultimaAtualizacao=ultimaAtualizacao;}
    public Boolean getAtivo(){return ativo;} public void setAtivo(Boolean ativo){this.ativo=ativo;}
    public List<NotificacoesModel> getNotificacoes(){return notificacoes;} public void setNotificacoes(List<NotificacoesModel> notificacoes){this.notificacoes=notificacoes;}
}
