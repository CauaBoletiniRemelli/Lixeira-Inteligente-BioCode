package com.ecobin.api.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "provisionamentos")
public class ProvisionamentosModel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer sensorId;
    @Column(length=1000) private String ssidCriptografado;
    @Column(length=1000) private String senhaWifiCriptografada;
    private String nomeSensor;
    private Integer usuarioId;
    private LocalDateTime expiracao;
    private Boolean usado;
    private LocalDateTime criadoEm;
    private String sessionToken;
    private LocalDateTime sessionExpires;
    @PrePersist public void prePersist(){ if(criadoEm==null) criadoEm=LocalDateTime.now(); if(usado==null) usado=false; }
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Integer getSensorId(){return sensorId;} public void setSensorId(Integer sensorId){this.sensorId=sensorId;}
    public String getSsidCriptografado(){return ssidCriptografado;} public void setSsidCriptografado(String ssidCriptografado){this.ssidCriptografado=ssidCriptografado;}
    public String getSenhaWifiCriptografada(){return senhaWifiCriptografada;} public void setSenhaWifiCriptografada(String senhaWifiCriptografada){this.senhaWifiCriptografada=senhaWifiCriptografada;}
    public String getNomeSensor(){return nomeSensor;} public void setNomeSensor(String nomeSensor){this.nomeSensor=nomeSensor;}
    public Integer getUsuarioId(){return usuarioId;} public void setUsuarioId(Integer usuarioId){this.usuarioId=usuarioId;}
    public LocalDateTime getExpiracao(){return expiracao;} public void setExpiracao(LocalDateTime expiracao){this.expiracao=expiracao;}
    public Boolean getUsado(){return usado;} public void setUsado(Boolean usado){this.usado=usado;}
    public LocalDateTime getCriadoEm(){return criadoEm;} public void setCriadoEm(LocalDateTime criadoEm){this.criadoEm=criadoEm;}
    public String getSessionToken(){return sessionToken;} public void setSessionToken(String sessionToken){this.sessionToken=sessionToken;}
    public LocalDateTime getSessionExpires(){return sessionExpires;} public void setSessionExpires(LocalDateTime sessionExpires){this.sessionExpires=sessionExpires;}
}
