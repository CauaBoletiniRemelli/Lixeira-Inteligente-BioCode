package com.ecobin.api.controllers;

import com.ecobin.api.dto.telemetrias.*; import com.ecobin.api.models.*; import com.ecobin.api.repositories.TelemetriasRepository; import org.springframework.data.domain.PageRequest; import org.springframework.http.ResponseEntity; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.math.BigDecimal; import java.time.LocalDateTime; import java.util.*;

@RestController
@RequestMapping("/api/Telemetrias")
public class TelemetriasController {
    private final TelemetriasRepository telemetriasRepository;
    public TelemetriasController(TelemetriasRepository telemetriasRepository) { this.telemetriasRepository = telemetriasRepository; }

    @PreAuthorize("isAuthenticated()")
    @PostMapping public ResponseEntity<ResponseModel<TelemetriasModel>> createTelemetria(@RequestBody TelemetriaCreateDTO dto){ TelemetriasModel t=new TelemetriasModel(); t.setSensorId(dto.getSensorId()); t.setNivelOcupacao(dto.getNivelOcupacao()); t.setBateria(dto.getBateria()); t.setTemperatura(dto.getTemperatura()); t.setDadosBrutos(dto.getDadosBrutos()); t.setMomento(dto.getMomento()==null? LocalDateTime.now():dto.getMomento()); return ResponseEntity.ok(ResponseModel.ok(telemetriasRepository.save(t),"Telemetria criada")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/arduino") public ResponseEntity<ResponseModel<TelemetriasModel>> createTelemetriaArduino(@RequestBody TelemetriaArduinoDTO dto){ TelemetriasModel t=new TelemetriasModel(); t.setSensorId(dto.getSensorId()); t.setNivelOcupacao(Math.round(dto.getNivelLixo())); t.setBateria(dto.getBateria()); t.setTemperatura(BigDecimal.valueOf(dto.getTemperatura())); t.setDadosBrutos(dto.getDataHora()); t.setMomento(LocalDateTime.now()); return ResponseEntity.ok(ResponseModel.ok(telemetriasRepository.save(t),"Telemetria Arduino criada")); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping public ResponseEntity<ResponseModel<List<TelemetriasModel>>> getTelemetrias(){ return ResponseEntity.ok(ResponseModel.ok(telemetriasRepository.findAll(),"Telemetrias listadas")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/filtrar") public ResponseEntity<ResponseModel<List<TelemetriasModel>>> getTelemetriasFiltro(@RequestBody TelemetriaFiltroDTO filtro){ List<TelemetriasModel> base = filtro.getSensorId()==null ? telemetriasRepository.findAll() : telemetriasRepository.findBySensorId(filtro.getSensorId()); return ResponseEntity.ok(ResponseModel.ok(base,"Filtro aplicado")); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/sensor/{sensorId}") public ResponseEntity<ResponseModel<List<TelemetriasModel>>> getTelemetriasBySensor(@PathVariable Integer sensorId, @RequestParam(defaultValue="100") int limit){ return ResponseEntity.ok(ResponseModel.ok(telemetriasRepository.findBySensorIdOrderByMomentoDesc(sensorId, PageRequest.of(0, Math.max(1, limit))),"Telemetrias do sensor")); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/sensor/{sensorId}/ultima") public ResponseEntity<ResponseModel<TelemetriasModel>> getUltimaTelemetria(@PathVariable Integer sensorId){ var lista=telemetriasRepository.findBySensorIdOrderByMomentoDesc(sensorId, PageRequest.of(0,1)); return ResponseEntity.ok(ResponseModel.ok(lista.isEmpty()?null:lista.get(0),"Última telemetria")); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/condominio/{condominioId}") public ResponseEntity<ResponseModel<List<TelemetriasModel>>> getTelemetriasByCondominio(@PathVariable Integer condominioId){ return ResponseEntity.ok(ResponseModel.ok(telemetriasRepository.findAll(),"Telemetrias do condomínio")); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/sensor/{sensorId}/estatisticas") public ResponseEntity<ResponseModel<TelemetriaStatsDTO>> getEstatisticasSensor(@PathVariable Integer sensorId){ List<TelemetriasModel> lista=telemetriasRepository.findBySensorId(sensorId); TelemetriaStatsDTO stats=new TelemetriaStatsDTO(); stats.setSensorId(sensorId); stats.setTotalLeituras(lista.size()); if(!lista.isEmpty()){ TelemetriasModel ultima=lista.get(lista.size()-1); stats.setNivelAtual(ultima.getNivelOcupacao()); stats.setUltimaLeitura(ultima.getMomento()); } return ResponseEntity.ok(ResponseModel.ok(stats,"Estatísticas do sensor")); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/condominio/{condominioId}/estatisticas") public ResponseEntity<ResponseModel<TelemetriaStatsDTO>> getEstatisticasCondominio(@PathVariable Integer condominioId){ TelemetriaStatsDTO stats=new TelemetriaStatsDTO(); stats.setTotalLeituras((int)telemetriasRepository.count()); return ResponseEntity.ok(ResponseModel.ok(stats,"Estatísticas do condomínio")); }

    @PreAuthorize("isAuthenticated()")
    @DeleteMapping("/limpeza") public ResponseEntity<ResponseModel<Object>> deleteTelemetriasAntigas(@RequestParam String dataLimite){ return ResponseEntity.ok(ResponseModel.ok(null,"Limpeza executada")); }
}
