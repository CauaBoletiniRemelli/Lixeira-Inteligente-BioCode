package com.ecobin.api.repositories;

import com.ecobin.api.models.TelemetriasModel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import org.springframework.data.domain.Pageable;

public interface TelemetriasRepository extends JpaRepository<TelemetriasModel, Integer> {
    List<TelemetriasModel> findBySensorIdOrderByMomentoDesc(Integer sensorId, Pageable pageable);
    List<TelemetriasModel> findBySensorId(Integer sensorId);
}
