package com.ecobin.api.models;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "telemetrias")
public class TelemetriasModel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer sensorId;
    private LocalDateTime momento;
    private Integer nivelOcupacao;
    private Integer bateria;
    private BigDecimal temperatura;
    @Column(length = 2000)
    private String dadosBrutos;
    @PrePersist public void prePersist(){ if(momento==null) momento=LocalDateTime.now(); }
    public Integer getId(){return id;} public void setId(Integer id){this.id=id;}
    public Integer getSensorId(){return sensorId;} public void setSensorId(Integer sensorId){this.sensorId=sensorId;}
    public LocalDateTime getMomento(){return momento;} public void setMomento(LocalDateTime momento){this.momento=momento;}
    public Integer getNivelOcupacao(){return nivelOcupacao;} public void setNivelOcupacao(Integer nivelOcupacao){this.nivelOcupacao=nivelOcupacao;}
    public Integer getBateria(){return bateria;} public void setBateria(Integer bateria){this.bateria=bateria;}
    public BigDecimal getTemperatura(){return temperatura;} public void setTemperatura(BigDecimal temperatura){this.temperatura=temperatura;}
    public String getDadosBrutos(){return dadosBrutos;} public void setDadosBrutos(String dadosBrutos){this.dadosBrutos=dadosBrutos;}
}
