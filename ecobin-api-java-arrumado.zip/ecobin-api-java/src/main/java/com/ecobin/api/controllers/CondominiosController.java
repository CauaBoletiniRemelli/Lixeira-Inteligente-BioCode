package com.ecobin.api.controllers;

import com.ecobin.api.dto.condominios.*;
import com.ecobin.api.models.*;
import com.ecobin.api.repositories.CondominiosRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/Condominios")
public class CondominiosController {
    private final CondominiosRepository condominiosRepository;
    public CondominiosController(CondominiosRepository condominiosRepository) { this.condominiosRepository = condominiosRepository; }
    @PreAuthorize("hasAuthority('AdminOnly') or hasAuthority('Admin')")
    @GetMapping public ResponseEntity<ResponseModel<List<CondominiosModel>>> getCondominios(){ return ResponseEntity.ok(ResponseModel.ok(condominiosRepository.findAll(), "Condomínios listados")); }
    @PreAuthorize("hasAuthority('AdminOnly') or hasAuthority('Admin')")
    @PostMapping public ResponseEntity<ResponseModel<CondominiosModel>> postCondominio(@RequestBody CondominiosCreateDTO dto){ CondominiosModel c=new CondominiosModel(); c.setNome(dto.getNome()); c.setEndereco(dto.getEndereco()); c.setCep(dto.getCep()); c.setAtivo(dto.getAtivo()==null?true:dto.getAtivo()); return ResponseEntity.ok(ResponseModel.ok(condominiosRepository.save(c),"Condomínio criado")); }
    @PreAuthorize("hasAuthority('AdminOnly') or hasAuthority('Admin')")
    @PutMapping public ResponseEntity<ResponseModel<CondominiosModel>> updateCondominio(@RequestBody CondominioEditDTO dto){ return condominiosRepository.findById(dto.getId()).map(c->{ c.setNome(dto.getNome()); c.setEndereco(dto.getEndereco()); c.setCep(dto.getCep()); c.setAtivo(dto.getAtivo()); return ResponseEntity.ok(ResponseModel.ok(condominiosRepository.save(c),"Condomínio atualizado")); }).orElseGet(()->ResponseEntity.badRequest().body(ResponseModel.<CondominiosModel>erro("Condomínio não encontrado"))); }
    @PreAuthorize("hasAuthority('AdminOnly') or hasAuthority('Admin')")
    @DeleteMapping("/{idCond}") public ResponseEntity<ResponseModel<List<CondominiosModel>>> deleteCondominio(@PathVariable Integer idCond){ if(!condominiosRepository.existsById(idCond)) return ResponseEntity.badRequest().body(ResponseModel.<List<CondominiosModel>>erro("Condomínio não encontrado")); condominiosRepository.deleteById(idCond); return ResponseEntity.ok(ResponseModel.ok(condominiosRepository.findAll(),"Condomínio removido")); }
}
