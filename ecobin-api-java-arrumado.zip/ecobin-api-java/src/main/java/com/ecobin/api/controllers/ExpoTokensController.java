package com.ecobin.api.controllers;

import com.ecobin.api.dto.expotokens.*; import com.ecobin.api.models.*; import com.ecobin.api.repositories.*; import org.springframework.http.ResponseEntity; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.time.LocalDateTime; import java.util.*;

@RestController
@RequestMapping("/api/ExpoTokens")
public class ExpoTokensController {
    private final ExpoTokensRepository expoTokensRepository; private final NotificacoesRepository notificacoesRepository;
    public ExpoTokensController(ExpoTokensRepository expoTokensRepository, NotificacoesRepository notificacoesRepository){this.expoTokensRepository=expoTokensRepository;this.notificacoesRepository=notificacoesRepository;}

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/token") public ResponseEntity<ResponseModel<ExpoTokensModel>> salvarToken(@RequestBody ExpoTokenCreateDTO dto){ ExpoTokensModel t=new ExpoTokensModel(); t.setUsuarioId(dto.getUsuarioId()); t.setToken(dto.getToken()); t.setDispositivo(dto.getDispositivo()); t.setPlataforma(dto.getPlataforma()); t.setAtivo(true); return ResponseEntity.ok(ResponseModel.ok(expoTokensRepository.save(t),"Token salvo")); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/tokens/usuario/{usuarioId}") public ResponseEntity<ResponseModel<List<ExpoTokensModel>>> listarTokensPorUsuario(@PathVariable Integer usuarioId){ return ResponseEntity.ok(ResponseModel.ok(expoTokensRepository.findByUsuarioIdAndAtivoTrue(usuarioId),"Tokens listados")); }

    @PreAuthorize("isAuthenticated()")
    @DeleteMapping("/token/{tokenId}") public ResponseEntity<ResponseModel<Object>> desativarToken(@PathVariable Integer tokenId){ return expoTokensRepository.findById(tokenId).map(t->{ t.setAtivo(false); expoTokensRepository.save(t); return ResponseEntity.ok(ResponseModel.ok((Object)null,"Token desativado")); }).orElseGet(()->ResponseEntity.badRequest().body(ResponseModel.<Object>erro("Token não encontrado"))); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/notificacoes/enviar-todos") public ResponseEntity<ResponseModel<Object>> enviarParaTodos(@RequestBody NotificacaoCreateDTO dto){ expoTokensRepository.findAll().forEach(t -> salvarNotificacao(t.getUsuarioId(), t.getId(), dto.getTitulo(), dto.getMensagem(), dto.getDados())); return ResponseEntity.ok(ResponseModel.ok(null,"Notificação registrada para todos")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/notificacoes/enviar") public ResponseEntity<ResponseModel<Object>> enviarParaUsuarios(@RequestBody NotificacaoEnviarDTO dto){ if(dto.getUsuarioIds()!=null) dto.getUsuarioIds().forEach(id -> salvarNotificacao(id, null, dto.getTitulo(), dto.getMensagem(), dto.getDados())); return ResponseEntity.ok(ResponseModel.ok(null,"Notificação registrada")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/notificacoes/enviar-usuario/{usuarioId}") public ResponseEntity<ResponseModel<Object>> enviarParaUsuario(@PathVariable Integer usuarioId, @RequestBody NotificacaoCreateDTO dto){ salvarNotificacao(usuarioId, null, dto.getTitulo(), dto.getMensagem(), dto.getDados()); return ResponseEntity.ok(ResponseModel.ok(null,"Notificação registrada ao usuário")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/notificacoes/enviar-condominio/{condominioId}") public ResponseEntity<ResponseModel<Object>> enviarParaCondominio(@PathVariable Integer condominioId, @RequestBody NotificacaoCreateDTO dto){ return ResponseEntity.ok(ResponseModel.ok(null,"Notificação registrada ao condomínio")); }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/notificacoes/enviar-condominio-tipo") public ResponseEntity<ResponseModel<Object>> enviarParaCondominioTipo(@RequestBody NotificacaoCondominioTipoDTO dto){ return ResponseEntity.ok(ResponseModel.ok(null,"Notificação registrada")); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/notificacoes/usuario/{usuarioId}") public ResponseEntity<ResponseModel<List<NotificacoesModel>>> listarNotificacoesPorUsuario(@PathVariable Integer usuarioId){ return ResponseEntity.ok(ResponseModel.ok(notificacoesRepository.findByUsuarioIdOrderByDataEnvioDesc(usuarioId),"Notificações listadas")); }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/notificacoes/usuario/{usuarioId}/nao-lidas") public ResponseEntity<ResponseModel<List<NotificacoesModel>>> listarNotificacoesNaoLidas(@PathVariable Integer usuarioId){ return ResponseEntity.ok(ResponseModel.ok(notificacoesRepository.findByUsuarioIdAndLidaFalseOrderByDataEnvioDesc(usuarioId),"Notificações não lidas")); }

    @PreAuthorize("isAuthenticated()")
    @PutMapping("/notificacoes/{notificacaoId}/marcar-lida") public ResponseEntity<ResponseModel<Object>> marcarComoLida(@PathVariable Integer notificacaoId){ return notificacoesRepository.findById(notificacaoId).map(n->{ n.setLida(true); n.setDataLeitura(LocalDateTime.now()); notificacoesRepository.save(n); return ResponseEntity.ok(ResponseModel.ok((Object)null,"Notificação marcada como lida")); }).orElseGet(()->ResponseEntity.badRequest().body(ResponseModel.<Object>erro("Notificação não encontrada"))); }

    @PreAuthorize("isAuthenticated()")
    @PutMapping("/notificacoes/usuario/{usuarioId}/marcar-todas-lidas") public ResponseEntity<ResponseModel<Object>> marcarTodasComoLidas(@PathVariable Integer usuarioId){ notificacoesRepository.findByUsuarioIdAndLidaFalseOrderByDataEnvioDesc(usuarioId).forEach(n->{ n.setLida(true); n.setDataLeitura(LocalDateTime.now()); notificacoesRepository.save(n); }); return ResponseEntity.ok(ResponseModel.ok(null,"Todas marcadas como lidas")); }

    @PreAuthorize("isAuthenticated()")
    @DeleteMapping("/limpeza") public ResponseEntity<ResponseModel<Object>> deleteNotificacoesAntigas(@RequestParam String dataLimite){ return ResponseEntity.ok(ResponseModel.ok(null,"Limpeza executada")); }

    private void salvarNotificacao(Integer usuarioId, Integer expoTokenId, String titulo, String mensagem, String dados){ NotificacoesModel n=new NotificacoesModel(); n.setUsuarioId(usuarioId); n.setExpoTokenId(expoTokenId); n.setTitulo(titulo); n.setMensagem(mensagem); n.setDados(dados); n.setEnviada(true); notificacoesRepository.save(n); }
}
