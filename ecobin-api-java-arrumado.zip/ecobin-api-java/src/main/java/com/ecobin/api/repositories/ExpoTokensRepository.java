package com.ecobin.api.repositories;

import com.ecobin.api.models.ExpoTokensModel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ExpoTokensRepository extends JpaRepository<ExpoTokensModel, Integer> {
    List<ExpoTokensModel> findByUsuarioIdAndAtivoTrue(Integer usuarioId);
}
