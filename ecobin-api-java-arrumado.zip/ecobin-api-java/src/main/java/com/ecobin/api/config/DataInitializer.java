package com.ecobin.api.config;

import com.ecobin.api.enums.TipoUsuario;
import com.ecobin.api.models.UsuariosModel;
import com.ecobin.api.repositories.UsuariosRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner seedAdmin(UsuariosRepository usuariosRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            if (usuariosRepository.findByEmail("admin@ecobin.com").isEmpty()) {
                UsuariosModel admin = new UsuariosModel();
                admin.setNome("Administrador EcoBin");
                admin.setEmail("admin@ecobin.com");
                admin.setSenhaHash(passwordEncoder.encode("123456"));
                admin.setTipo(TipoUsuario.Admin);
                usuariosRepository.save(admin);
            }
        };
    }
}
