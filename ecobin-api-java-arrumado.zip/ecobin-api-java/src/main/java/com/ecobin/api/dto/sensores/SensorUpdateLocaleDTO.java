package com.ecobin.api.dto.sensores;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class SensorUpdateLocaleDTO {
    private Integer id;
    private BigDecimal latitude;
    private BigDecimal longitude;

    public SensorUpdateLocaleDTO() {}

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public BigDecimal getLatitude() { return latitude; }
    public void setLatitude(BigDecimal latitude) { this.latitude = latitude; }

    public BigDecimal getLongitude() { return longitude; }
    public void setLongitude(BigDecimal longitude) { this.longitude = longitude; }

}
