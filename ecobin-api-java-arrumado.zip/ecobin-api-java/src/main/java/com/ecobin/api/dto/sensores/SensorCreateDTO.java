package com.ecobin.api.dto.sensores;

import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

public class SensorCreateDTO {
    private String deviceId;
    private String deviceKey;
    private Integer condominioId;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private String nome;

    public SensorCreateDTO() {}

    public String getDeviceId() { return deviceId; }
    public void setDeviceId(String deviceId) { this.deviceId = deviceId; }

    public String getDeviceKey() { return deviceKey; }
    public void setDeviceKey(String deviceKey) { this.deviceKey = deviceKey; }

    public Integer getCondominioId() { return condominioId; }
    public void setCondominioId(Integer condominioId) { this.condominioId = condominioId; }

    public BigDecimal getLatitude() { return latitude; }
    public void setLatitude(BigDecimal latitude) { this.latitude = latitude; }

    public BigDecimal getLongitude() { return longitude; }
    public void setLongitude(BigDecimal longitude) { this.longitude = longitude; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

}
